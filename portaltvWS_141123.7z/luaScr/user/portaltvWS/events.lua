--TV Portal events 14.11.23

local function Get_isactiv(id)
	local verNumber, verString = m_simpleTV.Common.GetVersion()
	if verNumber < 1100 then return '' end
	local active = m_simpleTV.Control.GetTracksInfo()
--[[
	if active["video"] and active["video"]["currentID"] and active["audio"] and active["audio"]["currentID"] and active["subtitle"] and active["subtitle"]["currentID"] then
		m_simpleTV.OSD.ShowMessage_UTF8(active["video"]["currentID"] .. ' / ' .. active["audio"]["currentID"] .. ' / ' .. active["subtitle"]["currentID"],0x0000FF00,10 )
	end--]]
	if active and
	(active["video"] and active["video"]["currentID"] and tonumber(id) == tonumber(active["video"]["currentID"]) or
		active["audio"] and active["audio"]["currentID"] and tonumber(id) == tonumber(active["audio"]["currentID"]) or
		active["subtitle"] and active["subtitle"]["currentID"] and tonumber(id) == tonumber(active["subtitle"]["currentID"]))
	then
		return '● '
	end
	return ''
end

local function Get_rating(rating)
	if rating == nil then return 0 end
	local rat = math.ceil((tonumber(rating)*2 - tonumber(rating)*2%1)/2)
	return rat
end

local function Get_lang(lang)
	local t = {
	{'Russian','ru'},
	{'English','en'},
	{'Ukrainian','ua'},
	{'French','fr'},
	{'Deutche','de'},
	{'Italian','it'},
	}
	for i = 1,#t do
		if lang == t[i][1] then return t[i][2] end
	end
	return '-'
end

local function Get_res(res)
	res = res:match('(%d+)')
	if tonumber(res) >= 3800 then
		return '4kbis'
	end
	if tonumber(res) >= 1900 then
		return '1080'
	end
	if tonumber(res) >= 1200 then
		return '720'
	end
	if tonumber(res) >= 800 then
		return '480'
	end
	return 'sd'
end

local function Get_codec(codec)
	codec = codec:match('%(.-%) %((.-)%)$') or codec:match('%((.-)%)$')
	if codec then
		return codec:gsub(' $','')
	end
	return 'na'
end

if m_simpleTV.Control.Reason=='addressready'  then
	if m_simpleTV.User.TVPortal.PortalShowWindowId then
		m_simpleTV.Interface.RemoveExtMenu(m_simpleTV.User.TVPortal.PortalShowWindowId)
	end
	if m_simpleTV.User.TVPortal.PortalShowAdd then
		m_simpleTV.Interface.RemoveExtMenu(m_simpleTV.User.TVPortal.PortalShowAdd)
	end
	if m_simpleTV.User.TVPortal.PortalTable~=nil then
		local t={}
		t.utf8 = true
		t.name = '-'
		t.luastring = ''
		t.lua_as_scr = false
		t.submenu = 'TVPortal WS'
		t.imageSubmenu = ''
		--t.key = string.byte('I')
		t.ctrlkey = 0
		t.location = 0
		t.image=''
		m_simpleTV.User.TVPortal.PortalSeparatorId = m_simpleTV.Interface.AddExtMenuT(t)
		local t={}
		t.utf8 = true
		t.name = 'TVPortal Info Window'
		t.luastring = 'GetPortalTableForTVPortal()'
		t.lua_as_scr = true
		t.submenu = 'TVPortal WS'
		t.imageSubmenu = m_simpleTV.MainScriptDir_UTF8 .. 'user/portaltvWS/img/portaltv.png'
		t.key = string.byte('I')
		t.ctrlkey = 0
		t.location = 0
		t.image= m_simpleTV.MainScriptDir_UTF8 .. 'user/portaltvWS/img/fw_box_t3.png'
		m_simpleTV.User.TVPortal.PortalShowWindowId = m_simpleTV.Interface.AddExtMenuT(t)
		local t={}
		t.utf8 = true
		t.name = 'Add to FAV PlaylistT'
		t.luastring = 'AddPortalTVAddressToPlaylist()'
		t.lua_as_scr = true
		t.submenu = 'TVPortal WS'
		t.imageSubmenu = m_simpleTV.MainScriptDir_UTF8 .. 'user/portaltvWS/img/portaltv.png'
		t.key = string.byte('I')
		t.ctrlkey = 1
		t.location = 0
		t.image= m_simpleTV.MainScriptDir_UTF8 .. 'user/portaltvWS/img/fw_box_t2.png'
		m_simpleTV.User.TVPortal.PortalShowAdd = m_simpleTV.Interface.AddExtMenuT(t)
	end
end

-------------------------
			if m_simpleTV.Control.GetState() == 3 then
			m_simpleTV.User.TVPortal.isPause = true
			m_simpleTV.OSD.RemoveElement('USER_LOGO_IMG_1_ID')
			m_simpleTV.OSD.RemoveElement('ID_DIV_1')
			m_simpleTV.OSD.RemoveElement('ID_DIV_2')
			m_simpleTV.OSD.RemoveElement('TEXT_0_ID')
			m_simpleTV.OSD.RemoveElement('TEXT_1_ID')
			m_simpleTV.OSD.RemoveElement('TEXT_2_ID')
			m_simpleTV.OSD.RemoveElement('TEXT_3_ID')
			m_simpleTV.OSD.RemoveElement('TEXT_4_ID')
			m_simpleTV.OSD.RemoveElement('TEXT_5_ID')
			m_simpleTV.OSD.RemoveElement('RIMDB_IMG_ID')
			m_simpleTV.OSD.RemoveElement('R_IMDB_IMG_ID')
			m_simpleTV.OSD.RemoveElement('RKP_IMG_ID')
			m_simpleTV.OSD.RemoveElement('R_KP_IMG_ID')
			m_simpleTV.OSD.RemoveElement('RTMDB_IMG_ID')
			m_simpleTV.OSD.RemoveElement('R_TMDB_IMG_ID')
			m_simpleTV.OSD.RemoveElement('VIDEO_IMG_ID')
			m_simpleTV.OSD.RemoveElement('CVIDEO_IMG_ID')
			m_simpleTV.OSD.RemoveElement('CAUDIO_IMG_ID')
			m_simpleTV.OSD.RemoveElement('CCB_IMG_ID')
			m_simpleTV.OSD.RemoveElement('CC_IMG_ID')
			m_simpleTV.OSD.RemoveElement('CCL_IMG_ID')
			end

			if m_simpleTV.Control.GetState() == 4 and
			m_simpleTV.User.TVPortal.isPause == true and
			m_simpleTV.User.TVPortal.mess and
			m_simpleTV.User.TVPortal.logo and
			m_simpleTV.User.TVPortal.logo ~= '' then

			local  t, AddElement = {}, m_simpleTV.OSD.AddElement

			 t = {}
			 t.id = 'ID_DIV_1'
			 t.cx=-100 * m_simpleTV.Interface.GetScale()
			 t.cy=-50 * m_simpleTV.Interface.GetScale()
			 t.class="DIV"
			 t.minresx=0
			 t.minresy=0
			 t.align = 0x0201
			 t.left=0
			 t.top=30 * m_simpleTV.Interface.GetScale()
			 t.once=1
			 t.zorder=0
			 t.background = -1
			 t.backcolor0 = 0xff0000000
			 AddElement(t)

			 t = {}
			 t.id = 'ID_DIV_2'
			 t.cx=700 * m_simpleTV.Interface.GetScale()
			 t.cy=-95 * m_simpleTV.Interface.GetScale()
			 t.class="DIV"
			 t.minresx=0
			 t.minresy=0
			 t.align = 0x0101
			 t.left=20 * m_simpleTV.Interface.GetScale()
			 t.top=20 * m_simpleTV.Interface.GetScale()
			 t.once=1
			 t.zorder=0
			 t.background = -1
			 t.backcolor0 = 0x7fFFFF00
			 AddElement(t,'ID_DIV_1')

			 t = {}
			 t.id = 'USER_LOGO_IMG_1_ID'
			 t.cx= 300 * m_simpleTV.Interface.GetScale()
			 t.cy= 450 * m_simpleTV.Interface.GetScale()
			 t.class="IMAGE"
			 t.imagepath = m_simpleTV.User.TVPortal.logo
			 t.minresx=-1
			 t.minresy=-1
			 t.align = 0x0101
			 t.left=20 * m_simpleTV.Interface.GetScale()
			 t.top=0
			 t.transparency = 200
			 t.zorder=0
			 t.borderwidth = 2
			 t.bordercolor = -6250336
			 t.backroundcorner = 0*0
			 t.borderround = 20
			 AddElement(t,'ID_DIV_1')

			 t = {}
			 t.id = 'RIMDB_IMG_ID'
			 t.cx= 90 * m_simpleTV.Interface.GetScale()
			 t.cy= 60 * m_simpleTV.Interface.GetScale()
			 t.class="IMAGE"
			 t.imagepath = m_simpleTV.MainScriptDir_UTF8 .. 'user/show_mi/pause/imdb.png'
			 t.minresx=-1
			 t.minresy=-1
			 t.align = 0x0101
			 t.left=25 * m_simpleTV.Interface.GetScale()
			 t.top=-90 * m_simpleTV.Interface.GetScale()
			 t.transparency = 200
			 t.zorder=0
			 t.borderwidth = 0
			 t.bordercolor = -6250336
			 t.backroundcorner = 0*0
			 t.borderround = 20
			 AddElement(t,'ID_DIV_1')

			 t = {}
			 t.id = 'R_IMDB_IMG_ID'
			 t.cx= 80 * m_simpleTV.Interface.GetScale()
			 t.cy= 16 * m_simpleTV.Interface.GetScale()
			 t.class="IMAGE"
			 t.imagepath = m_simpleTV.MainScriptDir_UTF8 .. 'user/show_mi/stars/' .. Get_rating(m_simpleTV.User.TVPortal.ret_imdb) .. '.png'
			 t.minresx=-1
			 t.minresy=-1
			 t.align = 0x0101
			 t.left=30 * m_simpleTV.Interface.GetScale()
			 t.top=-50 * m_simpleTV.Interface.GetScale()
			 t.transparency = 200
			 t.zorder=0
			 t.borderwidth = 0
			 t.bordercolor = -6250336
			 t.backroundcorner = 0*0
			 t.borderround = 20
			 AddElement(t,'ID_DIV_1')

			 t = {}
			 t.id = 'RKP_IMG_ID'
			 t.cx= 90 * m_simpleTV.Interface.GetScale()
			 t.cy= 60 * m_simpleTV.Interface.GetScale()
			 t.class="IMAGE"
			 t.imagepath = m_simpleTV.MainScriptDir_UTF8 .. 'user/show_mi/pause/kinopoisk.png'
			 t.minresx=-1
			 t.minresy=-1
			 t.align = 0x0101
			 t.left=125 * m_simpleTV.Interface.GetScale()
			 t.top=-90 * m_simpleTV.Interface.GetScale()
			 t.transparency = 200
			 t.zorder=0
			 t.borderwidth = 0
			 t.bordercolor = -6250336
			 t.backroundcorner = 0*0
			 t.borderround = 20
			 AddElement(t,'ID_DIV_1')

			 t = {}
			 t.id = 'R_KP_IMG_ID'
			 t.cx= 80 * m_simpleTV.Interface.GetScale()
			 t.cy= 16 * m_simpleTV.Interface.GetScale()
			 t.class="IMAGE"
			 t.imagepath = m_simpleTV.MainScriptDir_UTF8 .. 'user/show_mi/stars/' .. Get_rating(m_simpleTV.User.TVPortal.ret_KP) .. '.png'
			 t.minresx=-1
			 t.minresy=-1
			 t.align = 0x0101
			 t.left=130 * m_simpleTV.Interface.GetScale()
			 t.top=-50 * m_simpleTV.Interface.GetScale()
			 t.transparency = 200
			 t.zorder=0
			 t.borderwidth = 0
			 t.bordercolor = -6250336
			 t.backroundcorner = 0*0
			 t.borderround = 20
			 AddElement(t,'ID_DIV_1')

			 t = {}
			 t.id = 'RTMDB_IMG_ID'
			 t.cx= 90 * m_simpleTV.Interface.GetScale()
			 t.cy= 60 * m_simpleTV.Interface.GetScale()
			 t.class="IMAGE"
			 t.imagepath = m_simpleTV.MainScriptDir_UTF8 .. 'user/show_mi/pause/tmdb.png'
			 t.minresx=-1
			 t.minresy=-1
			 t.align = 0x0101
			 t.left=225 * m_simpleTV.Interface.GetScale()
			 t.top=-90 * m_simpleTV.Interface.GetScale()
			 t.transparency = 200
			 t.zorder=0
			 t.borderwidth = 0
			 t.bordercolor = -6250336
			 t.backroundcorner = 0*0
			 t.borderround = 20
			 AddElement(t,'ID_DIV_1')

			 t = {}
			 t.id = 'R_TMDB_IMG_ID'
			 t.cx= 80 * m_simpleTV.Interface.GetScale()
			 t.cy= 16 * m_simpleTV.Interface.GetScale()
			 t.class="IMAGE"
			 t.imagepath = m_simpleTV.MainScriptDir_UTF8 .. 'user/show_mi/stars/' .. Get_rating(m_simpleTV.User.TVPortal.ret_tmdb) .. '.png'
			 t.minresx=-1
			 t.minresy=-1
			 t.align = 0x0101
			 t.left=230 * m_simpleTV.Interface.GetScale()
			 t.top=-50 * m_simpleTV.Interface.GetScale()
			 t.transparency = 200
			 t.zorder=0
			 t.borderwidth = 0
			 t.bordercolor = -6250336
			 t.backroundcorner = 0*0
			 t.borderround = 20
			 AddElement(t,'ID_DIV_1')

			if m_simpleTV.User.TVPortal.res_video and m_simpleTV.User.TVPortal.codec_video then
			 t = {}
			 t.id = 'VIDEO_IMG_ID'
			 t.cx= 90 * m_simpleTV.Interface.GetScale()
			 t.cy= 60 * m_simpleTV.Interface.GetScale()
			 t.class="IMAGE"
			 t.imagepath = m_simpleTV.MainScriptDir_UTF8 .. 'user/show_mi/pause/video/' .. m_simpleTV.User.TVPortal.res_video .. '.png'
			 t.minresx=-1
			 t.minresy=-1
			 t.align = 0x0101
			 t.left=375 * m_simpleTV.Interface.GetScale()
			 t.top=-90 * m_simpleTV.Interface.GetScale()
			 t.transparency = 200
			 t.zorder=0
			 t.borderwidth = 0
			 t.bordercolor = -6250336
			 t.backroundcorner = 0*0
			 t.borderround = 20
			 AddElement(t,'ID_DIV_1')

			 t = {}
			 t.id = 'CVIDEO_IMG_ID'
			 t.cx= 90 * m_simpleTV.Interface.GetScale()
			 t.cy= 60 * m_simpleTV.Interface.GetScale()
			 t.class="IMAGE"
			 t.imagepath = m_simpleTV.MainScriptDir_UTF8 .. 'user/show_mi/pause/video/' .. m_simpleTV.User.TVPortal.codec_video .. '.png'
			 t.minresx=-1
			 t.minresy=-1
			 t.align = 0x0101
			 t.left=475 * m_simpleTV.Interface.GetScale()
			 t.top=-90 * m_simpleTV.Interface.GetScale()
			 t.transparency = 200
			 t.zorder=0
			 t.borderwidth = 0
			 t.bordercolor = -6250336
			 t.backroundcorner = 0*0
			 t.borderround = 20
			 AddElement(t,'ID_DIV_1')
			end

			if m_simpleTV.User.TVPortal.codec_audio then
			 t = {}
			 t.id = 'CAUDIO_IMG_ID'
			 t.cx= 90 * m_simpleTV.Interface.GetScale()
			 t.cy= 60 * m_simpleTV.Interface.GetScale()
			 t.class="IMAGE"
			 t.imagepath = m_simpleTV.MainScriptDir_UTF8 .. 'user/show_mi/pause/audio/' .. m_simpleTV.User.TVPortal.codec_audio .. '.png'
			 t.minresx=-1
			 t.minresy=-1
			 t.align = 0x0101
			 t.left=575 * m_simpleTV.Interface.GetScale()
			 t.top=-90 * m_simpleTV.Interface.GetScale()
			 t.transparency = 200
			 t.zorder=0
			 t.borderwidth = 0
			 t.bordercolor = -6250336
			 t.backroundcorner = 0*0
			 t.borderround = 20
			 AddElement(t,'ID_DIV_1')
			end

			if m_simpleTV.User.TVPortal.lang_sub then
			 t = {}
			 t.id = 'CCB_IMG_ID'
			 t.cx= 90 * m_simpleTV.Interface.GetScale()
			 t.cy= 60 * m_simpleTV.Interface.GetScale()
			 t.class="IMAGE"
			 t.imagepath = m_simpleTV.MainScriptDir_UTF8 .. 'user/show_mi/pause/empty.png'
			 t.minresx=-1
			 t.minresy=-1
			 t.align = 0x0101
			 t.left=675 * m_simpleTV.Interface.GetScale()
			 t.top=-90 * m_simpleTV.Interface.GetScale()
			 t.transparency = 200
			 t.zorder=0
			 t.borderwidth = 0
			 t.bordercolor = -6250336
			 t.backroundcorner = 0*0
			 t.borderround = 20
			 AddElement(t,'ID_DIV_1')

			 t = {}
			 t.id = 'CC_IMG_ID'
			 t.cx= 36 * m_simpleTV.Interface.GetScale()
			 t.cy= 36 * m_simpleTV.Interface.GetScale()
			 t.class="IMAGE"
			 t.imagepath = m_simpleTV.MainScriptDir_UTF8 .. 'user/show_mi/pause/subtitle_cc.png'
			 t.minresx=-1
			 t.minresy=-1
			 t.align = 0x0101
			 t.left=685 * m_simpleTV.Interface.GetScale()
			 t.top=-78 * m_simpleTV.Interface.GetScale()
			 t.transparency = 200
			 t.zorder=0
			 t.borderwidth = 0
			 t.bordercolor = -6250336
			 t.backroundcorner = 0*0
			 t.borderround = 20
			 AddElement(t,'ID_DIV_1')

			 t = {}
			 t.id = 'CCL_IMG_ID'
			 t.cx= 27 * m_simpleTV.Interface.GetScale()
			 t.cy= 18 * m_simpleTV.Interface.GetScale()
			 t.class="IMAGE"
			 t.imagepath = m_simpleTV.MainScriptDir_UTF8 .. 'user/show_mi/pause/flags/' .. m_simpleTV.User.TVPortal.lang_sub .. '.png'
			 t.minresx=-1
			 t.minresy=-1
			 t.align = 0x0101
			 t.left=725 * m_simpleTV.Interface.GetScale()
			 t.top=-69 * m_simpleTV.Interface.GetScale()
			 t.transparency = 200
			 t.zorder=0
			 t.borderwidth = 0
			 t.bordercolor = -6250336
			 t.backroundcorner = 0*0
			 t.borderround = 20
			 AddElement(t,'ID_DIV_1')
			end
			 t={}
			 t.id = 'TEXT_0_ID'
			 t.cx=0
			 t.cy=0
			 t.class="TEXT"
			 t.align = 0x0101
			 t.text = m_simpleTV.User.TVPortal.slogan
			 t.color = -9113993
			 t.font_height = -15 * m_simpleTV.Interface.GetScale()
			 t.font_weight = 300 * m_simpleTV.Interface.GetScale()
			 t.font_italic = 1
			 t.font_name = "Segoe UI Black"
			 t.textparam = 0--1+4
			 t.boundWidth = 15 -- bound to screen
			 t.row_limit=1 -- row limit
			 t.scrollTime = 40 --for ticker (auto scrolling text)
			 t.scrollFactor = 2
			 t.scrollWaitStart = 70
			 t.scrollWaitEnd = 100
			 t.left = 350 * m_simpleTV.Interface.GetScale()
			 t.top  = -13 * m_simpleTV.Interface.GetScale()
			 t.glow = 2 -- коэффициент glow эффекта
			 t.glowcolor = 0xFF000077 -- цвет glow эффекта
			 AddElement(t,'USER_LOGO_IMG_1_ID')

			 t={}
			 t.id = 'TEXT_1_ID'
			 t.cx=0
			 t.cy=0
			 t.class="TEXT"
			 t.align = 0x0101
			 t.text = m_simpleTV.User.TVPortal.title
			 t.color = -2123993
			 t.font_height = -35 * m_simpleTV.Interface.GetScale()
			 t.font_weight = 400 * m_simpleTV.Interface.GetScale()
			 t.font_underline = 1
			 t.font_name = "Segoe UI Black"
			 t.textparam = 0--1+4
			 t.boundWidth = 15 -- bound to screen
			 t.row_limit=1 -- row limit
			 t.scrollTime = 40 --for ticker (auto scrolling text)
			 t.scrollFactor = 2
			 t.scrollWaitStart = 70
			 t.scrollWaitEnd = 100
			 t.left = 350 * m_simpleTV.Interface.GetScale()
			 t.top  = 3 * m_simpleTV.Interface.GetScale()
			 t.glow = 3 -- коэффициент glow эффекта
			 t.glowcolor = 0xFF000077 -- цвет glow эффекта
			 AddElement(t,'USER_LOGO_IMG_1_ID')

			 t={}
			 t.id = 'TEXT_2_ID'
			 t.cx=0
			 t.cy=0
			 t.class="TEXT"
			 t.align = 0x0101
			 t.text = m_simpleTV.User.TVPortal.title_en
			 t.color = -2113993
			 t.font_height = -25 * m_simpleTV.Interface.GetScale()
			 t.font_weight = 300 * m_simpleTV.Interface.GetScale()
			 t.font_name = "Segoe UI Black"
			 t.textparam = 0--1+4
			 t.boundWidth = 15 -- bound to screen
			 t.row_limit=1 -- row limit
			 t.scrollTime = 40 --for ticker (auto scrolling text)
			 t.scrollFactor = 2
			 t.scrollWaitStart = 70
			 t.scrollWaitEnd = 100
			 t.left = 350 * m_simpleTV.Interface.GetScale()
			 t.top  = 65 * m_simpleTV.Interface.GetScale()
			 t.glow = 2 -- коэффициент glow эффекта
			 t.glowcolor = 0xFF000077 -- цвет glow эффекта
			 AddElement(t,'USER_LOGO_IMG_1_ID')

			 t={}
			 t.id = 'TEXT_3_ID'
			 t.cx=0
			 t.cy=0
			 t.class="TEXT"
			 t.align = 0x0101
			 t.text = m_simpleTV.User.TVPortal.year .. ' ● ' .. m_simpleTV.User.TVPortal.country
			 t.color = -2113993
			 t.font_height = -15 * m_simpleTV.Interface.GetScale()
			 t.font_weight = 300 * m_simpleTV.Interface.GetScale()
			 t.font_name = "Segoe UI Black"
			 t.textparam = 0--1+4
			 t.left = 350 * m_simpleTV.Interface.GetScale()
			 t.top  = 115 * m_simpleTV.Interface.GetScale()
			 t.glow = 2 -- коэффициент glow эффекта
			 t.glowcolor = 0xFF000077 -- цвет glow эффекта
			 AddElement(t,'USER_LOGO_IMG_1_ID')

			 t={}
			 t.id = 'TEXT_4_ID'
			 t.cx=0
			 t.cy=0
			 t.class="TEXT"
			 t.align = 0x0101
			 t.text = (m_simpleTV.User.TVPortal.genre or '') .. (m_simpleTV.User.TVPortal.age or '') ..  (m_simpleTV.User.TVPortal.time_all or '')
			 t.color = -2113993
			 t.font_height = -15 * m_simpleTV.Interface.GetScale()
			 t.font_weight = 300 * m_simpleTV.Interface.GetScale()
			 t.font_name = "Segoe UI Black"
			 t.textparam = 0--1+4
			 t.left = 350 * m_simpleTV.Interface.GetScale()
			 t.top  = 140 * m_simpleTV.Interface.GetScale()
			 t.glow = 2 -- коэффициент glow эффекта
			 t.glowcolor = 0xFF000077 -- цвет glow эффекта
			 AddElement(t,'USER_LOGO_IMG_1_ID')

			 t={}
			 t.id = 'TEXT_5_ID'
			 t.cx=0
			 t.cy=0
			 t.class="TEXT"
			 t.align = 0x0101
			 t.text = m_simpleTV.User.TVPortal.mess
			 t.color = -2113993
			 t.font_height = -10 * m_simpleTV.Interface.GetScale()
			 t.font_weight = 200 * m_simpleTV.Interface.GetScale()
			 t.font_name = "Segoe UI Black"
			 t.textparam = 0--1+4
			 t.left = 375 * m_simpleTV.Interface.GetScale()
			 t.top  = 180 * m_simpleTV.Interface.GetScale()
			 t.glow = 2 -- коэффициент glow эффекта
			 t.glowcolor = 0xFF000077 -- цвет glow эффекта
			 AddElement(t,'USER_LOGO_IMG_1_ID')

			 m_simpleTV.User.TVPortal.isPause = nil
--			 else
--			 m_simpleTV.OSD.ShowMessage_UTF8('',0x0000FF00,10 )
			 end

-------------------------

if m_simpleTV.Control.Reason=='Stopped' or m_simpleTV.Control.Reason=='Error' or m_simpleTV.Control.Reason == 'EndReached' then
	m_simpleTV.User.TVPortal.PortalTable=nil
	m_simpleTV.User.TVPortal.logo=nil
	m_simpleTV.User.TVPortal.mess=nil
	m_simpleTV.User.TVPortal.age=nil
	m_simpleTV.User.TVPortal.time_all=nil
	m_simpleTV.User.TVPortal.ret_imdb=nil
	m_simpleTV.User.TVPortal.ret_KP=nil
	m_simpleTV.User.TVPortal.ret_tmdb=nil
	if m_simpleTV.User.TVPortal.PortalShowWindowId then
		m_simpleTV.Interface.RemoveExtMenu(m_simpleTV.User.TVPortal.PortalShowWindowId)
	end
	if m_simpleTV.User.TVPortal.PortalShowAdd then
		m_simpleTV.Interface.RemoveExtMenu(m_simpleTV.User.TVPortal.PortalShowAdd)
	end
	m_simpleTV.OSD.RemoveElement('USER_LOGO_IMG_1_ID')
	m_simpleTV.OSD.RemoveElement('ID_DIV_1')
	m_simpleTV.OSD.RemoveElement('ID_DIV_2')
	m_simpleTV.OSD.RemoveElement('TEXT_0_ID')
	m_simpleTV.OSD.RemoveElement('TEXT_1_ID')
	m_simpleTV.OSD.RemoveElement('TEXT_2_ID')
	m_simpleTV.OSD.RemoveElement('TEXT_3_ID')
	m_simpleTV.OSD.RemoveElement('TEXT_4_ID')
	m_simpleTV.OSD.RemoveElement('TEXT_5_ID')
	m_simpleTV.OSD.RemoveElement('RIMDB_IMG_ID')
	m_simpleTV.OSD.RemoveElement('R_IMDB_IMG_ID')
	m_simpleTV.OSD.RemoveElement('RKP_IMG_ID')
	m_simpleTV.OSD.RemoveElement('R_KP_IMG_ID')
	m_simpleTV.OSD.RemoveElement('RTMDB_IMG_ID')
	m_simpleTV.OSD.RemoveElement('R_TMDB_IMG_ID')
	m_simpleTV.OSD.RemoveElement('VIDEO_IMG_ID')
	m_simpleTV.OSD.RemoveElement('CVIDEO_IMG_ID')
	m_simpleTV.OSD.RemoveElement('CAUDIO_IMG_ID')
	m_simpleTV.OSD.RemoveElement('CCB_IMG_ID')
	m_simpleTV.OSD.RemoveElement('CC_IMG_ID')
	m_simpleTV.OSD.RemoveElement('CCL_IMG_ID')
end

if m_simpleTV.Control.Reason == 'Playing' then
   m_simpleTV.Control.EventPlayingInterval=5000
   if m_simpleTV.User.TVPortal.IsFoxRoom == true then
	local name_for_media = m_simpleTV.Control.GetMetaInfo(0)
	name_for_media = name_for_media:gsub('%(',''):gsub('%)',''):gsub('%.',' '):gsub('_','')
	local title, year = name_for_media:match('(.-) (%d%d%d%d)')
	if title and year then
	 m_simpleTV.OSD.ShowMessage_UTF8(title .. ' (' .. year .. ')',0x0000FF00,10 )
	 info_fox(title,year,'')
	 m_simpleTV.User.TVPortal.IsFoxRoom = false
	end
   end
   m_simpleTV.User.TVPortal.lang_sub=nil
   m_simpleTV.User.TVPortal.res_video=nil
   m_simpleTV.User.TVPortal.codec_video=nil
   m_simpleTV.User.TVPortal.codec_audio=nil
   local mess=''
   local ss = m_simpleTV.Control.GetCodecInfo()
   local i=1
	while ss and ss[i] and type(ss[i])=='table' do
     if ss[i]["Type"]~=nil and ss[i]["Codec"]~=nil then
	 local original_id = ss[i]["Original ID"] or i-1
	 local lang, desc = '', ''
	  if (ss[i]["Type"] == 'Audio' or ss[i]["Type"] == 'Subtitle') and ss[i]["Language"] or
	  ss[i]["Type"] == 'Video' and ss[i]["Video resolution"] then
	   if ss[i]["Type"] == 'Video' then lang = ' / ' .. ss[i]["Video resolution"]
	    else lang = ' / ' .. ss[i]["Language"]
	   end
	  end
	  if ss[i]["Description"] then desc = ' / ' .. ss[i]["Description"] end
	  local isactive = Get_isactiv(original_id)
	  if isactive ~= '' then
	   if ss[i]["Type"] == 'Video' then
		m_simpleTV.User.TVPortal.res_video = Get_res(ss[i]["Video resolution"])
		m_simpleTV.User.TVPortal.codec_video = Get_codec(ss[i]["Codec"])
	   end
	   if ss[i]["Type"] == 'Audio' then
		m_simpleTV.User.TVPortal.codec_audio = Get_codec(ss[i]["Codec"])
	   end
	   if ss[i]["Type"] == 'Subtitle' then
		m_simpleTV.User.TVPortal.lang_sub = Get_lang(ss[i]["Language"])
	   end
	  end
      mess = mess .. isactive .. ss[i]["Type"] .. lang .. desc .. ' / ' .. ss[i]["Codec"] .. '\n'
     end
	i = i + 1
   end
   if mess ~= '' then
--        m_simpleTV.OSD.ShowMessage_UTF8(mess,0x0000FF00,10 )
	m_simpleTV.User.TVPortal.mess = mess
   end
end

if m_simpleTV.Control.Reason == 'Stopped' or m_simpleTV.Control.Reason == 'EndReached' then
            m_simpleTV.OSD.ShowMessage_UTF8('')
end
