-- Видеоскрипт для воспроизведения из медиапортала TV (16.09.2023)
-- author west_side, GitHub: https://github.com/west-side-simple
-- Открывает ссылки:
-- portalTV=N&channel=M, где N - номер группы плейлиста TV портала, M - номер канала в группе плейлиста TV портала
-- ===============================================================================================================
if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
local inAdr = m_simpleTV.Control.CurrentAdress
if not inAdr then return end
if not inAdr:match('^portalTV=') then return end

m_simpleTV.Control.ChangeAdress = 'Yes'
local grp = inAdr:match('^portalTV=(%d+)')
local chn = inAdr:match('channel=(%d+)')

local function clean_title(s)
	s = s:gsub('%(.-%)', ' ')
	s = s:gsub('%[.-%]', ' ')
	s = s:gsub('Х/ф', '')
	s = s:gsub('х/ф', '')
	s = s:gsub('М/ф', '')
	s = s:gsub('м/ф', '')
	s = s:gsub('М/с', '')
	s = s:gsub('м/с', '')
	s = s:gsub('Т/с', '')
	s = s:gsub('т/с', '')
	s = s:gsub('%d+%-.-$', ' ')
	s = s:gsub('Сезон.-$', '')
	s = s:gsub('сезон.-$', '')
	s = s:gsub('Серия.-$', '')
	s = s:gsub('серия.-$', '')
	s = s:gsub('%d+ с%-н.-$', '')
	s = s:gsub('%d+ с[%.]*$', '')
	s = s:gsub('%p', ' ')
	s = s:gsub('«', '')
	s = s:gsub('»', '')
	s = s:gsub('^%s*(.-)%s*$', '%1')
	return s
end

local function GetEPG_Id(name)
	if not m_simpleTV.User.TVPortal.EPG then
		local epg = m_simpleTV.Database.GetTable('SELECT * FROM ChannelsEpg ORDER BY Id')
		if epg == nil or epg[1] == nil then
			return false, false
		end
		local t,j = {},1
		for i = 1,#epg do
			local all_names = epg[i].ChName .. ';'
			for w in all_names:gmatch('.-%;') do
				local title = w:gsub('%;','')
				t[j] = {}
				t[j].Name_EPG = title
				t[j].Id_EPG = epg[i].Id
				t[j].Logo_EPG = epg[i].Logo
				j = j + 1
			end
			i = i + 1
		end
		if j == 1 then return false, false end
		m_simpleTV.User.TVPortal.EPG = t -- база EPG с t[j].Name_EPG, t[j].Id_EPG, t[j].Logo_EPG
	end
	for i = 1,#m_simpleTV.User.TVPortal.EPG do
		if m_simpleTV.User.TVPortal.EPG[i].Name_EPG == name then
			return m_simpleTV.User.TVPortal.EPG[i].Id_EPG, m_simpleTV.User.TVPortal.EPG[i].Logo_EPG
		end
	end
	return false, false
end

local function GetEPG_For_Id(id,ch_name,ch_logo)
	local epgTitle,epgDesc,epgTitle1,epgDesc1,epgCategory,epgCategory1,StartFor,EndFor,StartForN,StartForH,StartForM,EndForN,EndForH,EndForM,prtime,timeH,timeM,prendtime
	local curTime = os.date('%Y-%m-%d %X', os.time() + 1)
	local sql = 'SELECT * FROM ChProg WHERE IdChannel=="' .. id .. '"' .. ' AND StartPr <= "' .. curTime .. '" AND EndPr > "' .. curTime .. '"'
	local epgT = m_simpleTV.Database.GetTable(sql)
	if epgT ~= nil and epgT[1] ~= nil then
		epgTitle = epgT[1].Title
		epgDesc  = epgT[1].Desc
		epgCategory = epgT[1].Category
		StartFor = epgT[1].StartPr:gsub('-$--$--$', '')
		EndFor   = epgT[1].EndPr
	end
	local sql1 = 'SELECT * FROM ChProg WHERE IdChannel=="' .. id .. '"' .. ' AND StartPr > "' .. curTime .. '"'
	local epgT1 = m_simpleTV.Database.GetTable(sql1)
	if epgT1 ~= nil and epgT1[1] ~= nil then
		epgTitle1 = epgT1[1].Title
		epgDesc1  = epgT1[1].Desc
		epgCategory1 = epgT1[1].Category
	end
	if StartFor and EndFor then
		StartForN = StartFor:gsub('.- ', '')
		StartForH = StartForN:match('(.-):')
		StartForM = StartForN:match(':(.-):')
		EndForN = EndFor:gsub('.- ', '')
		EndForH = EndForN:match('(.-):')
		EndForM = EndForN:match(':(.-):')
		prtime = (EndForH * 60 + EndForM) - (StartForH * 60 + StartForM)
		if prtime < 0 then prtime = prtime + 24 * 60 end
		timeH = os.date ("%H")
		timeM = os.date ("%M")
		prendtime = (EndForH * 60 + EndForM) - (timeH * 60 + timeM)
		if prendtime < 0 then prendtime = prendtime + 24 * 60 end
	end
	if epgCategory and epgCategory ~= '' then epgCategory = '<font color="#BBBBBB">' .. epgCategory .. '</font><p>' else epgCategory = '' end
	if epgCategory1 and epgCategory1 ~= '' then epgCategory1 = ' (' .. epgCategory1 .. ')' else epgCategory1 = '' end
	local str1, str2 = '<td style="padding: 10px 10px 0px; color: #EBEBEB;" valign="middle"><h3><font color="#00FF7F">' .. ch_name .. '</font></h3>', ''
	local titleepg, yearepg, str3, backgroundepg
	if epgTitle and StartFor and EndFor then
		str1 = str1 .. '<h4><i><font color="#BBBBBB">' .. epgTitle ..  '</font></i><p>' .. epgCategory .. '<font color="#CD7F32">(' .. StartForH .. ':' .. StartForM .. ' - '  .. EndForH .. ':' .. EndForM .. ')</font> <b>' .. prtime .. ' мин.</b></h4>' .. '</td></tr></table>'
		titleepg = clean_title(epgTitle)
	end
	if epgDesc then
		str1 = str1 .. '<table width="100%"><tr><td style="padding: 0px 10px 10px;" valign="middle" width="100%"><h5><font color="#EBEBEB">' .. epgDesc ..  '</font></h5>'
		yearepg = epgDesc:match('^.-(%d%d%d%d).-$') or 0
	end
	if titleepg and yearepg then
		if ch_name:match('KBC') then titleepg = titleepg:gsub(' 4K.-$',''):gsub(' %d%d%d%d$','') end
		str3,backgroundepg = info_fox(titleepg,yearepg,ch_logo)
	end
	local epg_logo
	if backgroundepg and backgroundepg ~= '' and backgroundepg ~= ch_logo then
		epg_logo = backgroundepg
		if m_simpleTV.Control.MainMode == 0 then
			m_simpleTV.Interface.SetBackground({BackColor = 0, PictFileName = epg_logo, TypeBackColor = 0, UseLogo = 3, Once = 1})
		end
	end
	str1 = '<html><body bgcolor="#182633"><table width="100%"><tr><td style="padding: 10px 10px 0px; color: #EBEBEB;">' .. '<img src="' .. (epg_logo or ch_logo) .. '" width="240">' .. '</td>' .. str1
	if epgTitle1 then
		str1 = str1 .. '<p><h4><font color="#CD7F32">далее: </font><i><font color="#BBBBBB">' .. epgTitle1 .. epgCategory1 .. '</font></i></h4>'
	end
	str1 = str1 .. '</td></tr></table></body></html>'
	return epgTitle,str1
end
-----------------------------------

local function GetAdr(adr)
	for i = 1,#m_simpleTV.User.TVPortal.Channel_Of_Group do
		if adr == m_simpleTV.User.TVPortal.Channel_Of_Group[i].Address then
			if not m_simpleTV.User.TVPortal.Channel_Of_Group[i].Address1:match('XXXXXXXXXX') then
				if not m_simpleTV.User.EdemWS then
					m_simpleTV.User.EdemWS = {}
				end
				m_simpleTV.User.EdemWS.channel = nil
				m_simpleTV.User.EdemWS.channel_ott = nil
			end
			return m_simpleTV.User.TVPortal.Channel_Of_Group[i].Address1, m_simpleTV.User.TVPortal.Channel_Of_Group[i].InfoPanelLogo
		end
	end
end
if m_simpleTV.User.TVPortal.Channel_Of_Group == nil then
	start_tv()
end

if m_simpleTV.User.filmix==nil then m_simpleTV.User.filmix={} end
if m_simpleTV.User.rezka==nil then m_simpleTV.User.rezka={} end
if m_simpleTV.User.TMDB==nil then m_simpleTV.User.TMDB={} end
if m_simpleTV.User.collaps==nil then m_simpleTV.User.collaps={} end
if m_simpleTV.User.torrent==nil then m_simpleTV.User.torrent={} end
if m_simpleTV.User.hevc==nil then m_simpleTV.User.hevc={} end
if m_simpleTV.User.AudioWS==nil then m_simpleTV.User.AudioWS={} end
m_simpleTV.User.filmix.CurAddress = nil
m_simpleTV.User.rezka.CurAddress = nil
m_simpleTV.User.TMDB.Id = nil
m_simpleTV.User.TMDB.tv = nil
m_simpleTV.User.collaps.ua = nil
m_simpleTV.User.collaps.kinogo = nil
m_simpleTV.User.torrent.content = nil
m_simpleTV.User.hevc.content = nil
m_simpleTV.User.AudioWS.TrackCash = nil
m_simpleTV.User.westSide.PortalTable = true

local t = m_simpleTV.User.TVPortal.Channel_Of_Group
t.ExtButton0 = {ButtonEnable = true, ButtonName = ' Group ', ButtonScript = 'start_tv()'}
t.ExtButton1 = {ButtonEnable = true, ButtonName = ' TVPortal ', ButtonScript = 'SelectTVPortal()'}
t.ExtParams = {FilterType = 1, AutoNumberFormat = '%1. %2', StopOnError = 0, StopAfterPlay = 0, PlayMode = 2}
	local __,id = m_simpleTV.OSD.ShowSelect_UTF8(m_simpleTV.User.TVPortal.Group_name .. ' - ' .. #t .. ' ch.', tonumber(chn) - 1, t, 10000, 2 + 32)
	id = id or 1
	m_simpleTV.User.TVPortal.Channel_id = tonumber(chn)
	local retAdr, logo = GetAdr(t[tonumber(chn)].Address)

	m_simpleTV.Control.CurrentTitle_UTF8 = t[tonumber(chn)].InfoPanelName:gsub('^.-: ',''):gsub('^.-: ','')
	m_simpleTV.Control.SetTitle(t[tonumber(chn)].InfoPanelName:gsub('^.-: ',''):gsub('^.-: ',''))
			local is_portal = m_simpleTV.Database.GetTable('SELECT * FROM ExtFilter WHERE Name=="PortalTV";')
			local Filter_ID = is_portal[1].Id
			local epg_id,epg_logo = GetEPG_Id(m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].InfoPanelName:gsub('^.-: ',''):gsub('^.-: ',''):gsub('\r',''):gsub(' orig$',''))
			if epg_logo and logo == '' then
				logo = epg_logo
			end
			if logo == '' or logo == nil then
				logo = 'https://raw.githubusercontent.com/west-side-simple/logopacks/main/MoreLogo/westSidePortal.png'
			end
			if epg_id then
				m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].InfoPanelLogo = logo
				epg_title,desc = GetEPG_For_Id(epg_id,m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].InfoPanelName:gsub('^.-: ',''):gsub('^.-: ',''):gsub('\r',''),logo)
				m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].InfoPanelTitle = epg_title
				m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].InfoPanelDesc = desc
			end
			m_simpleTV.Database.ExecuteSql('DELETE FROM Channels WHERE (Channels.Id=' .. m_simpleTV.User.TVPortal.Id .. ');', true)
			if m_simpleTV.Database.ExecuteSql('INSERT INTO Channels ([Id],[ChannelOrder],[Name],[Address],[Group],[ExtFilter],[TypeMedia],[EpgId],[Logo],[LastPosition],[UpdateID],[RawM3UString],[State]) VALUES (' .. m_simpleTV.User.TVPortal.Id .. ',' .. m_simpleTV.User.TVPortal.Id .. ',"' .. m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].InfoPanelName:gsub('^.-: ',''):gsub('^.-: ',''):gsub('\r','') .. '","portalTV=' .. m_simpleTV.User.TVPortal.Group_id .. '&channel=' .. tonumber(chn) .. '",' .. 0 .. ',' .. Filter_ID ..',' .. 0 .. ',"' .. (epg_id or 'not epg') .. '","' .. logo .. '",' .. 0 .. ',"PortalTV",' .. "'" .. (m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].RawM3UString or '') .. "'," .. m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].State .. ');') then
				m_simpleTV.PlayList.Refresh()
			end
			if m_simpleTV.Timeshift.EpgOffsetRequest and m_simpleTV.Timeshift.EpgOffsetRequest > 0 then
				m_simpleTV.User.TVPortal.EpgOffsetRequest = m_simpleTV.Timeshift.EpgOffsetRequest
			else
				m_simpleTV.User.TVPortal.EpgOffsetRequest = 0
			end
	m_simpleTV.Control.ChangeAddress = 'No'
	m_simpleTV.Control.CurrentAddress = retAdr
	m_simpleTV.Control.SetNewAddressT({address = retAdr, timeshiftOffset = m_simpleTV.User.TVPortal.EpgOffsetRequest})
