-- script for creating an EPG plate 14.10.2023
-- author west_side GITHUB https://github.com/west-side-simple
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
AddFileToExecute('events', m_simpleTV.MainScriptDir .. "user/westSide_EPG/events.lua")
local t = m_simpleTV.Database.GetTable('SELECT * FROM ChannelsEpg WHERE (Id="NOEPG by WS");')
if t == nil or t[1] == nil then
	m_simpleTV.Database.ExecuteSql('INSERT INTO ChannelsEpg ([Id],[ChName],[Source],[Logo]) VALUES ("NOEPG by WS","NOEPG by WS","NOEPG by WS","");')
	m_simpleTV.EPG.Refresh()
end
local end_EPG = os.time() - (os.date("%H",os.time())*60*60 + os.date("%M",os.time())*60 + os.date("%S",os.time())) - os.date("%w",os.time())*24*60*60 + 8*24*60*60 -- UTC время 00:00 понедельника следующей недели
local t1 = m_simpleTV.Database.GetTable('SELECT * FROM ChProg WHERE (IdChannel="NOEPG by WS" AND EndPr = "' .. end_EPG .. '");')
if t1 == nil or t1[1] == nil then
	m_simpleTV.Database.ExecuteSql('DELETE FROM ChProg WHERE (IdChannel="NOEPG by WS");', true)
	local start_EPG = os.time() - (os.date("%H",os.time())*60*60 + os.date("%M",os.time())*60 + os.date("%S",os.time())) - os.date("%w",os.time())*24*60*60 - 6*24*60*60 -- UTC время 00:00 понедельника прошедшей недели
	local EPG = { -- EPG на сутки
		{0,1,"ночное вещание"},
		{1,2,"ночное вещание"},
		{2,3,"ночное вещание"},
		{3,4,"ночное вещание"},
		{4,5,"ночное вещание"},
		{5,6,"ночное вещание"},
		{6,7,"утреннее вещание"},
		{7,8,"утреннее вещание"},
		{8,9,"утреннее вещание"},
		{9,10,"утреннее вещание"},
		{10,11,"утреннее вещание"},
		{11,12,"утреннее вещание"},
		{12,13,"дневное вещание"},
		{13,14,"дневное вещание"},
		{14,15,"дневное вещание"},
		{15,16,"дневное вещание"},
		{16,17,"дневное вещание"},
		{17,18,"дневное вещание"},
		{18,19,"вечернее вещание"},
		{19,20,"вечернее вещание"},
		{20,21,"вечернее вещание"},
		{21,22,"вечернее вещание"},
		{22,23,"вечернее вещание"},
		{23,24,"вечернее вещание"},
	}
	local logo = m_simpleTV.MainScriptDir_UTF8 .. 'user/westSide_EPG/img/Logo_PORTALTV_WS.png'
	m_simpleTV.Database.ExecuteSql('START TRANSACTION;/*ChProg*/')
	for i = 1,14 do
		local start_time = tonumber(start_EPG) + (i - 1)*24*60*60
		for j = 1,24 do
			local StartPr = tonumber(start_time) + tonumber(EPG[j][1])*60*60
			local EndPr = tonumber(start_time) + tonumber(EPG[j][2])*60*60
			StartPr = os.date('%Y-%m-%d %X', StartPr)
			EndPr = os.date('%Y-%m-%d %X', EndPr)
			local Title = EPG[j][3]
			m_simpleTV.Database.ExecuteSql('INSERT  INTO ChProg (IdChannel, StartPr, EndPr, Title, Desc, HaveDesc, Category, IconUrl) VALUES ("NOEPG by WS","' .. StartPr .. '","' .. EndPr .. '","' .. Title .. '","Source: NOEPG by WS","1","NOEPG by WS","' .. logo .. '");', true)
			j = j + 1
		end
		i = i + 1
	end
	m_simpleTV.Database.ExecuteSql('COMMIT;/*ChProg*/')
	m_simpleTV.EPG.Refresh()
end
m_simpleTV.Database.ExecuteSql([[UPDATE Channels SET EpgId="NOEPG by WS" WHERE ((Channels.Id<268435455)
                             AND (Channels.TypeMedia=0)
                             AND (Channels.EpgId = "" OR Channels.EpgId IS NULL)
                             AND (Channels.Title IS NULL OR trim(Channels.Title) = ""));]])

m_simpleTV.PlayList.Refresh()