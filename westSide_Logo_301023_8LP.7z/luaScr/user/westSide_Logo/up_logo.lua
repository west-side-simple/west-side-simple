local function GetLogo(name, author)
		m_simpleTV.Database.ExecuteSql("ATTACH DATABASE '" .. m_simpleTV.Common.GetMainPath(1) .. "/logopack.db' AS logopack;", false)
		local logopack = m_simpleTV.Database.GetTable('SELECT * FROM logopackchannels WHERE logopackchannels.AuthorLogopack = "' .. author .. '"')

		if logopack == nil or logopack[1] == nil then
			return false
		end

		for i = 1,#logopack do
			local all_names = logopack[i].NameChannels .. ';'
			for w in all_names:gmatch('.-%;') do
				local title = w:gsub('%;','')
				local logo = logopack[i].LogoChannels
				if title:gsub('%-','%-'):gsub('%+',''):gsub(' HD','') == name:gsub('%-','%-'):gsub('%+',''):gsub(' HD','') then
					return logo
				end
			end
			i = i + 1
		end
	return false
end

function select_logopack(extFilterId,Filter_Name)

	local t = {}

	t[1] = {}
	t[1].Id = 1
	t[1].Name = '1OTT'
	t[1].Action = ''

	t[2] = {}
	t[2].Id = 2
	t[2].Name = 'EDEM dark'
	t[2].Action = ''

	t[3] = {}
	t[3].Id = 3
	t[3].Name = 'EDEM transparent'
	t[3].Action = ''

	t[4] = {}
	t[4].Id = 4
	t[4].Name = 'Glanz'
	t[4].Action = ''

	t[5] = {}
	t[5].Id = 5
	t[5].Name = 'Gabbarit'
	t[5].Action = ''

	t[6] = {}
	t[6].Id = 6
	t[6].Name = 'IPTV ONE'
	t[6].Action = ''

	t[7] = {}
	t[7].Id = 7
	t[7].Name = 'TROYA'
	t[7].Action = ''

	t[8] = {}
	t[8].Id = 8
	t[8].Name = 'Mirror Glass'
	t[8].Action = ''

	local ret,id = m_simpleTV.OSD.ShowSelect_UTF8('Select Logopack' ,0,t,10000,1+4+8+2)
		if ret == -1 or not id then
			return
		end
		if ret == 1 then

			local Channels_Filter = m_simpleTV.Database.GetTable('SELECT Id, Name FROM Channels WHERE ((Channels.ExtFilter=' .. tonumber(extFilterId) .. ') AND (Channels.Id<268435455)); ')
			if Channels_Filter == nil or Channels_Filter[1] == nil then
				return
			end

			local j = 1
			for i = 1, #Channels_Filter do
				local channel_id = Channels_Filter[i].Id
				local channel_name = Channels_Filter[i].Name
				local channel_logo = GetLogo(channel_name, t[id].Name)
				m_simpleTV.OSD.ShowMessageT({imageParam = 'vSizeFactor="1" src="' .. m_simpleTV.MainScriptDir .. 'user/westSide_Logo/img/palette-custom.png"', text = i .. '. ' .. Filter_Name .. ' Update Logopack: ' .. t[id].Name, color = ARGB(255, 255, 255, 0), showTime = 1000 * 3})
				if channel_logo and channel_id then
					m_simpleTV.Database.ExecuteSql('UPDATE Channels SET Logo="' .. channel_logo .. '" WHERE (Channels.Id = ' .. channel_id .. '); ')
					j = j + 1
				end
				i = i + 1
			end

			if j > 1 then
				m_simpleTV.PlayList.Refresh()
			end
		end
end
local _ , _ , extFilterId = ...
	local Filter_Data = m_simpleTV.Database.GetTable('SELECT Name FROM ExtFilter WHERE id=' .. (extFilterId or '').. '; ')
	local Filter_Name = ''
	if Filter_Data and Filter_Data[1] then
	   Filter_Name = Filter_Data[1].Name
	end
select_logopack(extFilterId, Filter_Name)
