--TV Portal events 04.11.23

if m_simpleTV.Control.Reason=='addressready'  then
	if m_simpleTV.User.TVPortal.PortalShowWindowId then
		m_simpleTV.Interface.RemoveExtMenu(m_simpleTV.User.TVPortal.PortalShowWindowId)
	end
	if m_simpleTV.User.TVPortal.PortalShowAdd then
		m_simpleTV.Interface.RemoveExtMenu(m_simpleTV.User.TVPortal.PortalShowAdd)
	end
	if m_simpleTV.User.TVPortal.PortalTable~=nil then
		local t={}
		t.utf8 = true
		t.name = '-'
		t.luastring = ''
		t.lua_as_scr = false
		t.submenu = 'TVPortal WS'
		t.imageSubmenu = ''
		--t.key = string.byte('I')
		t.ctrlkey = 0
		t.location = 0
		t.image=''
		m_simpleTV.User.TVPortal.PortalSeparatorId = m_simpleTV.Interface.AddExtMenuT(t)
		local t={}
		t.utf8 = true
		t.name = 'TVPortal Info Window'
		t.luastring = 'GetPortalTableForTVPortal()'
		t.lua_as_scr = true
		t.submenu = 'TVPortal WS'
		t.imageSubmenu = m_simpleTV.MainScriptDir_UTF8 .. 'user/portaltvWS/img/portaltv.png'
		t.key = string.byte('I')
		t.ctrlkey = 0
		t.location = 0
		t.image= m_simpleTV.MainScriptDir_UTF8 .. 'user/portaltvWS/img/fw_box_t3.png'
		m_simpleTV.User.TVPortal.PortalShowWindowId = m_simpleTV.Interface.AddExtMenuT(t)
		local t={}
		t.utf8 = true
		t.name = 'Add to FAV PlaylistT'
		t.luastring = 'AddPortalTVAddressToPlaylist()'
		t.lua_as_scr = true
		t.submenu = 'TVPortal WS'
		t.imageSubmenu = m_simpleTV.MainScriptDir_UTF8 .. 'user/portaltvWS/img/portaltv.png'
		t.key = string.byte('I')
		t.ctrlkey = 1
		t.location = 0
		t.image= m_simpleTV.MainScriptDir_UTF8 .. 'user/portaltvWS/img/fw_box_t2.png'
		m_simpleTV.User.TVPortal.PortalShowAdd = m_simpleTV.Interface.AddExtMenuT(t)
	end
end

if m_simpleTV.Control.Reason=='Stopped' or m_simpleTV.Control.Reason=='Error' then
	m_simpleTV.User.TVPortal.PortalTable=nil
	if m_simpleTV.User.TVPortal.PortalShowWindowId then
		m_simpleTV.Interface.RemoveExtMenu(m_simpleTV.User.TVPortal.PortalShowWindowId)
	end
	if m_simpleTV.User.TVPortal.PortalShowAdd then
		m_simpleTV.Interface.RemoveExtMenu(m_simpleTV.User.TVPortal.PortalShowAdd)
	end
end
