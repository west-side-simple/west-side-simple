-- WS Logopack plugin script for Playlist
-- author: west_side 23.01.24

local function GetLogo(name, author)
	m_simpleTV.Database.ExecuteSql("ATTACH DATABASE '" .. m_simpleTV.Common.GetMainPath(1) .. "/logopack.db' AS logopack;", false)
	local logopack = m_simpleTV.Database.GetTable('SELECT * FROM logopackchannels WHERE (logopackchannels.AuthorLogopack = "' .. author .. '" AND (logopackchannels.NameChannels LIKE "' .. name .. ';%" OR logopackchannels.NameChannels LIKE "%;' .. name .. ';%" OR logopackchannels.NameChannels LIKE "%;' .. name .. '" OR logopackchannels.NameChannels LIKE "' .. name .. '" ))')

	if logopack == nil or logopack[1] == nil then
		return false
	else
		return logopack[1].LogoChannels:gsub('https://picon%.pp%.ua/','https://epgx.site/p/')
	end
end

local function GetNames(name, author)
	m_simpleTV.Database.ExecuteSql("ATTACH DATABASE '" .. m_simpleTV.Common.GetMainPath(1) .. "/logopack.db' AS logopack;", false)
	local logopack = m_simpleTV.Database.GetTable('SELECT * FROM logopackchannels WHERE (logopackchannels.AuthorLogopack = "' .. author .. '" AND (logopackchannels.NameChannels LIKE "' .. name .. ';%" OR logopackchannels.NameChannels LIKE "%;' .. name .. ';%" OR logopackchannels.NameChannels LIKE "%;' .. name .. '" OR logopackchannels.NameChannels LIKE "' .. name .. '" ))')
	if logopack == nil or logopack[1] == nil then
		return false
	else
		return logopack[1].NameChannels
	end
end

function select_logopack_for_selected()

-- можно закомментировать неиспользуемые логопаки

	local t1 = {

	'🧹 очистить',
	'1OTT',
	'EDEM dark',
	'EDEM transparent',
	'Gabbarit',
	'IPTV ONE',
	'TROYA',
	'Mirror Glass',
	'mini by AnZo',
	'ColorPic',
				}

	local t = {}

	for i = 1,#t1 do
		t[i] = {}
		t[i].Id = i
		t[i].Name = t1[i]
	end

	local ret,id = m_simpleTV.OSD.ShowSelect_UTF8('Select Logopack' ,0,t,10000,1+4+8+2)
		if ret == -1 or not id then
			return
		end
		if ret == 1 then

			local Channels_Selected = m_simpleTV.PlayList.GetSelectedItems()

			if Channels_Selected == nil or Channels_Selected[1] == nil then
				return
			end

			local j, k = 1, 1
			for i = 1, #Channels_Selected do

				local Channels_Filter = m_simpleTV.Database.GetTable('SELECT Id, Name FROM Channels WHERE (Channels.Id=' .. tonumber(Channels_Selected[i]) .. '); ')
				local channel_id = Channels_Filter[1].Id
				local channel_name = Channels_Filter[1].Name
				if id == 1 then
					m_simpleTV.OSD.ShowMessageT({imageParam = 'vSizeFactor="1" src="' .. m_simpleTV.MainScriptDir .. 'user/westSide_Logo/img/palette-custom.png"', text = i .. '. Cleaning Logopack', color = ARGB(255, 255, 255, 0), showTime = 1000 * 3})
					m_simpleTV.Database.ExecuteSql('UPDATE Channels SET Logo="" WHERE (Channels.Id = ' .. channel_id .. '); ')
					j = j + 1
				else
					local channel_logo
					local channel_names_in_FILTER = GetNames(channel_name:gsub(' $',''):gsub(' orig$',''):gsub(' 50$',''):gsub('^ ',''), 'Gabbarit')
					if not channel_names_in_FILTER then
						channel_logo = GetLogo(channel_name:gsub(' $',''):gsub(' orig$',''):gsub(' 50$',''):gsub('^ ',''), t[id].Name)
						if channel_logo and channel_id then
							m_simpleTV.Database.ExecuteSql('UPDATE Channels SET Logo="' .. channel_logo .. '" WHERE (Channels.Id = ' .. channel_id .. '); ')
							j = j + 1
							k = k + 1
						end
					else
						channel_names_in_FILTER = channel_names_in_FILTER .. ';'
						for w in channel_names_in_FILTER:gmatch('.-%;') do
							local channel_name_from_FILTER = w:match('(.-)%;')
							channel_logo = GetLogo(channel_name_from_FILTER:gsub(' $',''):gsub(' orig$',''):gsub(' 50$',''):gsub('^ ',''), t[id].Name)
							if channel_logo then break end
						end
						if channel_logo and channel_id then
							m_simpleTV.Database.ExecuteSql('UPDATE Channels SET Logo="' .. channel_logo .. '" WHERE (Channels.Id = ' .. channel_id .. '); ')
							j = j + 1
						end
						k = k + 1
					end
					m_simpleTV.OSD.ShowMessageT({imageParam = 'vSizeFactor="1" src="' .. m_simpleTV.MainScriptDir .. 'user/westSide_Logo/img/palette-custom.png"', text = i .. '. Update Logopack for Selected Channels 🔄 ' .. t[id].Name .. '\n ● всего в базе: ' .. k-1 .. '\n ● в логопаке: ' .. j-1, color = ARGB(255, 255, 255, 0), showTime = 1000 * 10})
				end
				i = i + 1
			end

			if j > 1 then
				m_simpleTV.PlayList.Refresh()
			end
		end
end

select_logopack_for_selected()
