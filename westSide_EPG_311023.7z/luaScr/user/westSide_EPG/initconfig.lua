-- ini for EPG WS plugin
-- author west_side 31.10.23

	local t ={}
		t.name = 'EPG WS'
		t.htmlUri = m_simpleTV.MainScriptDir_UTF8 .. 'user/westSide_EPG/configDialog.html'
		t.luaUri  = 'user/westSide_EPG/configDialog.lua'
		t.iconUri  = m_simpleTV.MainScriptDir_UTF8 .. 'user/westSide_EPG/img/noepg.png'

	m_simpleTV.Config.AddExtDialogT(t)