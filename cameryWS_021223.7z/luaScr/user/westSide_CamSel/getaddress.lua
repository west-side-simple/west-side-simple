--getaddress westSide CamSel (02.12.23)

if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
local inAdr = m_simpleTV.Control.CurrentAdress
if not inAdr then return end
if not inAdr:match('^camera=') then return end

m_simpleTV.Control.ChangeAdress = 'Yes'
local cur_id = inAdr:match('^camera=(%d+)')

if m_simpleTV.User==nil then m_simpleTV.User={} end
if m_simpleTV.User.CamSel==nil then m_simpleTV.User.CamSel={} end

if not m_simpleTV.User.CamSel or not m_simpleTV.User.CamSel[1] then
	Cameras_stream()
end

local function check_adr(url)
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:91.0) Gecko/20100101 Firefox/91.0')
	if not session then
		return
	end
	m_simpleTV.Http.SetTimeout(session, 6000)
	local url = url
	local rc, answer = m_simpleTV.Http.Request(session, {url = url})
	if rc~=200 then
		return false
	end
	return true
end

local function Get_adr(id)
	local t = m_simpleTV.User.CamSel
	if not t or not t[1] then
		return false
	end
	for i = 1,#t do
		if t[i].Address == 'camera=' .. id then
			return t[i].Address1, t[i].InfoPanelLogo
		end
	end
	return false
end

local retAdr, logo = Get_adr(cur_id)
local check = check_adr(retAdr)
if not check or check == false then
	Cameras_stream()
	m_simpleTV.Common.Sleep(5000)
	m_simpleTV.OSD.ShowMessageT({imageParam = 'vSizeFactor="2.5" src="' .. m_simpleTV.Common.GetMainPath(2) .. './luaScr/user/westSide_CamSel/camera.png"', text = 'Ожидание адреса.' , showTime = 5000,0xFF00,3})
	retAdr, logo = Get_adr(cur_id)
end
m_simpleTV.Control.EventPlayingInterval=5000
m_simpleTV.User.CamSel.CurAddress = cur_id
m_simpleTV.Control.ChangeChannelLogo(logo , m_simpleTV.Control.ChannelID)
m_simpleTV.Control.SetNewAddress(retAdr)
