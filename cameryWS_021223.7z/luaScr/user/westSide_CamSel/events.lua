--events westSide CamSel (02.12.23)

if m_simpleTV.Control.CurrentAddress==nil then return end
if m_simpleTV.User==nil then m_simpleTV.User={} end
if m_simpleTV.User.CamSel==nil then m_simpleTV.User.CamSel={} end
local cam_id = m_simpleTV.Control.CurrentAddress:match('https://sochi%.camera:8443/cam_(%d+)/index%.m3u8')
if not cam_id then return end
--m_simpleTV.OSD.ShowMessageT({imageParam = 'vSizeFactor="2.5" src="' .. m_simpleTV.Common.GetMainPath(2) .. './luaScr/user/westSide_CamSel/camera.png"', text = 'Camera ' .. cam_id , showTime = 5000,0xFF00,3})
local function check_addr()
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:91.0) Gecko/20100101 Firefox/91.0')
	if not session then
		return
	end
	m_simpleTV.Http.SetTimeout(session, 12000)
	local url = m_simpleTV.Control.CurrentAddress
	local rc, answer = m_simpleTV.Http.Request(session, {url = url})
	if rc~=200 then
		return false
	end
	return true
end

local function Get_addr(id)
	local t = m_simpleTV.User.CamSel
	if not t or not t[1] then
		return false
	end
	for i = 1,#t do
		if tonumber(t[i].Address2) == tonumber(id) then
			return t[i].Address1
		end
	end
	return false
end
if m_simpleTV.Control.Reason=='Playing' then
	m_simpleTV.Control.EventPlayingInterval=5000
	local check = check_addr()
	if not check or check == false then
		m_simpleTV.OSD.ShowMessageT({imageParam = 'vSizeFactor="2.5" src="' .. m_simpleTV.Common.GetMainPath(2) .. './luaScr/user/westSide_CamSel/camera.png"', text = 'Ожидание адреса.' , showTime = 5000,0xFF00,3})
		Cameras_stream()
		m_simpleTV.Common.Sleep(5000)
		local retAdr = Get_addr(cam_id)
		m_simpleTV.Control.SetNewAddress(retAdr)
	end
end
