--startup westSide CamSel (02.12.23)

AddFileToExecute('events', m_simpleTV.MainScriptDir .. "user/westSide_CamSel/events.lua")
AddFileToExecute('getaddress', m_simpleTV.MainScriptDir .. "user/westSide_CamSel/getaddress.lua")

if m_simpleTV.User==nil then m_simpleTV.User={} end
if m_simpleTV.User.CamSel==nil then m_simpleTV.User.CamSel={} end

function Cameras_stream()
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:91.0) Gecko/20100101 Firefox/91.0')
	if not session then
		return
	end
	m_simpleTV.Http.SetTimeout(session, 12000)
	local url = 'https://sochi.camera/vse-kamery/?format=json' ..
	'&sort=camId-up' -- can be changed: &sort=name-up or &sort=camId-up
	local rc, answer = m_simpleTV.Http.Request(session, {url = url})
	if rc~=200 then
		return
	end
	require('json')
	answer = answer:gsub('(%[%])', '"nil"'):gsub('\\"', ''):gsub('<.->',''):gsub('\\n', ' '):gsub('\\r', ''):gsub('%(', ' '):gsub('%)', ''):gsub('^.-%{', '{')
--	debug_in_file(answer,'c://1/jsc.txt')
	local tab = json.decode(answer)
	if not tab or not tab.items or not tab.items[1] or not tab.items[1].id or not tab.items[1].cam_id then
		return
	end
	local t, i = {}, 1
	while true do
		if not tab.items[i] then
			break
		end
		t[i]={}
		local id, cam_id, name, logo, desc, adr = tab.items[i].id, tab.items[i].cam_id, tab.items[i].name, tab.items[i].imagesUrl.small, tab.items[i].description, (tab.items[i].hd_url or tab.items[i].video_url)
		logo = 'https://sochi.camera' .. logo
		if desc == '' then desc = 'без описания' end
		t[i].Id = i
		t[i].Name = name
		t[i].Address = 'camera=' .. id
		t[i].Address1 = adr
		t[i].Address2 = cam_id
		t[i].InfoPanelLogo = logo
		t[i].InfoPanelName = name .. ' | ID=' .. id .. ' | CAMID=' .. cam_id
		t[i].InfoPanelShowTime = 10000
		t[i].InfoPanelTitle = desc:gsub('%&nbsp%;',' '):gsub('%&raquo%;','»'):gsub('%&laquo%;','«')
		i=i+1
	end
--	m_simpleTV.OSD.ShowMessageT({imageParam = 'vSizeFactor="2.5" src="' .. m_simpleTV.Common.GetMainPath(2) .. './luaScr/user/westSide_CamSel/camera.png"', text = 'Всего камер: ' .. #t , showTime = 5000,0xFF00,3})
	m_simpleTV.User.CamSel = t
end

function Cameras_select()
	if not m_simpleTV.User.CamSel or not m_simpleTV.User.CamSel[1] then
		Cameras_stream()
	end
	local t = m_simpleTV.User.CamSel
	local AutoNumberFormat, FilterType
	if #t > 4 then
		AutoNumberFormat = '%1. %2'
		FilterType = 1
	else
		AutoNumberFormat = ''
		FilterType = 2
	end
	local cur_id = 1
	if m_simpleTV.User.CamSel.CurAddress then
		for i = 1,#t do
			if t[i].Address == 'camera=' .. m_simpleTV.User.CamSel.CurAddress then
				cur_id = i
			end
		end
	end
	t.ExtParams = {FilterType = FilterType, AutoNumberFormat = AutoNumberFormat}
	local ret,id = m_simpleTV.OSD.ShowSelect_UTF8('ВебКамерыСочи: ' .. #t,tonumber(cur_id) - 1,t,10000,1+4+8+2)
	if ret == -1 or not id then
		return
	end
	if ret == 1 then
		m_simpleTV.Control.PlayAddressT({address= t[id].Address, title=t[id].InfoPanelName})
	end
end

-- Add ext Menu Select
	local tp = {}
	tp.utf8 = true -- string coding
	tp.name = 'Cameras select'
	tp.luastring = 'Cameras_select()'
	tp.lua_as_scr = true
	tp.key = string.byte('S') -- can be changed
	tp.ctrlkey = 4 -- modifier keys (type: number) (available value: 0 - not modifier keys, 1 - CTRL, 2 - SHIFT, 3 - CTRL + SHIFT )
	tp.location = 0 --(0) - 0 - in main menu, 1 - in playlist menu, -1 all
	tp.image = m_simpleTV.MainScriptDir_UTF8 .. '/user/westSide_CamSel/camera.png'
	m_simpleTV.Interface.AddExtMenuT(tp)
