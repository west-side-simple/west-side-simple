-- config for dialog window EPG_WS plugin
-- author west_side 31.10.23

	if m_simpleTV.User==nil then m_simpleTV.User={} end
	if m_simpleTV.User.EPG_WS==nil then m_simpleTV.User.EPG_WS={} end

	local function getConfigVal(key)
		return m_simpleTV.Config.GetValue(key,"EPG_WS.ini")
	end

	local function setConfigVal(key,val)
		m_simpleTV.Config.SetValue(key,val,"EPG_WS.ini")
	end

	function OnNavigateComplete(Object)
		local value
		value= getConfigVal("EPG_WS_Enable") or 1
		m_simpleTV.Dialog.SetCheckBoxValue(Object,'EPG_WS_Enable',value)
	end

	function OnOk(Object)
		local value
		value=m_simpleTV.Dialog.GetCheckBoxValue(Object,'EPG_WS_Enable')
		if value ~= nil then
			setConfigVal("EPG_WS_Enable",value)
			m_simpleTV.User.EPG_WS.Use = 1
			if tonumber(value) == 0 then
				m_simpleTV.User.EPG_WS.Use = 0
			end
		end
	end
