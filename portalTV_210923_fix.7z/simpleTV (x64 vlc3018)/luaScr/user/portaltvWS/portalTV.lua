-- Видеоскрипт для воспроизведения из медиапортала TV (21.09.2023)
-- author west_side, GitHub: https://github.com/west-side-simple
-- Открывает ссылки:
-- portalTV=N&channel=M, где N - номер группы плейлиста TV портала, M - номер канала в группе плейлиста TV портала
-- ===============================================================================================================

if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
local inAdr = m_simpleTV.Control.CurrentAdress
if not inAdr then return end
if not inAdr:match('^portalTV=') then return end

m_simpleTV.Control.ChangeAdress = 'Yes'
local grp = inAdr:match('^portalTV=(%d+)')
local chn = inAdr:match('channel=(%d+)')

local function clean_title(s)
	s = s:gsub('%(.-%)', ' ')
	s = s:gsub('%[.-%]', ' ')
	s = s:gsub('Х/ф', '')
	s = s:gsub('х/ф', '')
	s = s:gsub('М/ф', '')
	s = s:gsub('м/ф', '')
	s = s:gsub('М/с', '')
	s = s:gsub('м/с', '')
	s = s:gsub('Т/с', '')
	s = s:gsub('т/с', '')
	s = s:gsub('%d+%-.-$', ' ')
	s = s:gsub('Сезон.-$', '')
	s = s:gsub('сезон.-$', '')
	s = s:gsub('Серия.-$', '')
	s = s:gsub('серия.-$', '')
	s = s:gsub('%d+ с%-н.-$', '')
	s = s:gsub('%d+ с[%.]*$', '')
	s = s:gsub('%p', ' ')
	s = s:gsub('«', '')
	s = s:gsub('»', '')
	s = s:gsub('^%s*(.-)%s*$', '%1')
	return s
end

local function GetEPG_Id(name)
	if not m_simpleTV.User.TVPortal.EPG then
		local epg = m_simpleTV.Database.GetTable('SELECT * FROM ChannelsEpg ORDER BY Id')
		if epg == nil or epg[1] == nil then
			return false, false
		end
		local t,j = {},1
		for i = 1,#epg do
			local all_names = epg[i].ChName .. ';'
			for w in all_names:gmatch('.-%;') do
				local title = w:gsub('%;','')
				t[j] = {}
				t[j].Name_EPG = title
				t[j].Id_EPG = epg[i].Id
				t[j].Logo_EPG = epg[i].Logo
				j = j + 1
			end
			i = i + 1
		end
		if j == 1 then return false, false end
		m_simpleTV.User.TVPortal.EPG = t -- база EPG с t[j].Name_EPG, t[j].Id_EPG, t[j].Logo_EPG
	end
	for i = 1,#m_simpleTV.User.TVPortal.EPG do
		if m_simpleTV.User.TVPortal.EPG[i].Name_EPG == name then
			return m_simpleTV.User.TVPortal.EPG[i].Id_EPG, m_simpleTV.User.TVPortal.EPG[i].Logo_EPG
		end
	end
	return false, false
end

local function GetEPG_For_Id(id,ch_name,ch_logo)
	local epgTitle,epgDesc,epgTitle1,epgDesc1,epgCategory,epgCategory1,StartFor,EndFor,StartForN,StartForH,StartForM,EndForN,EndForH,EndForM,prtime,timeH,timeM,prendtime
	local curTime = os.date('%Y-%m-%d %X', os.time() + 1)
	if m_simpleTV.User.TVPortal.EpgOffsetRequest then
		curTime = os.date('%Y-%m-%d %X', os.time() + 1 - tonumber(m_simpleTV.User.TVPortal.EpgOffsetRequest)/1000)
	end
--	debug_in_file(curTime .. ': ' .. (os.time() + 1) .. ' - ' .. (m_simpleTV.User.TVPortal.EpgOffsetRequest or 0) .. '\n','c://1/offset.txt')
	local sql = 'SELECT * FROM ChProg WHERE IdChannel=="' .. id .. '"' .. ' AND StartPr <= "' .. curTime .. '" AND EndPr > "' .. curTime .. '"'
	local epgT = m_simpleTV.Database.GetTable(sql)
	if epgT ~= nil and epgT[1] ~= nil then
		epgTitle = epgT[1].Title
		epgDesc  = epgT[1].Desc
		epgCategory = epgT[1].Category
		StartFor = epgT[1].StartPr:gsub('-$--$--$', '')
		EndFor   = epgT[1].EndPr
	end
	local sql1 = 'SELECT * FROM ChProg WHERE IdChannel=="' .. id .. '"' .. ' AND StartPr > "' .. curTime .. '"'
	local epgT1 = m_simpleTV.Database.GetTable(sql1)
	if epgT1 ~= nil and epgT1[1] ~= nil then
		epgTitle1 = epgT1[1].Title
		epgDesc1  = epgT1[1].Desc
		epgCategory1 = epgT1[1].Category
	end
	if StartFor and EndFor then
		StartForN = StartFor:gsub('.- ', '')
		StartForH = StartForN:match('(.-):')
		StartForM = StartForN:match(':(.-):')
		EndForN = EndFor:gsub('.- ', '')
		EndForH = EndForN:match('(.-):')
		EndForM = EndForN:match(':(.-):')
		prtime = (EndForH * 60 + EndForM) - (StartForH * 60 + StartForM)
		if prtime < 0 then prtime = prtime + 24 * 60 end
		timeH = os.date ("%H")
		timeM = os.date ("%M")
		prendtime = (EndForH * 60 + EndForM) - (timeH * 60 + timeM)
		if prendtime < 0 then prendtime = prendtime + 24 * 60 end
	end
	if epgCategory and epgCategory ~= '' then epgCategory = '<font color="#BBBBBB">' .. epgCategory .. '</font><p>' else epgCategory = '' end
	if epgCategory1 and epgCategory1 ~= '' then epgCategory1 = ' (' .. epgCategory1 .. ')' else epgCategory1 = '' end
	local str1, str2 = '<td style="padding: 10px 10px 0px; color: #EBEBEB;" valign="middle"><h3><font color="#00FF7F">' .. ch_name .. '</font></h3>', ''
	local titleepg, yearepg, str3, backgroundepg
	if epgTitle and StartFor and EndFor then
		str1 = str1 .. '<h4><i><font color="#BBBBBB">' .. epgTitle ..  '</font></i><p>' .. epgCategory .. '<font color="#CD7F32">(' .. StartForH .. ':' .. StartForM .. ' - '  .. EndForH .. ':' .. EndForM .. ')</font> <b>' .. prtime .. ' мин.</b></h4>' .. '</td></tr></table>'
		titleepg = clean_title(epgTitle)
	end
	if epgDesc then
		str1 = str1 .. '<table width="100%"><tr><td style="padding: 0px 10px 10px;" valign="middle" width="100%"><h5><font color="#EBEBEB">' .. epgDesc ..  '</font></h5>'
		yearepg = titleepg:match('^.-(%d%d%d%d).-$') or epgDesc:match('^.-(%d%d%d%d).-$') or 0
	end
	if titleepg and yearepg then
		if ch_name:match('KBC') then titleepg = titleepg:gsub(' 4K.-$',''):gsub(' %d%d%d%d$','') end
--		debug_in_file(titleepg .. ' / ' .. yearepg .. '\n','c://1/foxinfo.txt')
		str3,backgroundepg = info_fox(titleepg:gsub(' %(.-$',''):gsub(' %d%d%d%d.-$',''),yearepg,ch_logo)
	end
	local epg_logo
	if backgroundepg and backgroundepg ~= '' and backgrounde ~= ch_logo then
		epg_logo = backgroundepg
		if m_simpleTV.Control.MainMode == 0 then
			m_simpleTV.Interface.SetBackground({BackColor = 0, PictFileName = epg_logo, TypeBackColor = 0, UseLogo = 3, Once = 1})
		end
	end
	str1 = '<html><body bgcolor="#182633"><table width="100%"><tr><td style="padding: 10px 10px 0px; color: #EBEBEB;">' .. '<img src="' .. (epg_logo or ch_logo) .. '" width="240">' .. '</td>' .. str1
	if epgTitle1 then
		str1 = str1 .. '<p><h4><font color="#CD7F32">далее: </font><i><font color="#BBBBBB">' .. epgTitle1 .. epgCategory1 .. '</font></i></h4>'
	end
	str1 = str1 .. '</td></tr></table></body></html>'
	return epgTitle,str1
end
-----------------------------------

local function GetAdr(adr)
	for i = 1,#m_simpleTV.User.TVPortal.Channel_Of_Group do
		if adr == m_simpleTV.User.TVPortal.Channel_Of_Group[i].Address then
			if not m_simpleTV.User.TVPortal.Channel_Of_Group[i].Address1:match('XXXXXXXXXX') then
				if not m_simpleTV.User.EdemWS then
					m_simpleTV.User.EdemWS = {}
				end
				m_simpleTV.User.EdemWS.channel = nil
				m_simpleTV.User.EdemWS.channel_ott = nil
			end
			return m_simpleTV.User.TVPortal.Channel_Of_Group[i].Address1, m_simpleTV.User.TVPortal.Channel_Of_Group[i].InfoPanelLogo
		end
	end
end

function GetPortalTableForTVPortal()
	local t = m_simpleTV.User.TVPortal.Channel_Of_Group
	t.ExtButton0 = {ButtonEnable = true, ButtonName = ' Group ', ButtonScript = 'start_tv()'}
	t.ExtButton1 = {ButtonEnable = true, ButtonName = ' TVPortal ', ButtonScript = 'SelectTVPortal()'}
	t.ExtParams = {FilterType = 1, AutoNumberFormat = '%1. %2', StopOnError = 0, StopAfterPlay = 0, PlayMode = 2}
	local ret,id = m_simpleTV.OSD.ShowSelect_UTF8(m_simpleTV.User.TVPortal.Group_name .. ' - ' .. #t .. ' ch.', tonumber(m_simpleTV.User.TVPortal.Channel_id)-1, t, 10000, 1+4+8+2)
		if ret == -1 or not id then
			return
		end
		if ret == 1 then
			local is_portal = m_simpleTV.Database.GetTable('SELECT * FROM ExtFilter WHERE Name=="PortalTV";')
			local Filter_ID = is_portal[1].Id
			local epg_id,epg_logo = GetEPG_Id(m_simpleTV.User.TVPortal.Channel_Of_Group[id].InfoPanelName:gsub('^.-: ',''):gsub('^.-: ',''):gsub('\r',''))
			local logo = m_simpleTV.User.TVPortal.Channel_Of_Group[id].InfoPanelLogo
			if epg_logo and m_simpleTV.User.TVPortal.Channel_Of_Group[id].InfoPanelLogo == 'https://raw.githubusercontent.com/west-side-simple/logopacks/main/MoreLogo/westSidePortal.png' then
				logo = epg_logo
			end
			m_simpleTV.Database.ExecuteSql('DELETE FROM Channels WHERE (Channels.Id=' .. m_simpleTV.User.TVPortal.Id .. ');', true)
			if m_simpleTV.Database.ExecuteSql('INSERT INTO Channels ([Id],[ChannelOrder],[Name],[Address],[Group],[ExtFilter],[TypeMedia],[EpgId],[Logo],[LastPosition],[UpdateID],[RawM3UString],[State]) VALUES (' .. m_simpleTV.User.TVPortal.Id .. ',' .. m_simpleTV.User.TVPortal.Id .. ',"' .. m_simpleTV.User.TVPortal.Channel_Of_Group[id].InfoPanelName:gsub('^.-: ',''):gsub('^.-: ',''):gsub('\r','') .. '","portalTV=' .. m_simpleTV.User.TVPortal.Group_id .. '&channel=' .. id .. '",' .. 0 .. ',' .. Filter_ID ..',' .. 0 .. ',"' .. (epg_id or '') .. '","' .. logo .. '",' .. 0 .. ',"PortalTV",' .. "'" .. (m_simpleTV.User.TVPortal.Channel_Of_Group[id].RawM3UString or '') .. "'," .. m_simpleTV.User.TVPortal.Channel_Of_Group[id].State .. ');') then
				m_simpleTV.PlayList.Refresh()
			end
			m_simpleTV.PlayList.VerifyItem(m_simpleTV.User.TVPortal.Id, false)
			m_simpleTV.PlayList.SetFocusItem(m_simpleTV.User.TVPortal.Id, m_simpleTV.Interface.GetFullScreenMode())
			m_simpleTV.Control.SetPosition(0.0)
			m_simpleTV.Control.PlayAddressT({ address = '$InternationalID=' .. m_simpleTV.User.TVPortal.Id, timeshiftOffset = 0})
		end
		if ret == 2 then
			start_tv()
		end
		if ret == 3 then
			SelectTVPortal()
		end
end

if m_simpleTV.User.TVPortal.Channel_Of_Group == nil then
	start_tv()
end

if m_simpleTV.User.filmix==nil then m_simpleTV.User.filmix={} end
if m_simpleTV.User.rezka==nil then m_simpleTV.User.rezka={} end
if m_simpleTV.User.TMDB==nil then m_simpleTV.User.TMDB={} end
if m_simpleTV.User.collaps==nil then m_simpleTV.User.collaps={} end
if m_simpleTV.User.torrent==nil then m_simpleTV.User.torrent={} end
if m_simpleTV.User.hevc==nil then m_simpleTV.User.hevc={} end
if m_simpleTV.User.AudioWS==nil then m_simpleTV.User.AudioWS={} end
m_simpleTV.User.filmix.CurAddress = nil
m_simpleTV.User.rezka.CurAddress = nil
m_simpleTV.User.TMDB.Id = nil
m_simpleTV.User.TMDB.tv = nil
m_simpleTV.User.collaps.ua = nil
m_simpleTV.User.collaps.kinogo = nil
m_simpleTV.User.torrent.content = nil
m_simpleTV.User.hevc.content = nil
m_simpleTV.User.AudioWS.TrackCash = nil
m_simpleTV.User.westSide.PortalTable = true

local t = m_simpleTV.User.TVPortal.Channel_Of_Group
t.ExtButton0 = {ButtonEnable = true, ButtonName = ' Group ', ButtonScript = 'start_tv()'}
t.ExtButton1 = {ButtonEnable = true, ButtonName = ' TVPortal ', ButtonScript = 'SelectTVPortal()'}
t.ExtParams = {FilterType = 1, AutoNumberFormat = '%1. %2', StopOnError = 0, StopAfterPlay = 0, PlayMode = 2}
	local __,id = m_simpleTV.OSD.ShowSelect_UTF8(m_simpleTV.User.TVPortal.Group_name .. ' - ' .. #t .. ' ch.', tonumber(chn) - 1, t, 10000, 2 + 32)
	id = id or 1
	m_simpleTV.User.TVPortal.Channel_id = tonumber(chn)
	local retAdr, logo = GetAdr(t[tonumber(chn)].Address)

	m_simpleTV.Control.CurrentTitle_UTF8 = t[tonumber(chn)].InfoPanelName:gsub('^.-: ',''):gsub('^.-: ','')
	m_simpleTV.Control.SetTitle(t[tonumber(chn)].InfoPanelName:gsub('^.-: ',''):gsub('^.-: ',''))
			local is_portal = m_simpleTV.Database.GetTable('SELECT * FROM ExtFilter WHERE Name=="PortalTV";')
			local Filter_ID = is_portal[1].Id
			local epg_id,epg_logo = GetEPG_Id(m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].InfoPanelName:gsub('^.-: ',''):gsub('^.-: ',''):gsub('\r',''):gsub(' orig$',''))
			if epg_logo and logo == '' then
				logo = epg_logo
			end
			if logo == '' or logo == nil then
				logo = 'https://raw.githubusercontent.com/west-side-simple/logopacks/main/MoreLogo/westSidePortal.png'
			end
			local media_title, media_desc, background
			local name_for_media = m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].InfoPanelName:gsub('^.-: ',''):gsub('^.-: ',''):gsub('\r',''):gsub(' orig$','')
			local year = name_for_media:match(' %((%d%d%d%d)%)$') or name_for_media:match(' (%d%d%d%d)$')
	if year then
		local title_rus = name_for_media:gsub(' /.-$', ''):gsub('%(4K%)', ''):gsub(' %(мини%-сериал%)', ''):gsub('%(%+18%)', ''):gsub('%(Special%)', ''):gsub(' %- ', ' – '):gsub(' %(.-%d+%)$', ''):gsub(' %d+$', ''):gsub('%(color%)', '')
		local title_orig = name_for_media:gsub('^.-/ ', ''):gsub('%(4K%)', ''):gsub('%(4%)', ''):gsub(' %(мини%-сериал%)', ''):gsub('%(%+18%)', ''):gsub('%(Special%)', ''):gsub(' %- ', ' – '):gsub('%(.-%d+%)$', ''):gsub(' %d+$', ''):gsub('%(color%)', '') or title_rus

---------------заплатки (FOX)
		if title_orig:match('The Witcher') then title_orig = 'Ведьмак' year = 2019 end
		if title_orig == 'Bob Dylan at the Newport Folk Festival' then title_orig = 'Bob Dylan: The Other Side of the Mirror - Live at the Newport Folk Festival' year = 2007 end
		if title_orig:match('Холодное лето') then year = 1988 end
		if title_orig:match('Невероятные приключения') then year = 1974 end
		if title_orig:match('Мировой парень') then year = 1972 end
		if title_orig:match('Отпуск за свой счет') then year = 1982 end
		if title_orig:match('Блондинка за углом') then year = 1983 end
		if title_orig:match('Приключения Тома Сойера') then year = 1982 end
		if title_orig:match('12 стульев') and tonumber(year) == 1976 then year = 1977 end
		if title_orig:match('Человек%-амфибия') then year = 1962 end
		if title_orig:match('Трест который лопнул') then year = 1983 end
		if title_orig:match('Вождь краснокожих') then title_orig = 'Деловые люди' end
		if title_orig:match('Калина красная') then year = 1974 end
		if title_orig:match('ДАртаньян и три мушкетера') then year = 1978 end
		if title_orig:match('Кавказская пленница') then year = 1967 end
		if title_orig:match('Москва слезам не верит') then year = 1980 end
		if title_orig:match('На море!') then year = 2009 end
		if title_orig:match('Легенда №17') then year = 2013 end
		if title_orig:match('На Дерибасовской хорошая погода') then title_orig = 'На Дерибасовской хорошая погода, или На Брайтон-Бич опять идут дожди' year = 1993 end
		if title_orig:match('Трезвый водитель') then year = 2019 end
		if title_orig:match('Inkheart') then year = 2008 end
		if title_orig:match('The Dark World') then title_orig = 'Thor: The Dark World' end
		if title_orig == 'The Witches' then year = 1990 end
		if title_orig == 'Pelé: Birth of a Legend' then year = 2016 end
		if title_orig == 'Phantasm' then year = 1979 end
		if title_orig == 'Hellbound' then year = 1994 end
		if title_orig == 'Season of the Witch' then year = 2011 end
		if title_orig:match('R%-Evolution') then year = 2013 end
		if title_orig:match('Heathens and Thieves') then year = 2013 end
		if title_orig:match('Lichtmond') and tonumber(year) == 2014 then title_orig = 'Lichtmond 3 - Days of Eternity' end
		if title_orig:match('Старые песни о главном') then year = 1996 end
		if title_orig == 'Старые песни о главном 2' then year = 1997 end
		if title_orig == 'Старые песни о главном 3' then year = 1998 end
		if title_rus == 'Чиполлино' then year = 1973 end
		if title_rus == 'Белое солнце пустыни' then year = 1970 end
		if title_rus == 'Сексмиссия' then year = 1984 end
		if title_rus == 'Юнона и Авось' then year = 1983 end
		if title_rus == 'Любовь никогда не умирает' then year = 2012 end
		if title_rus == 'Летучая мышь' then year = 1979 end
		if title_rus == 'Хорошая девочка' then year = 2002 end
		if title_rus == 'Притворись моим парнем' then year = 2013 end
		if title_rus == 'Остров сокровищ' then year = 1989 end
		if title_orig:match('Приключения Петрова и Васечкина') then year = 1983 end
		if title_orig:match('Бриллиантовая рука') then year = 1969 end
		if title_orig:match('Федорино горе') then year = 1973 end
		if title_rus:match('Майами') and title_orig == 'New in Town' then year = 2009 end
		title_orig = title_orig:gsub('%: %d+ серия$', ''):gsub(' %d+ серия$', ''):gsub(' chapter %d+$', ''):gsub('Сокровища Агри', 'Сокровища Агры'):gsub('20%-й Век начинается', 'Двадцатый век начинается')
-----------------------

		media_desc, background, media_title = info_fox(title_orig:gsub(' $', ''),year,logo)
		if m_simpleTV.Control.MainMode == 0 then
			m_simpleTV.Interface.SetBackground({BackColor = 0, PictFileName = background or logo, TypeBackColor = 0, UseLogo = 3, Once = 1})
		end
		if media_desc ~= '' then
			media_desc = '<html><body bgcolor="#182633">' .. media_desc:gsub('<a href.-</a>','') .. '</body></html>'
		end
	end

			m_simpleTV.Database.ExecuteSql('DELETE FROM Channels WHERE (Channels.Id=' .. m_simpleTV.User.TVPortal.Id .. ');', true)
--			debug_in_file('INSERT INTO Channels ([Id],[ChannelOrder],[Name],[Address],[Group],[ExtFilter],[TypeMedia],[EpgId],[Logo],[LastPosition],[UpdateID],[RawM3UString],[State],[Title],[Desc]) VALUES (' .. m_simpleTV.User.TVPortal.Id .. ',' .. m_simpleTV.User.TVPortal.Id .. ',"' .. m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].InfoPanelName:gsub('^.-: ',''):gsub('^.-: ',''):gsub('\r',''):gsub('\n',''):gsub('\r',''):gsub('\n',''):gsub("'",'´') .. '","portalTV=' .. m_simpleTV.User.TVPortal.Group_id .. '&channel=' .. tonumber(chn) .. '",' .. 0 .. ',' .. Filter_ID ..',' .. 0 .. ',"' .. (epg_id or '') .. '","' .. logo .. '",' .. 0 .. ',"PortalTV",' .. "'" .. (m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].RawM3UString or ''):gsub('\r',''):gsub('\r',''):gsub('\n',''):gsub("'",'´') .. "'," .. m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].State .. ",'" .. (media_title or ""):gsub("'",'´') .. "','" .. (media_desc or ''):gsub("'",'´') .. "');" .. '\n','c://1/zapros_sql.txt')
			if m_simpleTV.Database.ExecuteSql('INSERT INTO Channels ([Id],[ChannelOrder],[Name],[Address],[Group],[ExtFilter],[TypeMedia],[EpgId],[Logo],[LastPosition],[UpdateID],[RawM3UString],[State],[Title],[Desc]) VALUES (' .. m_simpleTV.User.TVPortal.Id .. ',' .. m_simpleTV.User.TVPortal.Id .. ',"' .. m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].InfoPanelName:gsub('^.-: ',''):gsub('^.-: ',''):gsub('\r',''):gsub('\n',''):gsub('\r',''):gsub('\n','') .. '","portalTV=' .. m_simpleTV.User.TVPortal.Group_id .. '&channel=' .. tonumber(chn) .. '",' .. 0 .. ',' .. Filter_ID ..',' .. 0 .. ',"' .. (epg_id or '') .. '","' .. logo .. '",' .. 0 .. ',"PortalTV",' .. "'" .. (m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].RawM3UString or ''):gsub('\r',''):gsub('\r',''):gsub('\n',''):gsub("'",'´') .. "'," .. m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].State .. ",'" .. (media_title or ""):gsub("'",'´') .. "','" .. (media_desc or ''):gsub("'",'´') .. "');") then
				m_simpleTV.PlayList.Refresh()
			end

			if m_simpleTV.Timeshift.EpgOffsetRequest and m_simpleTV.Timeshift.EpgOffsetRequest > 0 then
				m_simpleTV.User.TVPortal.EpgOffsetRequest = m_simpleTV.Timeshift.EpgOffsetRequest
			else
				m_simpleTV.User.TVPortal.EpgOffsetRequest = 0
			end
			if epg_id then
				m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].InfoPanelLogo = logo
				epg_title,desc = GetEPG_For_Id(epg_id,m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].InfoPanelName:gsub('^.-: ',''):gsub('^.-: ',''):gsub('\r',''),logo)
				m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].InfoPanelTitle = epg_title
				m_simpleTV.User.TVPortal.Channel_Of_Group[tonumber(chn)].InfoPanelDesc = desc
			end
	m_simpleTV.Control.ChangeAddress = 'No'
	m_simpleTV.Control.CurrentAddress = retAdr
	m_simpleTV.Control.SetNewAddressT({address = retAdr, timeshiftOffset = m_simpleTV.User.TVPortal.EpgOffsetRequest})
