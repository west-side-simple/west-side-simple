--TV Portal events 04.11.23

if m_simpleTV.Control.Reason=='addressready'  then
	if m_simpleTV.User.TVPortal.PortalShowWindowId then
		m_simpleTV.Interface.RemoveExtMenu(m_simpleTV.User.TVPortal.PortalShowWindowId)
	end
	if m_simpleTV.User.TVPortal.PortalShowAdd then
		m_simpleTV.Interface.RemoveExtMenu(m_simpleTV.User.TVPortal.PortalShowAdd)
	end
	if m_simpleTV.User.TVPortal.PortalTable~=nil then
		local t={}
		t.utf8 = true
		t.name = '-'
		t.luastring = ''
		t.lua_as_scr = false
		t.submenu = 'TVPortal WS'
		t.imageSubmenu = ''
		--t.key = string.byte('I')
		t.ctrlkey = 0
		t.location = 0
		t.image=''
		m_simpleTV.User.TVPortal.PortalSeparatorId = m_simpleTV.Interface.AddExtMenuT(t)
		local t={}
		t.utf8 = true
		t.name = 'TVPortal Info Window'
		t.luastring = 'GetPortalTableForTVPortal()'
		t.lua_as_scr = true
		t.submenu = 'TVPortal WS'
		t.imageSubmenu = m_simpleTV.MainScriptDir_UTF8 .. 'user/portaltvWS/img/portaltv.png'
		t.key = string.byte('I')
		t.ctrlkey = 0
		t.location = 0
		t.image= m_simpleTV.MainScriptDir_UTF8 .. 'user/portaltvWS/img/fw_box_t3.png'
		m_simpleTV.User.TVPortal.PortalShowWindowId = m_simpleTV.Interface.AddExtMenuT(t)
		local t={}
		t.utf8 = true
		t.name = 'Add to FAV PlaylistT'
		t.luastring = 'AddPortalTVAddressToPlaylist()'
		t.lua_as_scr = true
		t.submenu = 'TVPortal WS'
		t.imageSubmenu = m_simpleTV.MainScriptDir_UTF8 .. 'user/portaltvWS/img/portaltv.png'
		t.key = string.byte('I')
		t.ctrlkey = 1
		t.location = 0
		t.image= m_simpleTV.MainScriptDir_UTF8 .. 'user/portaltvWS/img/fw_box_t2.png'
		m_simpleTV.User.TVPortal.PortalShowAdd = m_simpleTV.Interface.AddExtMenuT(t)
	end
end

-------------------------
			if m_simpleTV.Control.GetState() == 3 then
			m_simpleTV.User.TVPortal.isPause = true
			m_simpleTV.OSD.RemoveElement('USER_LOGO1_IMG_ID')
			m_simpleTV.OSD.RemoveElement('ID_DIV1')
			m_simpleTV.OSD.RemoveElement('ID_DIV5')
			m_simpleTV.OSD.RemoveElement('TEXT0_ID')
			m_simpleTV.OSD.RemoveElement('TEXT1_ID')
			m_simpleTV.OSD.RemoveElement('TEXT2_ID')
			m_simpleTV.OSD.RemoveElement('TEXT3_ID')
			m_simpleTV.OSD.RemoveElement('TEXT4_ID')
			m_simpleTV.OSD.RemoveElement('TEXT5_ID')
			end
			if m_simpleTV.Control.GetState() == 4 and m_simpleTV.User.TVPortal.isPause == true then

			local  t, AddElement = {}, m_simpleTV.OSD.AddElement

			 t = {}
			 t.id = 'ID_DIV1'
			 t.cx=-100 * m_simpleTV.Interface.GetScale()
			 t.cy=-50 * m_simpleTV.Interface.GetScale()
			 t.class="DIV"
			 t.minresx=0
			 t.minresy=0
			 t.align = 0x0201
			 t.left=0
			 t.top=30 * m_simpleTV.Interface.GetScale()
			 t.once=1
			 t.zorder=0
			 t.background = -1
			 t.backcolor0 = 0xff0000000
			 AddElement(t)

			 t = {}
			 t.id = 'ID_DIV5'
			 t.cx=700 * m_simpleTV.Interface.GetScale()
			 t.cy=-95 * m_simpleTV.Interface.GetScale()
			 t.class="DIV"
			 t.minresx=0
			 t.minresy=0
			 t.align = 0x0101
			 t.left=20 * m_simpleTV.Interface.GetScale()
			 t.top=20 * m_simpleTV.Interface.GetScale()
			 t.once=1
			 t.zorder=0
			 t.background = -1
			 t.backcolor0 = 0x7fFFFF00
			 AddElement(t,'ID_DIV1')
			 if not m_simpleTV.User.TVPortal.logo or m_simpleTV.User.TVPortal.logo == '' then return end
			 t = {}
			 t.id = 'USER_LOGO1_IMG_ID'
			 t.cx= 300 * m_simpleTV.Interface.GetScale()
			 t.cy= 450 * m_simpleTV.Interface.GetScale()
			 t.class="IMAGE"
			 t.imagepath = m_simpleTV.User.TVPortal.logo
			 t.minresx=-1
			 t.minresy=-1
			 t.align = 0x0101
			 t.left=20 * m_simpleTV.Interface.GetScale()
			 t.top=0
			 t.transparency = 200
			 t.zorder=0
			 t.borderwidth = 2
			 t.bordercolor = -6250336
			 t.backroundcorner = 0*0
			 t.borderround = 20
			 AddElement(t,'ID_DIV1')

			 t={}
			 t.id = 'TEXT0_ID'
			 t.cx=0
			 t.cy=0
			 t.class="TEXT"
			 t.align = 0x0101
			 t.text = m_simpleTV.User.TVPortal.slogan
			 t.color = -9113993
			 t.font_height = -15 * m_simpleTV.Interface.GetScale()
			 t.font_weight = 300 * m_simpleTV.Interface.GetScale()
			 t.font_italic = 1
			 t.font_name = "Segoe UI Black"
			 t.textparam = 0--1+4
			 t.left = 20 * m_simpleTV.Interface.GetScale()
			 t.top  = -50 * m_simpleTV.Interface.GetScale()
			 t.glow = 2 -- коэффициент glow эффекта
			 t.glowcolor = 0xFF000077 -- цвет glow эффекта
			 AddElement(t,'USER_LOGO1_IMG_ID')

			 t={}
			 t.id = 'TEXT1_ID'
			 t.cx=0
			 t.cy=0
			 t.class="TEXT"
			 t.align = 0x0101
			 t.text = m_simpleTV.User.TVPortal.title
			 t.color = -2123993
			 t.font_height = -35 * m_simpleTV.Interface.GetScale()
			 t.font_weight = 400 * m_simpleTV.Interface.GetScale()
			 t.font_underline = 1
			 t.font_name = "Segoe UI Black"
			 t.textparam = 0--1+4
			 t.left = 350 * m_simpleTV.Interface.GetScale()
			 t.top  = 0
			 t.glow = 3 -- коэффициент glow эффекта
			 t.glowcolor = 0xFF000077 -- цвет glow эффекта
			 AddElement(t,'USER_LOGO1_IMG_ID')

			 t={}
			 t.id = 'TEXT2_ID'
			 t.cx=0
			 t.cy=0
			 t.class="TEXT"
			 t.align = 0x0101
			 t.text = m_simpleTV.User.TVPortal.title_en
			 t.color = -2113993
			 t.font_height = -25 * m_simpleTV.Interface.GetScale()
			 t.font_weight = 300 * m_simpleTV.Interface.GetScale()
			 t.font_name = "Segoe UI Black"
			 t.textparam = 0--1+4
			 t.left = 350 * m_simpleTV.Interface.GetScale()
			 t.top  = 70 * m_simpleTV.Interface.GetScale()
			 t.glow = 2 -- коэффициент glow эффекта
			 t.glowcolor = 0xFF000077 -- цвет glow эффекта
			 AddElement(t,'USER_LOGO1_IMG_ID')

			 t={}
			 t.id = 'TEXT3_ID'
			 t.cx=0
			 t.cy=0
			 t.class="TEXT"
			 t.align = 0x0101
			 t.text = m_simpleTV.User.TVPortal.year .. ', ' .. m_simpleTV.User.TVPortal.country
			 t.color = -2113993
			 t.font_height = -15 * m_simpleTV.Interface.GetScale()
			 t.font_weight = 300 * m_simpleTV.Interface.GetScale()
			 t.font_name = "Segoe UI Black"
			 t.textparam = 0--1+4
			 t.left = 350 * m_simpleTV.Interface.GetScale()
			 t.top  = 115 * m_simpleTV.Interface.GetScale()
			 t.glow = 2 -- коэффициент glow эффекта
			 t.glowcolor = 0xFF000077 -- цвет glow эффекта
			 AddElement(t,'USER_LOGO1_IMG_ID')

			 t={}
			 t.id = 'TEXT4_ID'
			 t.cx=0
			 t.cy=0
			 t.class="TEXT"
			 t.align = 0x0101
			 t.text = m_simpleTV.User.TVPortal.genre
			 t.color = -2113993
			 t.font_height = -15 * m_simpleTV.Interface.GetScale()
			 t.font_weight = 300 * m_simpleTV.Interface.GetScale()
			 t.font_name = "Segoe UI Black"
			 t.textparam = 0--1+4
			 t.left = 350 * m_simpleTV.Interface.GetScale()
			 t.top  = 140 * m_simpleTV.Interface.GetScale()
			 t.glow = 2 -- коэффициент glow эффекта
			 t.glowcolor = 0xFF000077 -- цвет glow эффекта
			 AddElement(t,'USER_LOGO1_IMG_ID')

			 t={}
			 t.id = 'TEXT5_ID'
			 t.cx=0
			 t.cy=0
			 t.class="TEXT"
			 t.align = 0x0101
			 t.text = m_simpleTV.User.TVPortal.mess
			 t.color = -2113993
			 t.font_height = -10 * m_simpleTV.Interface.GetScale()
			 t.font_weight = 200 * m_simpleTV.Interface.GetScale()
			 t.font_name = "Segoe UI Black"
			 t.textparam = 0--1+4
			 t.left = 375 * m_simpleTV.Interface.GetScale()
			 t.top  = 180 * m_simpleTV.Interface.GetScale()
			 t.glow = 2 -- коэффициент glow эффекта
			 t.glowcolor = 0xFF000077 -- цвет glow эффекта
			 AddElement(t,'USER_LOGO1_IMG_ID')

			 m_simpleTV.User.TVPortal.isPause = nil
			 end

-------------------------

if m_simpleTV.Control.Reason=='Stopped' or m_simpleTV.Control.Reason=='Error' then
	m_simpleTV.User.TVPortal.PortalTable=nil
	if m_simpleTV.User.TVPortal.PortalShowWindowId then
		m_simpleTV.Interface.RemoveExtMenu(m_simpleTV.User.TVPortal.PortalShowWindowId)
	end
	if m_simpleTV.User.TVPortal.PortalShowAdd then
		m_simpleTV.Interface.RemoveExtMenu(m_simpleTV.User.TVPortal.PortalShowAdd)
	end
	m_simpleTV.OSD.RemoveElement('USER_LOGO1_IMG_ID')
		m_simpleTV.OSD.RemoveElement('ID_DIV1')
		m_simpleTV.OSD.RemoveElement('ID_DIV5')
		m_simpleTV.OSD.RemoveElement('TEXT0_ID')
		m_simpleTV.OSD.RemoveElement('TEXT1_ID')
		m_simpleTV.OSD.RemoveElement('TEXT2_ID')
		m_simpleTV.OSD.RemoveElement('TEXT3_ID')
		m_simpleTV.OSD.RemoveElement('TEXT4_ID')
		m_simpleTV.OSD.RemoveElement('TEXT5_ID')
end

if m_simpleTV.Control.Reason == 'Playing' then
   m_simpleTV.Control.EventPlayingInterval=5000
   if m_simpleTV.User.TVPortal.IsFoxRoom == true then
	local name_for_media = m_simpleTV.Control.GetMetaInfo(0)
	name_for_media = name_for_media:gsub('%(',''):gsub('%)',''):gsub('%.',' '):gsub('_','')
	local title, year = name_for_media:match('(.-) (%d%d%d%d)')
	if title and year then
	 m_simpleTV.OSD.ShowMessage_UTF8(title .. ' (' .. year .. ')',0x0000FF00,10 )
	 info_fox(title,year,'')
	 m_simpleTV.User.TVPortal.IsFoxRoom = false
	end
   end   
   local mess=''
   local ss = m_simpleTV.Control.GetCodecInfo()
   local i=1
	while ss and ss[i] and type(ss[i])=='table' do
     if ss[i]["Type"]~=nil and ss[i]["Codec"]~=nil then
	 local lang, desc = '', ''
	  if (ss[i]["Type"] == 'Audio' or ss[i]["Type"] == 'Subtitle') and ss[i]["Language"] or
	  ss[i]["Type"] == 'Video' and ss[i]["Video resolution"] then
	   if ss[i]["Type"] == 'Video' then lang = ' / ' .. ss[i]["Video resolution"]
	    else lang = ' / ' .. ss[i]["Language"]
	   end
	  end
	  if ss[i]["Description"] then desc = ' / ' .. ss[i]["Description"] end
      mess = mess .. ss[i]["Type"] .. lang .. desc .. ' / ' .. ss[i]["Codec"] .. '\n'
     end
	i = i + 1
   end
   if mess ~= '' then
--        m_simpleTV.OSD.ShowMessage_UTF8(mess,0x0000FF00,10 )
	m_simpleTV.User.TVPortal.mess = mess
   end
end

if m_simpleTV.Control.Reason == 'Stopped' or m_simpleTV.Control.Reason == 'EndReached' then
            m_simpleTV.OSD.ShowMessage_UTF8('')
end
