if m_simpleTV.Control.CurrentAddress==nil or m_simpleTV.Control.CurrentAddress_UTF8==nil then return end

if m_simpleTV.User.BestEverAddon.Access==true then return end

if m_simpleTV.Control.Reason=='Playing' then

 if m_simpleTV.User.BestEverAddon.Play==nil then
  m_simpleTV.User.BestEverAddon.Play=true
 end
 
 if m_simpleTV.User.BestEverAddon.Play then
  local t={}
  t.address = m_simpleTV.MainScriptDir .. "user/besteveraddon/001.jpg$OPT:image-duration=600"
  m_simpleTV.Control.SetNewAddressT(t)
  m_simpleTV.Control.SetTitle('Best Ever SimpleTV Addon')
  m_simpleTV.User.BestEverAddon.Play=false
 end
end 

if m_simpleTV.Control.Reason=='EndReached'  then
 m_simpleTV.User.BestEverAddon.Play=nil
 m_simpleTV.Control.Action='repeat'
end

if m_simpleTV.Control.Reason=='Stopped' then
 m_simpleTV.Control.EventPlayingInterval=0
 m_simpleTV.User.BestEverAddon.Play=nil
end


