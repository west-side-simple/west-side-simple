<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" sourcelanguage="en_US">
<context>
    <name>simpleTV::westSidePortal</name>
    <message>
     <source>Options for westSidePortal </source>
     <translation type="unfinished"></translation>
    </message>
    <message>
     <source>Enabled</source>
     <translation type="unfinished"></translation>
    </message>
    <message>
     <source>Embedded in main frame</source>
     <translation type="unfinished"></translation>       
    </message>    
    <message>
     <source>Save position</source>
     <translation type="unfinished"></translation>       
    </message>
    <message>
     <source>Chromium mode</source>
     <translation type="unfinished"></translation>       
    </message> 	
    <message>
     <source>Addon Media portal for SimpleTV. Implements the ability to select media content for portal-connected sites based on dialog boxes.&lt;br&gt;Keyboard shortcuts: 'Ctrl+Shift+P' - show OSD.</source>
     <translation type="unfinished"></translation>       
    </message>         
</context>
</TS>
