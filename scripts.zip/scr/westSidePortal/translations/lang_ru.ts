<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru" sourcelanguage="en_US">
<context>
    <name>simpleTV::westSidePortal</name>
    <message>
        <source>Options for westSidePortal </source>
        <translation>Настройки для westSidePortal </translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Включен</translation>
    </message>
    <message>
        <source>Embedded in main frame</source>
        <translation>Встроен в основное окно</translation>
    </message>
    <message>
        <source>Save position</source>
        <translation>Сохранять позицию</translation>
    </message>
	<message>
     <source>Chromium mode</source>
     <translation>Chromium режим</translation>       
    </message> 
    <message>
     <source>Addon Media portal for SimpleTV. Implements the ability to select media content for portal-connected sites based on dialog boxes.&lt;br&gt;Keyboard shortcuts: 'Ctrl+Shift+P' - show OSD.</source>
     <translation>Аддон Медиа портал для SimpleTV. Реализует возможность выбора медиаконтента для подключенных к порталу сайтов на основе диалоговых окон.&lt;br&gt;Горячие клавиши: 'Ctrl+Shift+P' - показать на OSD.</translation>
    </message>         
</context>
</TS>
