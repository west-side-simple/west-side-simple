local t ={}
t.name = "westSidePortal"
t.htmlUri = m_simpleTV.MainScriptDir_UTF8 .. 'user/westSidePortal/GUIConfig/configdialog.html'
t.luaUri  = 'user/westSidePortal/GUIConfig/configdialog.lua'
t.iconUri  = m_simpleTV.MainScriptDir_UTF8 .. 'user/westSidePortal/GUI/img/westSidePortal.png'
m_simpleTV.Config.AddExtDialogT(t)


