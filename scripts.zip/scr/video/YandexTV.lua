-- видеоскрипт для плейлиста "YandexTV" https://yandex.ru (25/12/19)
-- открывает подобные ссылки:
-- https://strm.yandex.ru/kal/bigasia/bigasia0.m3u8
-- https://strm.yandex.ru/kal/ohotnik/ohotnik0_169_480p.json/index-v1-a1.m3u8
		if m_simpleTV.Control.ChangeAddress ~= 'No' then return end
		if not m_simpleTV.Control.CurrentAddress:match('https?://strm%.yandex%.ru/k') then return end
	local inAdr = m_simpleTV.Control.CurrentAddress
	m_simpleTV.Control.ChangeAddress = 'Yes'
	m_simpleTV.Control.CurrentAddress = 'error'
	if m_simpleTV.Control.MainMode == 0 then
		m_simpleTV.Interface.SetBackground({BackColor = 0, PictFileName = '', TypeBackColor = 0, UseLogo = 0, Once = 1})
	end
	if not m_simpleTV.User then
		m_simpleTV.User = {}
	end
	if not m_simpleTV.User.tvYndx then
		m_simpleTV.User.tvYndx = {}
	end
	if not m_simpleTV.User.TVTimeShift then
		m_simpleTV.User.TVTimeShift = {}
	end
	local function tvYndxIndex(t)
		local lastQuality = tonumber(m_simpleTV.Config.GetValue('yandex_tv_qlty') or 5000)
		local index = #t
			for i = 1, #t do
				if t[i].Id >= lastQuality then
					index = i
				 break
				end
			end
		if index > 1 then
			if t[index].Id > lastQuality then
				index = index - 1
			end
		end
	 return index
	end
		if inAdr:match('^%$tvYndx') then
			local index = tvYndxIndex(m_simpleTV.User.tvYndx.Tab)
			inAdr = m_simpleTV.User.tvYndx.Tab[index].Address
			if m_simpleTV.User.TVTimeShift.istYndx_Offset == true then
				local offset = m_simpleTV.User.TVTimeShift.tYndx_Offset
				local endY = os.time() - 120
				local startY = os.time() + offset
				if (endY - startY) > (6 * 3600) then
					endY = startY + (6 * 3600)
				end
				inAdr = inAdr .. '?start=' .. startY .. '&end=' .. endY
			end
			m_simpleTV.Control.CurrentTitle_UTF8 = ''
			m_simpleTV.Control.CurrentAddress = inAdr:gsub('%$tvYndx', '') .. m_simpleTV.User.tvYndx.extOpt
		 return
		end
		if inAdr:match('start=') then
			m_simpleTV.Control.CurrentAddress = inAdr .. (m_simpleTV.User.tvYndx.extOpt or '')
		 return
		end
	local url = inAdr:gsub('_%d+_%d+p%.json.-$', '.m3u8') .. '?vsid=22'
	local extOpt = ''
	if m_simpleTV.Common.GetVlcVersion() > 3000 then
		extOpt = extOpt .. '$OPT:no-gnutls-system-trust'
	end
	m_simpleTV.User.tvYndx.extOpt = extOpt
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.79 Safari/537.36')
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 8000)
	url = url:gsub('%$OPT:.+', '')
	url = url:gsub('%?.-$', '')
	m_simpleTV.User.TVTimeShift.istYndx_Offset = nil
	rc, answer = m_simpleTV.Http.Request(session, {url = url})
	m_simpleTV.Http.Close(session)
		if rc ~= 200 then return end
	local host = url:match('.+/')
	if answer:match('%.json') then
		host = url:match('https?://.-/')
	end
	local i, t, name, adr = 1, {}
		for w in answer:gmatch('EXT%-X%-STREAM%-INF(.-%.m3u8.-)\n') do
			adr = w:match('\n(.+)')
				if not adr then break end
			if not adr:match('redundant') then
				name = w:match('RESOLUTION=%d+x(%d+)')
				t[i] = {}
				t[i].Name = name .. 'p'
				t[i].Address = '$tvYndx' .. host .. adr:gsub('^/', ''):gsub('%?.-$', ''):gsub('&.-$', '')
				t[i].Id = tonumber(name)
				i = i + 1
			end
		end
		if i == 1 then
			m_simpleTV.Control.CurrentAddress = url .. extOpt
		 return
		end
	table.sort(t, function(a, b) return a.Id < b.Id end)
	local index = #t
	if #t > 1 then
		t[#t + 1] = {}
		t[#t].Id = 5000
		t[#t].Name = '▫ всегда высокое'
		t[#t].Address = t[#t - 1].Address
		t[#t + 1] = {}
		t[#t].Id = 10000
		t[#t].Name = '▫ адаптивное'
		t[#t].Address = '$tvYndx' .. url
		index = tvYndxIndex(t)
		m_simpleTV.User.tvYndx.Tab = t
		if m_simpleTV.Control.MainMode == 0 then
			t.ExtButton1 = {ButtonEnable = true, ButtonName = '✕', ButtonScript = 'm_simpleTV.Control.ExecuteAction(37)'}
			t.ExtParams = {LuaOnOkFunName = 'tvYndxSaveQuality'}
			m_simpleTV.OSD.ShowSelect_UTF8('⚙ Качество', index - 1, t, 5000, 32 + 64 + 128)
		end
	end
	m_simpleTV.Control.CurrentAddress = t[index].Address:gsub('%$tvYndx', '') .. extOpt
	function tvYndxSaveQuality(obj, id)
		m_simpleTV.Config.SetValue('yandex_tv_qlty', id)
	end
-- debug_in_file(m_simpleTV.Control.CurrentAddress .. '\n')