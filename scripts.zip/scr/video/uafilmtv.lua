-- видеоскрипт для сайта https://uafilm.tv (24/1/19)
-- необходимы скрипты: hdgo
-- открывает подобные ссылки:
-- https://uafilm.tv/887-temna-vezha.html
-- https://uafilm.tv/264-i-mertvi-pidut.html
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
		if inAdr == nil then return end
		if not inAdr:match('uafilm%.tv') and not inAdr:match('&uafilmtv') then return end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = ''
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/71.0.2785.143 Safari/537.36')
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 12000)
	local retAdr = inAdr
	if not inAdr:match('&uafilmtv') then
		title = inAdr:match('uafilm%.tv/%d+%-(.+)%.') or 'uafilmtv'
		title = title:gsub('%-', ' ')
		local id = inAdr:match('uafilm%.tv/(%d+)')
		local url = 'https://uafilm.tv/engine/ajax/iframePlayer.php?post_id=' .. id
		rc, answer = m_simpleTV.Http.Request(session, {url = url})
			if rc ~= 200 then
				m_simpleTV.Http.Close(session)
				m_simpleTV.OSD.ShowMessage_UTF8('uafilmtv ошибка[1]-' .. rc, 255, 5)
			 return
			end
		answer = answer:gsub('\\/', '/'):gsub('\\"', '"')
		local sesons = answer:match('<select name="source"(.-)</select>')
		if sesons then
			local t, i = {}, 1
			for ww in sesons:gmatch('<option.-</option>') do
				local adr = ww:match('value="(.-)"')
				local name = ww:match('>(.-)</')
				t[i] = {}
				t[i].Id = i
				t[i].Adress = url .. '&select=source' .. url_encode('=' .. adr)
				t[i].Name = unescape3(name)
				i = i + 1
			end
			if i > 2 then
				local _, id = m_simpleTV.OSD.ShowSelect_UTF8('Виберете сезон - ' .. title, 0, t, 5000, 1)
				if id == nil then id = 1 end
				url = t[id].Adress
			else
				url = t[1].Adress
			end
			rc, answer = m_simpleTV.Http.Request(session, {url = url})
				if rc ~= 200 then
					m_simpleTV.Http.Close(session)
					m_simpleTV.OSD.ShowMessage_UTF8('uafilmtv ошибка[2]-' .. rc, 255, 5)
				 return
				end
			answer = answer:gsub('\\/', '/'):gsub('\\"', '"')
		end
		local seria = answer:match('<select name="series"(.-)</select>')
		if seria then
			local t1, i = {}, 1
			for ww in seria:gmatch('<option.-</option>') do
				local adr = ww:match('value="(.-)"')
				local name = ww:match('>(.-)</')
				t1[i] = {}
				t1[i].Id = i
				t1[i].Adress = url .. url_encode('&series=' .. adr) .. '&uafilmtv'
				t1[i].Name = unescape3(name)
				i = i + 1
			end
			if i > 2 then
				local _, id = m_simpleTV.OSD.ShowSelect_UTF8(title, 0, t1, 5000)
				if id == nil then id = 1 end
				retAdr = t1[id].Adress
			else
				retAdr = t1[1].Adress
			end
		end
	end
	local serii = false
	if retAdr:match('&uafilmtv') then
		rc, answer = m_simpleTV.Http.Request(session, {url = retAdr:gsub('&uafilmtv', '')})
			if rc ~= 200 then
				m_simpleTV.Http.Close(session)
				m_simpleTV.OSD.ShowMessage_UTF8('uafilmtv ошибка[3]-' .. rc, 255, 5)
			 return
			end
		answer = answer:gsub('\\/', '/'):gsub('\\"', '"')
		serii = true
	end
	retAdr = answer:match('iframe src="(.-)"')
		if retAdr == nil then
			m_simpleTV.OSD.ShowMessage_UTF8('uafilmtv ошибка[4]', 255, 5)
		 return
		end
	if m_simpleTV.Control.CurrentTitle_UTF8 ~= nil then m_simpleTV.Control.CurrentTitle_UTF8 = title end
	if serii == true then retAdr = retAdr .. '&uafilm' end
	m_simpleTV.Http.Close(session)
	m_simpleTV.Control.ChangeAdress = 'No'
	m_simpleTV.Control.CurrentAdress = retAdr:gsub('https?://.-/', 'http://hdgo.cc/')
	dofile(m_simpleTV.MainScriptDir .. "user\\video\\video.lua")
-- debug_in_file(retAdr .. '\n')