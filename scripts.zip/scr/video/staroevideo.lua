-- видеоскрипт для сайта http://www.staroe-video.ru (10/8/18)
-- необходимы скрипты: vk, ok, ourvideo
-- открывает подобные ссылки:
-- http://staroe-video.ru/vojna-i-mir-1965-goda
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
		if not inAdr then return end
		if not inAdr:match('https?://staroe%-video%.ru') then return end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = ''
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/68.0.2785.143 Safari/537.36')
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 8000)
	local rc, answer = m_simpleTV.Http.Request(session, {url = inAdr:gsub('#.+', '')})
	m_simpleTV.Http.Close(session)
		if rc ~= 200 then return end
	local title = answer:match('<title>(.-)</title>') or 'staroe-video'
	title = title:gsub('&#039;', '’'):gsub('%s%(.+', '')
	m_simpleTV.Control.CurrentTitle_UTF8 = title
	local a, i, ess, ess2 = {}, 1, 0, 0
	local Adr, name
		for dr in answer:gmatch('<div class="box.-</div>') do
			Adr = dr:match('src="(.-)"')
				if not Adr then break end
			if dr:match('"box"') then
				ess = ess + 1
				name = ess .. ' серия' .. ' 1 плеер'
			else
				ess2 = ess2 + 1
				name = ess .. ' серия' .. ' 2 плеер'
			end
			a[i] = {}
			a[i].Id = i
			a[i].Adress = Adr:gsub('&#038;', '&'):gsub('^//', 'http://')
			a[i].Name = name
			i = i + 1
		end
		if i == 1 then return end
	if i > 2 then
		local _, id = m_simpleTV.OSD.ShowSelect_UTF8(title, 0, a, 5000, 1)
		if not id then id = 1 end
		retAdr = a[id].Adress
	else
		retAdr = a[1].Adress
	end
	m_simpleTV.Control.ChangeAdress = 'No'
	m_simpleTV.Control.CurrentAdress = retAdr
	dofile(m_simpleTV.MainScriptDir .. "user\\video\\video.lua")
-- debug_in_file(retAdr .. '\n')