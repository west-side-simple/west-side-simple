-- видеоскрипт для сайта http://videomore.ru (20/8/18)
-- открывает подобные ссылки:
-- https://videomore.ru/illyuziya-obmana
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
		if not inAdr then return end
		if not inAdr:match('https?://videomore.ru') then return end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = 'error'
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/68.0.2785.143 Safari/537.36')
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 8000)
	local rc, answer = m_simpleTV.Http.Request(session, {url = inAdr})
		if rc ~= 200 then return end
	local title = answer:match('title="(.-)"') or 'videomore'
	local retAdr = answer:match('data%-content%-url="(.-)"')
		if not retAdr then m_simpleTV.Http.Close(session) return end
	rc, answer = m_simpleTV.Http.Request(session, {url = 'https://videomore.ru/videomore_token', headers = 'Referer: ' .. inAdr})
		if rc ~= 200 then m_simpleTV.Http.Close(session) return end
	local token = answer:match('"videomore_token":"(.-)"')
		if not token then m_simpleTV.Http.Close(session) return end
	rc, answer = m_simpleTV.Http.Request(session, {url = retAdr:gsub('amp;', '') .. token, headers = 'Referer: ' .. inAdr .. '?utm_source=videomore&utm_medium=widget_project_home&utm_campaign=top'})
	m_simpleTV.Http.Close(session)
		if rc ~= 200 then return end
	retAdr = answer:match('"hls_url":"(.-)"')
		if not retAdr then return end
	m_simpleTV.Control.CurrentTitle_UTF8 = title
	m_simpleTV.Control.CurrentAdress = retAdr
-- debug_in_file(retAdr .. '\n')