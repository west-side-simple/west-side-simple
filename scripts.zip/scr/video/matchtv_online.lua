-- видеоскрипт для сайта https://matchtv.ru (15/4/19)
-- открывает ссылку: https://matchtv.ru/on-air
-----------------------------------------------------------------------------------------
local qlty = 0 -- качество в кбит/с: 0 - авто; ограничить от 1000
-----------------------------------------------------------------------------------------
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
		if not inAdr then return end
		if not inAdr:match('^https?://matchtv%.ru/on%-air') and not inAdr:match('^$matchtv') then return end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = ''
	if not m_simpleTV.User then
		m_simpleTV.User = {}
	end
	if not m_simpleTV.User.matchtv then
		m_simpleTV.User.matchtv = {}
	end
	if qlty > 0 and not m_simpleTV.User.matchtv.MaxResolution then
		m_simpleTV.User.matchtv.MaxResolution = qlty
	end
	if qlty == 0 and not m_simpleTV.User.matchtv.MaxResolution then
		m_simpleTV.User.matchtv.MaxResolution = 100000000
	end
	local function GetMaxResolutionIndex(t)
		local index = m_simpleTV.Control.GetMultiAddressIndex()
		if (tvs_core) and (TVSources_var.IsTVS == true) then index = nil end
		if not index and not m_simpleTV.User.matchtv.MaxResolution then
			m_simpleTV.User.matchtv.MaxResolution = t[#t].res
		elseif index then
			if #t < index then
				index = #t - 1
			end
			if t[index+1] and t[index+1].res then
				m_simpleTV.User.matchtv.MaxResolution = t[index+1].res
			end
		end
		if m_simpleTV.User.matchtv.MaxResolution > 0 then
			index = 1
			for u = 1, #t do
					if t[u].res and m_simpleTV.User.matchtv.MaxResolution < t[u].res then break end
				index = u
			end
		end
	 return index or 1
	end
		if inAdr:match('$matchtv') then
			if m_simpleTV.User.matchtv.ResolutionTable then
				local index = GetMaxResolutionIndex(m_simpleTV.User.matchtv.ResolutionTable)
				local retAdr = m_simpleTV.User.matchtv.ResolutionTable[index].Adress:gsub('$matchtv', '')
				m_simpleTV.Control.CurrentAdress = retAdr
			end
		 return
		end
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/68.0.2785.143 Safari/537.36')
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 8000)
	local rc, answer = m_simpleTV.Http.Request(session, {url = inAdr})
		if rc ~= 200 then m_simpleTV.Http.Close(session) return end
	local url = answer:match('<iframe name.-src="(.-)"')
		if not url then m_simpleTV.Http.Close(session) return end
	rc, answer = m_simpleTV.Http.Request(session, {url = url:gsub('^//', 'http://'), headers = 'Referer: ' .. inAdr})
		if rc ~= 200 then m_simpleTV.Http.Close(session) return end
	local retAdr = answer:match('http[^\'\"<>]+%.m3u8[^<>\'\"]*')
		if not retAdr then m_simpleTV.Http.Close(session) return end
	rc, answer = m_simpleTV.Http.Request(session, {url = retAdr})
	m_simpleTV.Http.Close(session)
		if rc ~= 200 then return end
	local t, i = {}, 1
	local name, adr
		for w in answer:gmatch('EXT%-X%-STREAM%-INF(.-\n.-)\n') do
			adr = w:match('\n(.+)')
				if not adr then break end
			t[i] = {}
			t[i].Id = i
			name = w:match('BANDWIDTH=(%d+)') or '10'
			name = tonumber(name) / 1000
			name = math.floor(name)
			t[i].Name = name  .. ' кбит/с'
			t[i].res = name
			t[i].Adress = '$matchtv' .. adr
			i = i + 1
		end
	if i > 2 then
		t[i] = {Id = i, Name = 'Авто', res = 100000000, Adress = '$matchtv' .. retAdr}
		table.sort(t, function(a, b) return a.res < b.res end)
		for i = 1, #t do t[i].Id = i end
		m_simpleTV.User.matchtv.ResolutionTable = t
		local index = GetMaxResolutionIndex(t)
		retAdr = t[index].Adress:gsub('$matchtv', '')
		m_simpleTV.OSD.ShowSelect_UTF8('⚙  Качество', index-1, t, 5000, 32+64+128)
	end
	m_simpleTV.Control.CurrentAdress = retAdr
-- debug_in_file(retAdr .. '\n')