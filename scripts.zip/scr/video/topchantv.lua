-- видеоскрипт для плейлиста "topchantv" http://www.911tv.info (23/3/19)
-- открывает подобные ссылки:
-- topchantv1844
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
		if not inAdr then return end
		if not inAdr:match('^topchantv%d') then return end
	if not m_simpleTV.User then
		m_simpleTV.User = {}
	end
	if not m_simpleTV.User.topchantv then
		m_simpleTV.User.topchantv = {}
	end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = 'error'
	local function getAdr()
		local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.2785.143 Safari/537.36')
			if not session then return end
		m_simpleTV.Http.SetTimeout(session, 8000)
		local rc, answer = m_simpleTV.Http.Request(session, {url = 'http://www.911tv.info/online'})
		m_simpleTV.Http.Close(session)
			if rc ~= 200 then return end
		answer = answer:match('<li class="" data%-h="(.-)"')
			if not answer then return end
		answer = decode64(answer):gsub('\\/', '/')
		 return answer:gsub('(.+/).-$', '%1')
	end
	if not m_simpleTV.User.topchantv.adr then
		m_simpleTV.User.topchantv.adr = getAdr()
			if not m_simpleTV.User.topchantv.adr then return end
	end
	local retAdr = m_simpleTV.User.topchantv.adr .. inAdr:gsub('topchantv', '') .. '.m3u8'
	if m_simpleTV.Common.GetVlcVersion() > 3000 then
		retAdr  = retAdr .. '$OPT:adaptive-use-access$OPT:demux=adaptive,any'
    end
	m_simpleTV.Control.CurrentAdress = retAdr
-- debug_in_file(retAdr .. '\n')