-- видеоскрипт для Wink TV (25/12/20) - portal version
-- авторы west_side, wafee
	if m_simpleTV.Control.ChangeAddress ~= 'No' then return end
	if not m_simpleTV.Control.CurrentAddress:match('^https://wink%.rt%.ru/tv$')
		and not m_simpleTV.Control.CurrentAddress:match('^https://wink%.rt%.ru/tv.+') then
		return
	end
	
if m_simpleTV.User==nil then m_simpleTV.User={} end
if m_simpleTV.User.Wink==nil then m_simpleTV.User.Wink={} end
if m_simpleTV.User.Edem==nil then m_simpleTV.User.Edem={} end
--wafee event edem playlist
if m_simpleTV.Control.Reason=='Stopped' then
  m_simpleTV.User.Wink.Offset=nil
end
--

	m_simpleTV.Interface.SetBackground({BackColor = 0, PictFileName = '', TypeBackColor = 0, UseLogo = 3, Once = 1})
	local inAdr = m_simpleTV.Control.CurrentAddress
	m_simpleTV.Control.ChangeAddress = 'Yes'
	m_simpleTV.Control.CurrentAddress = ''
	m_simpleTV.OSD.ShowMessageT({text = '', showTime = 1000, id = 'channelName'})
	local epg_genre = tonumber(inAdr:match('epg_genre=(%d+)$')) or 0
	inAdr = inAdr:gsub('%&epg_genre=.-$', '')

	local program_start_time = inAdr:match('start_time=(%d+)$')
	if inAdr:match('start_time=%d+$') then
		m_simpleTV.Control.PlayAddressT({address=inAdr:gsub('%?.-$', ''),timeshiftOffset=(os.time()-program_start_time)*1000})
	else
		retAdr = inAdr:gsub('%?.-$', '')
	end
--  для использования прозрачного логопака каналов выбрать 1 (например, в базовом скине бекграунд уже присутствует)
--	local logopac_transparent = 1
	local logopac_transparent = 0
--
local genres = {
		{"genre1", "Фильмы", ''},
		{"genre2", "Сериалы", ''},
		{"genre3", "Познавательные передачи", ''},
		{"genre4", "Спорт", ''},
		{"genre5", "Музыка", ''},
		{"genre6", "Новости", ''},
		{"genre7", "ТВ-Шоу", ''},
		{"genre8", "Детям", ''},
		{"genre9", "Остальное", ''},
		{"genre10", "Новогодняя", ''},
		{"genre11", "Трейлер", ''},
		{"genre12", "Анонс", ''},
		{"genre13", "Для взрослых", ''},
		}
		local t_genres={}
		for i = 1, #genres do
		t_genres[i] = {}
		t_genres[i].Name = genres[i][2]
		t_genres[i].Address = genres[i][1]
		t_genres[i].Logo = genres[i][3]
		end

--wafee------------
--показывать предупреждение "погода не установлена" один раз в сессии симпла

if m_simpleTV.User.westSide.ShowWeatherMess == nil then
  m_simpleTV.User.westSide.ShowWeatherMess = true
end

--ноль громкости, при запуске портала, для тех кому не нравится слушать радио
--можно реализовать через опцию в меню
--пример 1 - on, 0 - off
local mute=0
local extOpt=''
if mute==1 then
 m_simpleTV.User.westSide.Volume = m_simpleTV.Control.GetVolume() or 0.3
--при запуске видео в getaddress установить громоксть из m_simpleTV.User.westSide.Volume
--SetVolume(number vol,boolean ShowSlider(opt def=true))
--или как retAdr .. '$OPT:volume=' .. m_simpleTV.User.westSide.Volume
 extOpt = '$OPT:volume=0'
end
		if m_simpleTV.Config.GetValue("background_chanel","PortalConf.ini") then
		background_chanel = m_simpleTV.Config.GetValue("background_chanel","PortalConf.ini")
		else 
		m_simpleTV.Config.SetValue("background_chanel","http://stream.pcradio.ru:8000/spirit_radio_pcradio-hi$OPT:http-user-agent=pcradio","PortalConf.ini")
		background_chanel = m_simpleTV.Config.GetValue("background_chanel","PortalConf.ini")
		m_simpleTV.OSD.ShowMessageT({imageParam = 'vSizeFactor="1.0" src="' .. m_simpleTV.Common.GetMainPath(2) .. './luaScr/user/westSide/icons/audio.png"', text = ' фоновый канал: Spirit FM', color = ARGB(255, 63, 63, 255), showTime = 1000 * 10})
		end
--можно через SetMute(number mode) , правда иконка появляется на экране и при скролле mute сбрасывается

--wafee------------

---------------------------------------------------------------------------
local masshtab = m_simpleTV.User.paramScriptForSkin_masshtab or 1.5
    if not m_simpleTV.Interface.GetFullScreenMode() then
     masshtab = masshtab*0.66
    end
		local titul_rezka = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://rezka.ag\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/hdrezka_logo.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_hevc = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://rips.club\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/h265.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_rezka_tor = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://rezka.cc\/\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/menuREZKA.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_lostfilm = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://www.lostfilm.tv/new\/\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/lostfilm.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_yt = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://www.youtube.com\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/menuYT.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_wink = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/menuWINK.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_newstudio = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'http://newstudio.tv/\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/newstudio.png" height="' .. 36*masshtab .. '" align="top"></a>'
	dataEN = os.date ("%a %d %b %Y %H:%M")
	dataRU = dataEN:gsub('Sun', 'Вс'):gsub('Mon', 'Пн'):gsub('Tue', 'Вт'):gsub('Wed', 'Ср'):gsub('Thu', 'Чт'):gsub('Fri', 'Пт'):gsub('Sat', 'Сб')
	dataRU = dataRU:gsub('Jan', 'Янв'):gsub('Feb', 'Фев'):gsub('Mar', 'Мар'):gsub('Apr', 'Апр'):gsub('May', 'Май'):gsub('Jun', 'Июн'):gsub('Jul', 'Июл'):gsub('Aug', 'Авг'):gsub('Sep', 'Сен'):gsub('Oct', 'Окт'):gsub('Nov', 'Ноя'):gsub('Dec', 'Дек')
	if m_simpleTV.Interface.GetLanguage() == 'ru' then data = dataRU else data = dataEN end
	if Weather then
		local pogoda = Weather.api.GetCurTemp()
		if type(pogoda)=="table" then
			pogoda_cur_temp = pogoda.cur_temp
			pogoda_letter = pogoda.letter
			pogoda_cur_icon = pogoda.cur_icon
			if pogoda.cur_icon == '' then pogoda_cur_icon = 'simpleTVImage:./luaScr/user/Weather/iconset/light/na.png' end
			pogoda_str = '<td style="padding: 10px 10px 5px; vertical-align: middle; color: #EBEBEB;"><center><a href = "simpleTVLua:dofile(m_simpleTV.MainScriptDir .. \'user/Weather/switch_weather.lua\')"><img src="' .. pogoda_cur_icon .. '" height="' .. 36*masshtab .. '" align="top"></a>' ..	pogoda_cur_temp .. pogoda_letter .. '</td>'
		else m_simpleTV.OSD.ShowMessage_UTF8("установите дополнение ПОГОДА")
			pogoda_str = ''
		end
	else

--wafee-------------
          if m_simpleTV.User.westSide.ShowWeatherMess then
            m_simpleTV.OSD.ShowMessage_UTF8("дополнение ПОГОДА не установлено")
            m_simpleTV.User.westSide.ShowWeatherMess = false
          end
--wafee-----------
			pogoda_str = ''
	end
--	portal_str = '<table style="font-size: 32px;" width="100%"><tr><td style="padding: 10px 10px 0px; vertical-align: middle;" align="center">' ..	titul_rezka_tor .. titul_hevc .. titul_lostfilm .. titul_newstudio .. ' <font color=#CD7F32><b>' .. data .. ' </b></font>' .. titul_yt .. titul_rezka .. titul_wink .. '</td>' .. pogoda_str .. '</tr></table><table width="100%" border="0"><tr><td style="padding: 0 0 0 10px;"><hr></td></tr></table>'

	portal1_str = '<table style="font-size: 32px;" width="100%"><tr><td style="padding: 10px 10px 0px; vertical-align: middle;"><center>' .. titul_rezka_tor .. titul_hevc .. titul_lostfilm .. titul_newstudio .. titul_yt .. titul_rezka .. titul_wink .. '</td></tr></table><table width="100%" border="0"><tr><td style="padding: 0 0 0 10px;"><hr></td></tr></table>'

	--пагинация титульных категорий
	wink1_str = '<td style="padding: 10px 10px 0px; vertical-align: middle;"><center><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/Wink.png" height="' .. 30*masshtab .. '"></a></td>'
	wink_str = wink1_str .. '<td style="padding: 10px 10px 0px; vertical-align: middle;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/movies\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_video.png" height="' .. 40*masshtab .. '" align="top"></a><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/series\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_series.png" height="' .. 40*masshtab .. '" align="top"></a><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/kids\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_kids.png" height="' .. 40*masshtab .. '" align="top"></a><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/sport\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_sport.png" height="' .. 40*masshtab .. '" align="top"></a><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/333\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_selected.png" height="' .. 40*masshtab .. '" align="top"></a><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=1000\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_tv.png" height="' .. 40*masshtab .. '" align="top"></a></td>'

	titul_str = '<table style="font-size: 32px;" width="100%"><tr>' .. wink_str .. '<td style="padding: 10px 10px 0px; vertical-align: middle;"><font color=#CD7F32><b>' .. data .. ' </b></font></td>' .. pogoda_str .. '</tr></table><table width="100%" border="0"><tr><td style="padding: 0 0 0 10px;"><hr></td></tr></table>'

	local userAgent = 'Mozilla/5.0 (SMART-TV; Linux; Tizen 4.0.0.2) AppleWebkit/605.1.15 (KHTML, like Gecko) SamsungBrowser/9.2 TV Safari/605.1.15'
	local session = m_simpleTV.Http.New(userAgent)
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 18000)
--	if not m_simpleTV.User.Wink then
--		m_simpleTV.User.Wink = {}
--	end

	inAdr = m_simpleTV.Common.multiByteToUTF8(inAdr:gsub('%?start.-$', ''):gsub('%?program.-$', ''))

	local rc, answer = m_simpleTV.Http.Request(session, {url = inAdr:gsub('%?start.-$', ''):gsub('%?program.-$', '')})
--	m_simpleTV.Http.Close(session)
		if rc ~= 200 then return end

	local function getConfigVal(key)
		return m_simpleTV.Config.GetValue(key,"WinkConf.ini")
	end

	local function setConfigVal(key,val)
		m_simpleTV.Config.SetValue(key,val,"WinkConf.ini")
	end

		local function Get_address(title)
		local path = './luaScr/user/TVSources/m3u/out_edem.m3u'
		local file = io.open('./luaScr/user/TVSources/m3u/out_edem.m3u', 'r')
			if not file then
			m_simpleTV.OSD.ShowMessage_UTF8('Необходимо добавить файл ' .. path) return background_chanel else
		local answer_pls = file:read('*a')
		file:close()
			local t_pls, i_pls, t1_address, t1_name  = {}, 1, '', ''
			for tab_pls in answer_pls:gmatch('ExtFilter="Edem"(,.-\n.-\nhttp://.-%.m3u8)') do
			t_pls[i_pls] = {}
			t_pls[i_pls].name, t_pls[i_pls].address = tab_pls:match(',(.-)\n.-\n(http://.-%.m3u8)')
				if t_pls[i_pls].name:gsub(' orig', '') == title then t1_address = t_pls[i_pls].address end
			i_pls = i_pls + 1	
			end
		return t1_address
		end
		end
		
--[[
		local function Get_address(title)
		require 'json'
		local path = './luaScr/user/westSide/zapros/list_channels.json'
		local file = io.open('./luaScr/user/westSide/zapros/list_channels.json', 'r')
			if not file then
			m_simpleTV.OSD.ShowMessage_UTF8('Необходимо добавить файл ' .. path) return end
		local answer_pls = file:read('*a')
		file:close()
		local t_pls, i_pls, t1_address, t1_desc, t1_name  = {}, 1, '', '', ''
		answer_pls = answer_pls:gsub('%[%]', '""')
			local tab_pls = json.decode(answer_pls)
			while tab_pls.channels_list[i_pls] do
					t_pls[i_pls] = {}
					t_pls[i_pls].name = tab_pls.channels_list[i_pls].bcname
					t_pls[i_pls].name = t_pls[i_pls].name:gsub('\\', ''):gsub('5 канал', 'Пятый канал')
					t_pls[i_pls].address = tab_pls.channels_list[i_pls].smlOttURL
					t_pls[i_pls].desc = tab_pls.channels_list[i_pls].bcdesc	or ''
					if t_pls[i_pls].name == title:gsub('коллекция', 'Коллекция'):gsub('Love Nature 4K', 'Love Nature 4K'):gsub('5 канал', 'Пятый канал')
					or t_pls[i_pls].name:match('Известия') and title:match('Известия') or t_pls[i_pls].name:match('мужское') and title:match('Мужское') or t_pls[i_pls].name:match('Ювелирочка') and title:match('Ювелирочка') or t_pls[i_pls].name:match('A2 ПРО ЛЮБОВЬ') and title:match('A2') or t_pls[i_pls].name:match('ПЯТНИЦА') and title:match('Пятница') or t_pls[i_pls].name:match('ЖИВИ') and title:match('ЖИВИ') or t_pls[i_pls].name:match('МАМА') and title:match('Мама') or t_pls[i_pls].name:match('Доктор') and title:match('Доктор') or t_pls[i_pls].name:match('Zee TV') and title:match('Zee TV') or t_pls[i_pls].name=='НСТВ' and title=='НСТ' or t_pls[i_pls].name=='ТЕХНО 24' and title=='Т24' or t_pls[i_pls].name=='Моя планета' and title=='Моя Планета' or t_pls[i_pls].name=='Discovery Channel' and title=='Discovery channel' or t_pls[i_pls].name=='Общественное телевидение России' and title=='ОТР'
					then
					t1_address = t_pls[i_pls].address:gsub('s37630','zabava-htlive'):gsub('s39787','zabava-htlive'):gsub('s72169','zabava-htlive'):gsub('CH_ZEETV','CH_ZEETVHD'):gsub('CH_LOVENATURE4K','CH_LOVENATURE4K_HLS')
					t1_desc = t_pls[i_pls].desc
					t1_name = t_pls[i_pls].name
					end
					if title:match('Shop%&Show') then
					t1_address = 'https://zabava-htlive.cdn.ngenix.net/hls/CH_SHOPANDSHOW/variant.m3u8'
					t1_desc = t_pls[i_pls].desc
					t1_name = t_pls[i_pls].name
					elseif title:match('Радио Disney') then
					t1_address = 'https://zabava-htlive.cdn.ngenix.net/hls/CH_RADIODISNEY/variant.m3u8'
					t1_desc = t_pls[i_pls].desc
					t1_name = t_pls[i_pls].name
					elseif title=='Ратник' then
					t1_address = 'https://zabava-htlive.cdn.ngenix.net/hls/CH_RATNIKHD/variant.m3u8'
					t1_desc = t_pls[i_pls].desc
					t1_name = t_pls[i_pls].name
					elseif title=='Ani' then
					t1_address = 'https://zabava-htlive.cdn.ngenix.net/hls/CH_ANI/variant.m3u8'
					t1_desc = t_pls[i_pls].desc
					t1_name = t_pls[i_pls].name
					elseif title=='Cinema' then
					t1_address = 'https://zabava-htlive.cdn.ngenix.net/hls/CH_PARKRAZVLECHENIJ/variant.m3u8'
					t1_desc = t_pls[i_pls].desc
					t1_name = t_pls[i_pls].name
					elseif title=='Тео-ТВ' then
					t1_address = 'https://rt-mos-htlive.cdn.ngenix.net/hls/CH_R01_OTT_TEOTV/variant.m3u8'
					t1_desc = t_pls[i_pls].desc
					t1_name = t_pls[i_pls].name
					elseif title=='Exxxotica' then
					t1_address = 'https://zabava-htlive.cdn.ngenix.net/hls/CH_EXXXOTICAHD/variant.m3u8'
					t1_desc = t_pls[i_pls].desc
					t1_name = t_pls[i_pls].name
					elseif title=='CCTV-4' then
					t1_address = 'https://zabava-htlive.cdn.ngenix.net/hls/CH_CCTV4/variant.m3u8'
					t1_desc = t_pls[i_pls].desc
					t1_name = t_pls[i_pls].name
					elseif title=='CGTN' then
					t1_address = 'https://zabava-htlive.cdn.ngenix.net/hls/CH_CGTNENG/variant.m3u8'
					t1_desc = t_pls[i_pls].desc
					t1_name = t_pls[i_pls].name
					elseif title=='CGTN Russian' then
					t1_address = 'https://zabava-htlive.cdn.ngenix.net/hls/CH_CGTNRUS/variant.m3u8'
					t1_desc = t_pls[i_pls].desc
					t1_name = t_pls[i_pls].name
					end
				i_pls = i_pls + 1
		end
			return t1_address
		end
--]]		

	local function t_archive(answer_all_epg, program_start_time, epg_genre)
	local te, ie = {}, 1
	epg_genre = tonumber(epg_genre)
	for answer_epg in answer_all_epg:gmatch('<div class="root_r1ru04lg time_t1krzpy3.-</p>') do
		te[ie] = {}
		te[ie].name = answer_epg:match('<h3 class="root_r1ru04lg.->(.-)</h3>')
		te[ie].info = answer_epg:match('<p class="root_r1ru04lg.->(.-)</p>') or ''
		te[ie].time_in = answer_epg:match('<div class="root_r1ru04lg.->(.-)</div>') or ''
		timein_h, timein_m = te[ie].time_in:match('^(%d+):(%d+)$')
		te[ie].timein = timein_h*60*60 + timein_m*60
		te[ie].age_info = answer_epg:match('<span class="root_r1ru04lg.->(.-)</span>') or ''
		te[ie].poster = answer_epg:match('src="(.-)"') or ''
--		te[ie].adress = url
		ie = ie + 1
	end
	local rev_te = {}
	for ie=#te, 1, -1 do
		rev_te[#rev_te+1] = te[ie]
	end

	for ie=1, #rev_te, 1 do

		if ie==1
		then
			rev_te[ie].time_all = 24*60*60 - rev_te[ie].timein
		else
			rev_te[ie].time_all = rev_te[ie-1].timein - rev_te[ie].timein
		end
		if rev_te[ie].time_all < 0 then
			rev_te[ie].time_all = rev_te[ie].time_all + 24*60*60
			timein_data1 = timein_data1 - 24*60*60
		end
		rev_te[ie].time_all_str = math.floor(rev_te[ie].time_all/60)
		rev_te[ie].time_start = timein_data1 + rev_te[ie].timein
		rev_te[ie].time_end = rev_te[ie].time_start + rev_te[ie].time_all
	end

	local n, arc1 = 1, {}
	for n=1, #rev_te, 1 do
		arc1[n] = {}
		if rev_te[n].time_start <= os.time() and rev_te[n].time_start > os.time() - 3*24*60*60
			then
			arc1[n] = rev_te[n]
		end
	end
-----------
			local kc, current_epg  = 1, ''
			for kc = 1, #arc1 do
			if arc1[kc].time_start and arc1[kc].time_end and program_start_time then
				if tonumber(arc1[kc].time_start) <= tonumber(program_start_time) and tonumber(arc1[kc].time_end) > tonumber(program_start_time)
				then
				current_epg_info = arc1[kc].age_info
				background_epg = arc1[kc].poster
				background_epg = background_epg:gsub('176x132', '704x528')
--запуск через PlayAddress
--				arc1[kc].time_play = '<a href = "simpleTVLua:play_timeshift_adr(' .. arc1[kc].time_start  .. ')" style="color: #7FFFD4; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/icons/timeshiftactive.png" height="' .. 54*masshtab .. '" align="top"></a>'
				arc1[kc].time_play = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '?start_time=' .. arc1[kc].time_start .. '\')" style="color: #7FFFD4; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/icons/timeshiftactive.png" height="' .. 54*masshtab .. '" align="top"></a>'

				rezka_poisk = ' <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'#' .. arc1[kc].name .. '\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/Preview.png" height="' .. 36*masshtab .. '" align="top"></a>'
				yt_poisk = ' <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'-' .. arc1[kc].name .. '\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/menuYT.png" height="' .. 36*masshtab .. '" align="top"></a>'
				wink_poisk = ' <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/search?query=' .. m_simpleTV.Common.toPercentEncoding(arc1[kc].name:gsub('^Премьера%.', ''):gsub('%..-$', '')) .. '&tab=1\')" style="color: #BBBBEE; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_video.png" height="' .. 36*masshtab .. '" align="top"></a>'
				arc1[kc].name_str = arc1[kc].name .. rezka_poisk .. yt_poisk .. wink_poisk
				current_epg = '<table width="100%"><tr><td style="padding: 5px 10px 5px; color: #EBEBEB; vertical-align: middle;"><h3><font color=#4169E1>' .. arc1[kc].name_str ..	'</font></h3><h4>' .. arc1[kc].time_play .. ' <font color=#CD7F32>' .. os.date("%a %d %b %Y %H:%M", arc1[kc].time_start):gsub('Sun', 'Вс'):gsub('Mon', 'Пн'):gsub('Tue', 'Вт'):gsub('Wed', 'Ср'):gsub('Thu', 'Чт'):gsub('Fri', 'Пт'):gsub('Sat', 'Сб'):gsub('Jan', 'Янв'):gsub('Feb', 'Фев'):gsub('Mar', 'Мар'):gsub('Apr', 'Апр'):gsub('May', 'Май'):gsub('Jun', 'Июн'):gsub('Jul', 'Июл'):gsub('Aug', 'Авг'):gsub('Sep', 'Сен'):gsub('Oct', 'Окт'):gsub('Nov', 'Ноя'):gsub('Dec', 'Дек') .. '</font></h4><h4><font color=#7F7FFF>' .. arc1[kc].age_info .. '</font></h4><h4><font color=#CD7F32>' .. arc1[kc].time_all_str .. ' мин.</font></h4></td><td style="padding: 5px 5px 0px; color: #EBEBEB;" width="' .. 420*masshtab ..	'"><img src="' .. background_epg .. '" height = "' .. 240*masshtab .. '" width = "' .. 416*masshtab ..	'"></td></tr></table><table width="100%"><tr><td style="padding: 5px 5px 0px; color: #D4D4FF;"><h4>' .. arc1[kc].info .. '</h4></td></tr></table><hr>'
				end
				kc = kc + 1
			end
			end
-----------
		local hash, arc2 = {}, {}
			for k = 1, #arc1 do
				if arc1[k].name and not hash[arc1[k].name]
				then
					arc2[#arc2 + 1] = arc1[k]
					hash[arc1[k].name] = true
				end
			end
		table.sort(arc2, function(a, b) return a.name < b.name end)

		local select_epg_str, desc_tab, i_tab, i_tab1, i_tab2, i_tab3, i_tab4, i_tab5, i_tab6, i_tab7, i_tab8, i_tab9, i_tab10, i_tab11, i_tab12, i_tab13 = '', '', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1

		for ie = 1, #arc2 do
--запуск через PlayAddress
--		arc2[ie].time_play = '<a href = "simpleTVLua:play_timeshift_adr(' .. arc2[ie].time_start  .. ')" style="color: #7FFFD4; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/icons/archive.png" height="' .. 54*masshtab .. '" align="top"></a>'
		arc2[ie].time_play = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '?start_time=' .. arc2[ie].time_start .. '\')" style="color: #7FFFD4; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/icons/archive.png" height="' .. 54*masshtab .. '" align="top"></a>'

		rezka_poisk = ' <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'#' .. arc2[ie].name .. '\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/Preview.png" height="' .. 36*masshtab .. '" align="top"></a>'
		yt_poisk = ' <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'-' .. arc2[ie].name .. '\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/menuYT.png" height="' .. 36*masshtab .. '" align="top"></a>'
		wink_poisk = ' <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/search?query=' .. m_simpleTV.Common.toPercentEncoding(arc2[ie].name:gsub('^Премьера%.', ''):gsub('%..-$', ''):gsub('&quot;', '')) .. '&tab=1\')" style="color: #BBBBEE; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_video.png" height="' .. 36*masshtab .. '" align="top"></a>'
		arc2[ie].name_str = arc2[ie].name .. rezka_poisk .. yt_poisk .. wink_poisk
		arc2[ie].desc = '<table width="100%"><tr><td style="padding: 5px 5px 0px; color: #EBEBEB;" width="' .. 330*masshtab .. '"><img src="' .. arc2[ie].poster:gsub('176x132', '352x264') .. '" height = "' .. 180*masshtab .. '" width = "' .. 312*masshtab .. '"></td><td style="padding: 5px 10px 5px; color: #7F7FFF; vertical-align: middle;"><h3>' .. arc2[ie].name_str .. '</h3><h4>' .. arc2[ie].time_play .. ' <font color=#CD7F32>' .. os.date("%a %d %b %Y %H:%M", arc2[ie].time_start):gsub('Sun', 'Вс'):gsub('Mon', 'Пн'):gsub('Tue', 'Вт'):gsub('Wed', 'Ср'):gsub('Thu', 'Чт'):gsub('Fri', 'Пт'):gsub('Sat', 'Сб'):gsub('Jan', 'Янв'):gsub('Feb', 'Фев'):gsub('Mar', 'Мар'):gsub('Apr', 'Апр'):gsub('May', 'Май'):gsub('Jun', 'Июн'):gsub('Jul', 'Июл'):gsub('Aug', 'Авг'):gsub('Sep', 'Сен'):gsub('Oct', 'Окт'):gsub('Nov', 'Ноя'):gsub('Dec', 'Дек') .. '</font></h4><h4>' .. arc2[ie].age_info .. '</h4><h4><font color=#CD7F32>' .. arc2[ie].time_all_str .. ' мин.</h4></td></tr></table><table width="100%"><tr><td style="padding: 5px 5px 0px; color: #EBEBEB;"><h5>' .. arc2[ie].info .. '</h5></td></tr></table><hr>'

--------жанровая пагинация
		local genres = {
		{"genre1", "Фильмы", ''},
		{"genre2", "Сериалы", ''},
		{"genre3", "Познавательные передачи", ''},
		{"genre4", "Спорт", ''},
		{"genre5", "Музыка", ''},
		{"genre6", "Новости", ''},
		{"genre7", "ТВ-Шоу", ''},
		{"genre8", "Детям", ''},
		{"genre9", "Остальное", ''},
		{"genre10", "Новогодняя", ''},
		{"genre11", "Трейлер", ''},
		{"genre12", "Анонс", ''},
		{"genre13", "Для взрослых", ''},
		}
--		local t_genres={}
		for i = 1, #genres do
		t_genres[i] = {}
		t_genres[i].Name = genres[i][2]
		t_genres[i].Address = genres[i][1]
		t_genres[i].Logo = genres[i][3]
---вывод EPG соответствующего текущей передаче, если epg_genre=0
		if epg_genre == 0 and current_epg_info:gsub('%-', ' '):match(t_genres[i].Name:gsub('%-', ' '))
		then epg_genre = i end
---счетчики
		if arc2[ie].age_info:gsub('%-', ' '):match(t_genres[i].Name:gsub('%-', ' ')) then
		if i == 1 then
		i_tab1 = i_tab1 + 1
		elseif i == 2 then
		i_tab2 = i_tab2 + 1
		elseif i == 3 then
		i_tab3 = i_tab3 + 1
		elseif i == 4 then
		i_tab4 = i_tab4 + 1
		elseif i == 5 then
		i_tab5 = i_tab5 + 1
		elseif i == 6 then
		i_tab6 = i_tab6 + 1
		elseif i == 7 then
		i_tab7 = i_tab7 + 1
		elseif i == 8 then
		i_tab8 = i_tab8 + 1
		elseif i == 9 then
		i_tab9 = i_tab9 + 1
		elseif i == 10 then
		i_tab10 = i_tab10 + 1
		elseif i == 11 then
		i_tab11 = i_tab11 + 1
		elseif i == 12 then
		i_tab12 = i_tab12 + 1
		elseif i == 13 then
		i_tab13 = i_tab13 + 1
		end
		end
		i=i+1
		end
		if arc2[ie].age_info:gsub('%-', ' '):match(t_genres[epg_genre].Name:gsub('%-', ' ')) then
		desc_tab = desc_tab .. arc2[ie].desc
		i_tab = i_tab + 1
		end
		end
--------------------------
		if i_tab1 > 1 then
			if epg_genre ~= 1 then
			select_epg_str = select_epg_str .. ' 🔸 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&epg_genre=1\')" style="color: #EEEEBB; text-decoration: none;">' .. t_genres[1].Name .. ' (' .. i_tab1 - 1 .. ')</a>'
			else select_epg_str = select_epg_str .. ' 🔹 <font color=#ED4830>' .. t_genres[1].Name .. ' (' .. i_tab1 - 1 .. ')</font>' end
		end
		if i_tab2 > 1 then
			if epg_genre ~= 2 then
			select_epg_str = select_epg_str .. ' 🔸 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&epg_genre=2\')" style="color: #EEEEBB; text-decoration: none;">' .. t_genres[2].Name .. ' (' .. i_tab2 - 1 .. ')</a>'
			else select_epg_str = select_epg_str .. ' 🔹 <font color=#ED4830>' .. t_genres[2].Name .. ' (' .. i_tab2 - 1 .. ')</font>' end
		end
		if i_tab3 > 1 then
			if epg_genre ~= 3 then
			select_epg_str = select_epg_str .. ' 🔸 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&epg_genre=3\')" style="color: #EEEEBB; text-decoration: none;">' .. t_genres[3].Name .. ' (' .. i_tab3 - 1 .. ')</a>'
			else select_epg_str = select_epg_str .. ' 🔹 <font color=#ED4830>' .. t_genres[3].Name .. ' (' .. i_tab3 - 1 .. ')</font>' end
		end
		if i_tab4 > 1 then
			if epg_genre ~= 4 then
			select_epg_str = select_epg_str .. ' 🔸 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&epg_genre=4\')" style="color: #EEEEBB; text-decoration: none;">' .. t_genres[4].Name .. ' (' .. i_tab4 - 1 .. ')</a>'
			else select_epg_str = select_epg_str .. ' 🔹 <font color=#ED4830>' .. t_genres[4].Name .. ' (' .. i_tab4 - 1 .. ')</font>' end
		end
		if i_tab5 > 1 then
			if epg_genre ~= 5 then
			select_epg_str = select_epg_str .. ' 🔸 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&epg_genre=5\')" style="color: #EEEEBB; text-decoration: none;">' .. t_genres[5].Name .. ' (' .. i_tab5 - 1 .. ')</a>'
			else select_epg_str = select_epg_str .. ' 🔹 <font color=#ED4830>' .. t_genres[5].Name .. ' (' .. i_tab5 - 1 .. ')</font>' end
		end
		if i_tab6 > 1 then
			if epg_genre ~= 6 then
			select_epg_str = select_epg_str .. ' 🔸 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&epg_genre=6\')" style="color: #EEEEBB; text-decoration: none;">' .. t_genres[6].Name .. ' (' .. i_tab6 - 1 .. ')</a>'
			else select_epg_str = select_epg_str .. ' 🔹 <font color=#ED4830>' .. t_genres[6].Name .. ' (' .. i_tab6 - 1 .. ')</font>' end
		end
		if i_tab7 > 1 then
			if epg_genre ~= 7 then
			select_epg_str = select_epg_str .. ' 🔸 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&epg_genre=7\')" style="color: #EEEEBB; text-decoration: none;">' .. t_genres[7].Name .. ' (' .. i_tab7 - 1 .. ')</a>'
			else select_epg_str = select_epg_str .. ' 🔹 <font color=#ED4830>' .. t_genres[7].Name .. ' (' .. i_tab7 - 1 .. ')</font>' end
		end
		if i_tab8 > 1 then
			if epg_genre ~= 8 then
			select_epg_str = select_epg_str .. ' 🔸 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&epg_genre=8\')" style="color: #EEEEBB; text-decoration: none;">' .. t_genres[8].Name .. ' (' .. i_tab8 - 1 .. ')</a>'
			else select_epg_str = select_epg_str .. ' 🔹 <font color=#ED4830>' .. t_genres[8].Name .. ' (' .. i_tab8 - 1 .. ')</font>' end
		end
		if i_tab9 > 1 then
			if epg_genre ~= 9 then
			select_epg_str = select_epg_str .. ' 🔸 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&epg_genre=9\')" style="color: #EEEEBB; text-decoration: none;">' .. t_genres[9].Name .. ' (' .. i_tab9 - 1 .. ')</a>'
			else select_epg_str = select_epg_str .. ' 🔹 <font color=#ED4830>' .. t_genres[9].Name .. ' (' .. i_tab9 - 1 .. ')</font>' end
		end
		if i_tab10 > 1 then
			if epg_genre ~= 10 then
			select_epg_str = select_epg_str .. ' 🔸 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&epg_genre=10\')" style="color: #EEEEBB; text-decoration: none;">' .. t_genres[10].Name .. ' (' .. i_tab10 - 1 .. ')</a>'
			else select_epg_str = select_epg_str .. ' 🔹 <font color=#ED4830>' .. t_genres[10].Name .. ' (' .. i_tab10 - 1 .. ')</font>' end
		end
		if i_tab11 > 1 then
			if epg_genre ~= 11 then
			select_epg_str = select_epg_str .. ' 🔸 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&epg_genre=11\')" style="color: #EEEEBB; text-decoration: none;">' .. t_genres[11].Name .. ' (' .. i_tab11 - 1 .. ')</a>'
			else select_epg_str = select_epg_str .. ' 🔹 <font color=#ED4830>' .. t_genres[11].Name .. ' (' .. i_tab11 - 1 .. ')</font>' end
		end
		if i_tab12 > 1 then
			if epg_genre ~= 12 then
			select_epg_str = select_epg_str .. ' 🔸 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&epg_genre=12\')" style="color: #EEEEBB; text-decoration: none;">' .. t_genres[12].Name .. ' (' .. i_tab12 - 1 .. ')</a>'
			else select_epg_str = select_epg_str .. ' 🔹 <font color=#ED4830>' .. t_genres[12].Name .. ' (' .. i_tab12 - 1 .. ')</font>' end
		end
		if i_tab13 > 1 then
			if epg_genre ~= 13 then
			select_epg_str = select_epg_str .. ' 🔸 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&epg_genre=13\')" style="color: #EEEEBB; text-decoration: none;">' .. t_genres[13].Name .. ' (' .. i_tab12 - 1 .. ')</a>'
			else select_epg_str = select_epg_str .. ' 🔹 <font color=#ED4830>' .. t_genres[13].Name .. ' (' .. i_tab13 - 1 .. ')</font>' end
		end
		if current_epg and select_epg_str and epg_genre and t_genres[epg_genre] and t_genres[epg_genre].Name and i_tab and desc_tab then
		desc_e = current_epg .. '<table width="100%" border="0"><tr><td style="padding: 0px 5px 5px; vertical-align: middle;">' .. select_epg_str .. '<center><h2><font color=#4169E1>' .. t_genres[epg_genre].Name .. ' Архив: ' .. i_tab - 1 .. '</font></h2></td></tr></table>' .. desc_tab
		else background_epg, current_epg, desc_e = '','','' end
		return background_epg, current_epg, desc_e
	end

----------------logo background
		if inAdr == 'https://wink.rt.ru/tv' or inAdr:match('https://wink%.rt%.ru/tv%?theme=')
		then
			background_epg = './luaScr/user/westSide/icons/Channels.jpg'
			m_simpleTV.Control.ChangeChannelLogo(background_epg, m_simpleTV.Control.ChannelID, 'CHANGE_IF_NOT_EQUAL')
		else
			for answer_data1 in answer:gmatch('<label for=".-</label>') do
				if answer_data1:match('checked') then
					timein_data1 = answer_data1:match('value="(%d+)"')
					timein_data1 = tonumber(timein_data1)
				end
			end
--time stamps
		local pars1, i, url_epg2, url_epg3, url_epg4 = {}, 1, '', '', ''
		for w1 in answer:gmatch('"original_id":%d+,.-"start_time":%d+,"end_time":%d+,') do
			pars1[i] = {}
			pars1[i].original_id, pars1[i].start_time_from_page, pars1[i].end_time_from_page = w1:match('"original_id":(%d+),.-"start_time":(%d+),"end_time":(%d+),')
			if timein_data1 >= tonumber(pars1[i].start_time_from_page) and timein_data1 < tonumber(pars1[i].end_time_from_page) then
			url_epg2 = inAdr .. '?program=' .. pars1[i].original_id .. '&start_time=' .. pars1[i].start_time_from_page
			end
			i = i + 1
		end
		answer_all_epg = answer
		if url_epg2 and url_epg2 ~= '' then
		local rc, answer_epg2 = m_simpleTV.Http.Request(session, {url = url_epg2})
		if rc ~= 200 then return end
		answer_all_epg = answer_epg2 .. answer_all_epg
		local pars2, i = {}, 1
		for w2 in answer_epg2:gmatch('"original_id":%d+,.-"start_time":%d+,"end_time":%d+,') do
			pars2[i] = {}
			pars2[i].original_id, pars2[i].start_time_from_page, pars2[i].end_time_from_page = w2:match('"original_id":(%d+),.-"start_time":(%d+),"end_time":(%d+),')
			if timein_data1 - 24*60*60 >= tonumber(pars2[i].start_time_from_page) and timein_data1 - 24*60*60 < tonumber(pars2[i].end_time_from_page) then
			url_epg3 = inAdr .. '?program=' .. pars2[i].original_id .. '&start_time=' .. pars2[i].start_time_from_page
			end
			i = i + 1
		end
		end
		if url_epg3 and url_epg3 ~= '' then
		local rc, answer_epg3 = m_simpleTV.Http.Request(session, {url = url_epg3})
		if rc ~= 200 then return end
		answer_all_epg = answer_epg3 .. answer_all_epg
		local pars3, i = {}, 1
		for w3 in answer_epg3:gmatch('"original_id":%d+,.-"start_time":%d+,"end_time":%d+,') do
			pars3[i] = {}
			pars3[i].original_id, pars3[i].start_time_from_page, pars3[i].end_time_from_page = w3:match('"original_id":(%d+),.-"start_time":(%d+),"end_time":(%d+),')
			if timein_data1 - 24*60*60*2 >= tonumber(pars3[i].start_time_from_page) and timein_data1 - 24*60*60*2 < tonumber(pars3[i].end_time_from_page) then
			url_epg4 = inAdr .. '?program=' .. pars3[i].original_id .. '&start_time=' .. pars3[i].start_time_from_page
			end
			i = i + 1
		end
		end
		if url_epg4 and url_epg4 ~= '' then
		local rc, answer_epg4 = m_simpleTV.Http.Request(session, {url = url_epg4})
		if rc ~= 200 then return end
		answer_all_epg = answer_epg4 .. answer_all_epg
		end
			program_start = os.time() - m_simpleTV.Timeshift.EpgOffsetRequest / 1000
			background_epg, current_epg, current_archive = t_archive(answer_all_epg, program_start, epg_genre)
				end
--background текущей передачи
	m_simpleTV.Interface.SetBackground({BackColor = 0, PictFileName = background_epg, TypeBackColor = 0, UseLogo = 3, Once = 1})

------------------------------
	title = answer:match('property="og:title" content="(.-)"')
	title = title:gsub('&quot;','"'):gsub('&amp;','&')
	answer_group = answer:match('<div class="scroll.->(.-)</div></form>') or ''
--	if answer_group then
	local tg, j, kg, desc_g, name_grp = {}, 1, 1, '', ''
	for ww in answer_group:gmatch('(<label for=.-)</label>') do

	tg[j] = {}
	tg[j].name = ww:match('<span.->(.-)</span>') or 'Wink'
	tg[j].logo = 'simpleTVImage:./luaScr/user/westSide/genres_tv/' .. tg[j].name .. '.png'
	tg[j].adr = ww:match('<label for="(.-)"') or 'https://wink.rt.ru/tv'
	if tg[j].name and tg[j].adr
	then
	tg[j].adr = 'https://wink.rt.ru/tv?theme=' .. tg[j].adr
	if tg[j].name == 'Все' then tg[j].adr = 'https://wink.rt.ru/tv' end
				if tg[j].adr == inAdr then
				desc_g = desc_g .. '<table style="float: left;font-size: 22px;color: #ED4830; text-decoration: none;" border="0"><tr><td rowspan="2" width="10"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="100" width="1"></td><td width="225" align="center"><img src="' .. tg[j].logo .. '" height="90" width="225"></td></tr><tr><td  style="padding-top: 10px;" width="225" align="center">' .. tg[j].name .. '</td></tr></table>'
				name_grp = tg[j].name
				else
				desc_g = desc_g .. '<table style="float: left;font-size: 22px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="10"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="100" width="1"></td><td width="225" align="center"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. tg[j].adr .. '\')"><img src="' .. tg[j].logo .. '" height="90" width="225"></a></td></tr><tr><td  style="padding-top: 10px;" width="225" align="center">' .. tg[j].name .. '</td></tr></table>'
				end
		j = j + 1
	end
	end
--	end
--favorite
	if inAdr=='https://wink.rt.ru/tv?theme=1000' then
	name_grp = 'Избранные каналы'
	end

	local tm = {}
	local answer_wink = answer:match('<div class="root_r1on6mqn" data%-test="channels%-list">.-</div></div></div></div></main>')
	if answer_wink and not answer:match('<div data%-test="channel%-content" class="root_rf3liu8 content_c1etjow5">') then
	local logo = './luaScr/user/westSide/icons/Channels.jpg'
	local t, i, k, desc = {}, 1, 1, '<table width="100%"><tr>'

---	desc plus
		local path1 = './luaScr/user/TVSources/m3u/out_Wink TV.m3u'
		local file1 = io.open('./luaScr/user/TVSources/m3u/out_Wink TV.m3u', 'r')
			if not file1 then
			m_simpleTV.OSD.ShowMessage_UTF8('Необходимо добавить файл ' .. path1) return end
		local answer_pls1 = file1:read('*a')
		file1:close()
		local t_pls1, i_pls1, desc_plus = {}, 1, ''
			for tab_pls1 in answer_pls1:gmatch('group%-title=".-".-tvg%-logo=".-".-https://wink%.rt%.ru/tv/%d+') do
			t_pls1[i_pls1] = {}
			t_pls1[i_pls1].name_grp1, t_pls1[i_pls1].logo_pls1, t_pls1[i_pls1].adr_pls1 = tab_pls1:match('group%-title="(.-)".-tvg%-logo="(.-)".-(https://wink%.rt%.ru/tv/%d+)')
			if t_pls1[i_pls1].name_grp1:match(name_grp) and not t_pls1[i_pls1].name_grp1:match('UltraHD') or name_grp == 'Все' or name_grp == '4К (UltraHD)' and t_pls1[i_pls1].name_grp1:match('UltraHD') or name_grp == 'Избранные каналы' and tonumber(getConfigVal('favoriteTV/' .. t_pls1[i_pls1].adr_pls1:match('https://wink%.rt%.ru/tv/(%d+)')))==1 then
				desc_plus = desc_plus .. '<table style="float: left;font-size: 32px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td width="240"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. t_pls1[i_pls1].adr_pls1 .. '\')"><img src="' .. t_pls1[i_pls1].logo_pls1 .. '" height="135" width="240"></a></td></tr></table>'
				i_pls1 = i_pls1 + 1
			end
		end


-------------
			tm[1] = {}
					tm[1].Id = 1
					tm[1].Name = title
					tm[1].Address = background_chanel
					tm[1].InfoPanelDesc = '<html><body bgcolor="#434750">' .. titul_str .. desc_g .. '</body><body><table style="font-size: 32px;" width="100%" border="0"><tr><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><p><center><font color=#4169E1>' .. 'Wink TV - ' .. name_grp .. '</td></tr></table>' .. desc_plus .. '</body></html>'
					tm[1].InfoPanelDesc = tm[1].InfoPanelDesc:gsub('"', '\"')
					tm[1].InfoPanelName = tm[1].Name
					tm[1].InfoPanelTitle = title
					tm[1].InfoPanelShowTime = 30000
					tm[1].InfoPanelLogo = './luaScr/user/westSide/icons/Channels.jpg'

		m_simpleTV.Control.CurrentAddress = background_chanel
		inAdr = background_chanel

		m_simpleTV.Control.SetTitle(title)
		m_simpleTV.Control.CurrentTitle_UTF8 = title

elseif answer:match('<div data%-test="channel%-content" class="root_rf3liu8 content_c1etjow5">')
then
local title = answer:match('<h1 class="root_r1ru04lg title_t1kbub20 root_header1_r1swja1w" data%-test="media%-item%-name">(.-)<')
title = title:gsub('&quot;', '"'):gsub('&amp;', '&')
local title_grp = answer:match('<h3 class="root_r1ru04lg subtitle_s12vmtjp root_caption1_.-">(.-)<') or 'Wink TV'

if title == 'Супер' then title_grp = 'Эфирные, Кино и сериалы, Развлекательные' end
--загрузка EPG
--[[
if inAdr:match('https://wink%.rt%.ru/tv/(%d+).-$') and getConfigVal('epg_update/' .. inAdr:match('https://wink%.rt%.ru/tv/(%d+).-$')) then
m_simpleTV.OSD.ShowMessageT({imageParam = 'vSizeFactor="1.0" src="' .. '' .. '"', text = getConfigVal('epg_update/' .. inAdr:match('https://wink%.rt%.ru/tv/(%d+).-$')) .. ' < ' .. os.time(), color = ARGB(255, 63, 63, 255), showTime = 1000 * 60})
end
--]]
if inAdr:match('https://wink%.rt%.ru/tv/(%d+).-$') and (not getConfigVal('epg_update/' .. inAdr:match('https://wink%.rt%.ru/tv/(%d+).-$')) or getConfigVal('epg_update/' .. inAdr:match('https://wink%.rt%.ru/tv/(%d+).-$')) and tonumber(getConfigVal('epg_update/' .. inAdr:match('https://wink%.rt%.ru/tv/(%d+).-$'))) < os.time()-24*60*60)
then GetEPG(inAdr:match('https://wink%.rt%.ru/tv/(%d+).-$'),m_simpleTV.Common.UTF8ToMultiByte(title))
end
--строка Гид
local title_desc = answer:match('{"left":0,"total":0},".-","(.-)"') or title_grp
title_desc = title_desc:gsub('\\', '')
if title_desc == 'age_value' then title_desc = title_grp end
 logo = answer:match('<div class="poster_pbugp4u.-src="(.-)"')
 if logopac_transparent == 1 then
 logo1 = answer:match('{"left":0,"total":0}.-{"id":%d+,"name":"%d+","age_value":%d+},"(.-)",".-",".-"')
 logo2 = answer:match('{"left":0,"total":0}.-{"id":%d+,"name":"%d+","age_value":%d+},".-",".-","(.-)"')
 else
 logo1 = answer:match('{"left":0,"total":0}.-{"id":%d+,"name":"%d+","age_value":%d+},".-",".-","(.-)"')
 logo2 = answer:match('{"left":0,"total":0}.-{"id":%d+,"name":"%d+","age_value":%d+},"(.-)",".-",".-"')
 end
 logo1 = 'https://s26037.cdn.ngenix.net/' .. logo1
 logo2 = 'https://s26037.cdn.ngenix.net/' .. logo2
 retAdr = Get_address(title)
---------------
--строка крошек
local title_grp_all = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Все.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Все</font></h5></a></td>'
local group_td_178 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=178\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/4К (UltraHD).png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>4К (UltraHD)</font></h5></a></td>'
local group_td_2 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=2\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/HD.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>HD</font></h5></a></td>'
local group_td_4 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=4\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Эфирные.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Эфирные</font></h5></a></td>'
local group_td_12 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=12\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Спортивные.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Спортивные</font></h5></a></td>'
local group_td_11 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=11\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Кино и сериалы.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Кино и сериалы</font></h5></a></td>'
local group_td_5 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=5\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Развлекательные.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Развлекательные</font></h5></a></td>'
local group_td_3 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=3\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Информационные.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Информационные</font></h5></a></td>'
local group_td_13 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=13\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Детские.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Детские</font></h5></a></td>'
local group_td_6 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=6\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Познавательные.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Познавательные</font></h5></a></td>'
local group_td_7 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=7\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Музыкальные.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Музыкальные</font></h5></a></td>'
local group_td_10 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=10\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Взрослые.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Взрослые</font></h5></a></td>'
local group_td_8 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=8\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Телемагазины.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Телемагазины</font></h5></a></td>'
local group_td_179 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=179\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Радио.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Радио</font></h5></a></td>'
local group_td_73 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=73\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Здоровье.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Здоровье</font></h5></a></td>'
local group_td_69 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=69\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Бесплатные.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Бесплатные</font></h5></a></td>'
local group_td_173 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=173\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Кулинарные.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Кулинарные</font></h5></a></td>'
local group_td_9 = '<td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.rt.ru/tv?theme=9\')" style="color: #EBEBEB; text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/genres_tv/Региональные.png" height = "' .. 60*masshtab .. '" width = "' .. 150*masshtab .. '"><h5><center><font color=#EBEBEB>Региональные</font></h5></a></td>'
if title_grp:match('4К') then title_grp_all = title_grp_all .. group_td_178 end
if title_grp:match('HD') and not title_grp:match('4К') then title_grp_all = title_grp_all .. group_td_2 end
if title_grp:match('Эфирные') then title_grp_all = title_grp_all .. group_td_4 end
if title_grp:match('Спортивные') then title_grp_all = title_grp_all .. group_td_12 end
if title_grp:match('Кино и сериалы') then title_grp_all = title_grp_all .. group_td_11 end
if title_grp:match('Развлекательные') then title_grp_all = title_grp_all .. group_td_5 end
if title_grp:match('Информационные') then title_grp_all = title_grp_all .. group_td_3 end
if title_grp:match('Детские') then title_grp_all = title_grp_all .. group_td_13 end
if title_grp:match('Познавательные') then title_grp_all = title_grp_all .. group_td_6 end
if title_grp:match('Музыкальные') then title_grp_all = title_grp_all .. group_td_7 end
if title_grp:match('Взрослые') then title_grp_all = title_grp_all .. group_td_10 end
if title_grp:match('Телемагазины') then title_grp_all = title_grp_all .. group_td_8 end
if title_grp:match('Радио') then title_grp_all = title_grp_all .. group_td_179 end
if title_grp:match('Здоровье') then title_grp_all = title_grp_all .. group_td_73 end
if title_grp:match('Бесплатные') then title_grp_all = title_grp_all .. group_td_69 end
if title_grp:match('Кулинарные') then title_grp_all = title_grp_all .. group_td_173 end
if title_grp:match('Региональные') then title_grp_all = title_grp_all .. group_td_9 end

		if tonumber(getConfigVal('favoriteTV/' .. inAdr:match('https://wink%.rt%.ru/tv/(%d+)')))==1
			then
				favorite_tv = 'favoriteON'
		elseif tonumber(getConfigVal('favoriteTV/' .. inAdr:match('https://wink%.rt%.ru/tv/(%d+)')))==0 or not getConfigVal('favoriteTV/' .. inAdr:match('https://wink%.rt%.ru/tv/(%d+)'))
			then
				favorite_tv = 'favoriteOFF'
		end

group_str = '<td style="padding: 5px 5px 0px; color: #EBEBEB; vertical-align: middle;"><a href = "simpleTVLua:GetEPG(' .. inAdr:match('https://wink%.rt%.ru/tv/(%d+).-$')  .. ', \'' .. title:gsub('&quot;', '"') .. '\')" style="color: #7FFFD4; text-decoration: none;"><center><img src="simpleTVImage:./luaScr/user/westSide/icons/epg.png" height="' .. 50*masshtab .. '" align="top"></a></br><a href = "simpleTVLua:FavoriteTV(' .. inAdr:match('https://wink%.rt%.ru/tv/(%d+).-$')  .. ', \'' .. logo2 .. '\')" style="color: #7FFFD4; text-decoration: none;"><center><img src="simpleTVImage:./luaScr/user/westSide/icons/' .. favorite_tv .. '.png" height="' .. 50*masshtab .. '" align="top"></a></td><td style="padding: 5px 5px 0px; color: #EBEBEB;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '\')" style="color: #7FFFD4; text-decoration: none;"><center><img src="simpleTVImage:./luaScr/user/westSide/icons/play.png" height="' .. 60*masshtab .. '" align="top"><h5><center><font color=#EBEBEB>Эфир</font></h5></a></td><td style="padding: 5px 5px 0px; color: #EBEBEB;"><center><img src="' .. logo1 .. '" height = "' .. 60*masshtab .. '"><h5><center><font color=#ED4830>' .. title:gsub('&quot;', '"') .. '</font></h5></td>' .. title_grp_all .. '</tr></table>'

--------------

			tm[1] = {}
					tm[1].Id = 1
					tm[1].Name = title:gsub('&quot;', '"')
					tm[1].Address = retAdr
					tm[1].InfoPanelDesc = '<html><body ><table style="font-size: 32px;" width="100%"><tr>' .. wink1_str .. group_str .. current_archive .. '<table style="font-size: 32px;" width="100%"><tr>' .. wink_str .. '</tr></table></body></html>'
					tm[1].InfoPanelDesc = tm[1].InfoPanelDesc:gsub('"', '\"')
					tm[1].InfoPanelName = tm[1].Name
					tm[1].InfoPanelTitle = title_desc
					tm[1].InfoPanelShowTime = 30000
					tm[1].InfoPanelLogo = logo

			m_simpleTV.Control.CurrentAddress = retAdr:gsub('%?.-$', '')

	if m_simpleTV.Control.MainMode == 0 then
		m_simpleTV.Control.ChangeChannelLogo(logo1, m_simpleTV.Control.ChannelID, 'CHANGE_IF_NOT_EQUAL')
		m_simpleTV.Control.ChangeChannelName(title:gsub('&quot;', '"'), m_simpleTV.Control.ChannelID, true)
	end
		m_simpleTV.Control.SetTitle(title)
		m_simpleTV.Control.CurrentTitle_UTF8 = title

end
--wafee
 local t = {}
 t.message = tm[1].InfoPanelDesc
 t.richTextMode = true
 t.header = tm[1].InfoPanelTitle
 t.showTime = -1
 t.once = true
 t.textAlignment = 1
 t.windowAlignment = 2
 t.windowMaxSizeH = 1
 t.windowMaxSizeV = 1

 if m_simpleTV.User.westSide.PortalTable==nil then
   m_simpleTV.User.westSide.PortalTable=t --кешируем данные в юзер таблицу
 end
if not inAdr:match('https://wink%.rt%.ru/tv/%d+') or retAdr == background_chanel then
 show_portal_window() -- hotkey 'I'
end

-------------------------------------------------