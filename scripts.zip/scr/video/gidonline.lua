-- видеоскрипт для сайта https://gidonline.io (28/2/20)
-- необходимы скрипты: videocdn
-- открывает подобные ссылки:
-- https://gidonline.io/film/gonki-pushechnoe-yadro/
		if m_simpleTV.Control.ChangeAddress ~= 'No' then return end
		if not m_simpleTV.Control.CurrentAddress:match('^https?://gidonline%.') then return end
	local inAdr = m_simpleTV.Control.CurrentAddress
	local host = inAdr:match('https?://[^/]+')
	m_simpleTV.OSD.ShowMessageT({text = '', showTime = 1000, id = 'channelName'})
	if m_simpleTV.Control.MainMode == 0 then
		m_simpleTV.Interface.SetBackground({BackColor = 0, TypeBackColor = 0, PictFileName = host .. '/im/gidonline.png', UseLogo = 1, Once = 1})
	end
	local function showError(str)
		m_simpleTV.OSD.ShowMessageT({text = 'gidonline ошибка: ' .. str, showTime = 5000, color = ARGB(255, 255, 0, 0), id = 'channelName'})
	end
	m_simpleTV.Control.ChangeAddress = 'Yes'
	m_simpleTV.Control.CurrentAddress = ''
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36')
		if not session then
			showError('0')
		 return
		end
	m_simpleTV.Http.SetTimeout(session, 8000)
	local rc, answer = m_simpleTV.Http.Request(session, {url = inAdr})
	m_simpleTV.Http.Close(session)
		if rc ~= 200 then
			showError('1 - ' .. rc)
		 return
		end
	answer = answer:gsub('<!%-%-.-%-%->', '')
	local retAdr = answer:match('<iframe.-src="([^&"]+)')
		if not retAdr then
			showError('2')
		 return
		end
	local title = answer:match('"og:title" content="([^"]+)') or 'gidonline'
	local poster = answer:match('"og:image" content="([^"]+)') or (host .. '/im/gidonline.png')
	poster = poster:gsub('^/', host .. '/')
	if m_simpleTV.Control.MainMode == 0 then
		m_simpleTV.Control.ChangeChannelLogo(poster, m_simpleTV.Control.ChannelID)
		m_simpleTV.Control.ChangeChannelName(title, m_simpleTV.Control.ChannelID, false)
	end
	m_simpleTV.Control.CurrentTitle_UTF8 = title
	retAdr = retAdr:gsub('^//', 'http://')
	m_simpleTV.Control.ChangeAddress = 'No'
	m_simpleTV.Control.CurrentAddress = retAdr .. '&kinopoisk'
	dofile(m_simpleTV.MainScriptDir .. 'user\\video\\video.lua')
-- debug_in_file(retAdr .. '\n')