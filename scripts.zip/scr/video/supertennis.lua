-- видеоскрипт для сайта http://www.supertennis.tv (14/1/19)
-- открывает: http://www.supertennis.tv
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
		if not inAdr then return end
		if not inAdr:match('^%s*https?://www%.supertennis%.tv') then return end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = 'error'
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/71.0.2785.143 Safari/537.36')
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 8000)
	local rc, answer = m_simpleTV.Http.Request(session, {url = 'http://advplayer.morescreens.eu/supertennis/index1.php'})
	m_simpleTV.Http.Close(session)
		if rc ~= 200 then return end
	local token = answer:match('(%?token=.-)"')
		if not token then return end
	local retAdr = 'https://supertennistv.securelive.ipcache.net/smil:super.smil/playlist.m3u8' .. token
	m_simpleTV.Control.CurrentAdress = retAdr
-- debug_in_file(retAdr .. '\n')