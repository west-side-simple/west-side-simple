-- видео скрипт для сайта http://the-cinema.club (1/4/18)
-- необходимы скрипты: moonwalk, kodik, hdgo
-- открывает подобные ссылки:
-- http://the-cinema.club/film2018/42088-apgreyd.html
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
		if not inAdr then return end
		if not inAdr:match('https?://the%-cinema%.') and not inAdr:match('https?://the%-c%.me') then return end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = ''
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.2785.143 Safari/537.36')
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 8000)
	local rc, answer = m_simpleTV.Http.Request(session, {url = inAdr, method = 'post'})
	m_simpleTV.Http.Close(session)
		if rc ~= 200 then
			m_simpleTV.OSD.ShowMessage_UTF8('the-cinema ошибка[1]-' .. rc, 255, 5)
		 return
		end
	local retAdr = answer:match('<noindex><center>.-<iframe.-src=".-</center></noindex>')
		if not retAdr then
			m_simpleTV.OSD.ShowMessage_UTF8('the-cinema ошибка[2]-' .. rc, 255, 5)
		  return
		end
	local title = answer:match('<title>(.-)</title>') or 'the-cinema'
	title = title:gsub(' %(.+', '')
	if m_simpleTV.Control.CurrentTitle_UTF8 then m_simpleTV.Control.CurrentTitle_UTF8 = title end
	m_simpleTV.OSD.ShowMessageT({text = title, color = ARGB(255, 255, 255, 255), showTime = 1000 * 5, id = "channelName"})
	local q, i = {}, 1
		for Adr in retAdr:gmatch('<iframe.-src="(.-)".-</iframe>') do
			q[i] = {}
			q[i].Id = i
			q[i].Adress = Adr
			q[i].Name = 'плеер ' .. i
			i = i + 1
		end
		if i == 1 then
			m_simpleTV.OSD.ShowMessage_UTF8('the-cinema ошибка[3]-' .. rc, 255, 5)
		  return
		end
	if i > 2 then
		local _, id = m_simpleTV.OSD.ShowSelect_UTF8('Выбрать - ' .. title, 0, q, 5000, 1)
		if not id then id = 1 end
		retAdr = q[id].Adress
	else
		retAdr = q[1].Adress
	end
	m_simpleTV.Control.ChangeAdress = 'No'
	m_simpleTV.Control.CurrentAdress = retAdr:gsub('^//', 'http://'):gsub('&amp;', '&')
	dofile(m_simpleTV.MainScriptDir .. 'user\\video\\video.lua')
-- debug_in_file(retAdr .. '\n')