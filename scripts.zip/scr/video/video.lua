-- (22/1/21)
-- mod by Nexterr | https://github.com/Nexterr/simpleTV
	require 'ex'
	require 'json'
		if m_simpleTV.Control.ChangeAddress ~= 'No' then return end
		if not m_simpleTV.Control.CurrentAddress then return end
	if not package.path:match('user/video/core', 0) then
		package.path = package.path .. ';' .. m_simpleTV.MainScriptDir .. 'user/video/core/?.lua'
	end
	m_simpleTV.Logger.WriteToLog(m_simpleTV.Common.fromPercentEncoding(m_simpleTV.Common.multiByteToUTF8(m_simpleTV.Control.CurrentAddress)), 0, 'address')
	local pathname = m_simpleTV.MainScriptDir .. 'user/video/'
		for entry in os.dir(pathname) do
			if entry.name:match('%.lua$')
				and not entry.name:match('^video%.lua$')
			then
				dofile(m_simpleTV.MainScriptDir .. 'user/video/' .. entry.name)
					if m_simpleTV.Control.ChangeAddress ~= 'No' then break end
			end
		end
-- debug_in_file(m_simpleTV.Control.CurrentAddress .. '\n')
