-- видеоскрипт для сайта https://w2.kinogid.com (26/2/20)
-- необходимы скрипты: ok
-- открывает подобные ссылки:
-- https://w2.kinogid.com/film/chetyre_komnaty/
		if m_simpleTV.Control.ChangeAddress ~= 'No' then return end
		if not m_simpleTV.Control.CurrentAddress:match('^https?://[%w%.]*kinogid%.') then return end
	local inAdr = m_simpleTV.Control.CurrentAddress
	m_simpleTV.OSD.ShowMessageT({text = '', showTime = 1000, id = 'channelName'})
	if m_simpleTV.Control.MainMode == 0 then
		m_simpleTV.Interface.SetBackground({BackColor = 0, TypeBackColor = 0, PictFileName = 'https://w2.kinogid.com/logo.png', UseLogo = 1, Once = 1})
	end
	local function showError(str)
		m_simpleTV.OSD.ShowMessageT({text = 'kinogid ошибка: ' .. str, showTime = 5000, color = ARGB(255, 255, 0, 0), id = 'channelName'})
	end
	m_simpleTV.Control.ChangeAddress = 'Yes'
	m_simpleTV.Control.CurrentAddress = ''
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3785.143 Safari/537.36', nil, true)
		if not session then
			showError('1')
		 return
		end
	m_simpleTV.Http.SetTimeout(session, 8000)
	local rc, answer = m_simpleTV.Http.Request(session, {url = inAdr})
		if rc ~= 200 then
			showError('2')
			m_simpleTV.Http.Close(session)
		 return
		end
	answer = answer:gsub('<!%-%-.-%-%->', '')
	local title = answer:match('property="og:title" content="([^"]+)') or 'kinogid'
	local poster = answer:match('property="ya:ovs:poster" content="([^"]+)') or 'https://w2.kinogid.com/logo.png'
	local embedUrl = answer:match('<iframe itemprop="embedUrl".-src="([^"]+)')
		if not embedUrl then
			showError('3')
		 return
		end
	rc, answer = m_simpleTV.Http.Request(session, {url = embedUrl})
	m_simpleTV.Http.Close(session)
		if rc ~= 200 then
			showError('4')
		 return
		end
	local url = answer:match('<iframe.-src="([^"]+)')
		if not url then
			showError('5')
		 return
		end
	local retAdr
	if url:match('/videoembed/%d+') then
		retAdr = url:gsub('.-/(videoembed/.+)', 'http://ok.ru/%1')
	end
		if not retAdr then
			showError('6')
		 return
		end
	if m_simpleTV.Control.MainMode == 0 then
		m_simpleTV.Control.ChangeChannelLogo(poster, m_simpleTV.Control.ChannelID)
		m_simpleTV.Control.ChangeChannelName(title, m_simpleTV.Control.ChannelID, false)
	end
	m_simpleTV.Control.CurrentTitle_UTF8 = title
	m_simpleTV.OSD.ShowMessageT({text = title, showTime = 5000, id = 'channelName'})
	m_simpleTV.Control.ChangeAddress = 'No'
	m_simpleTV.Control.CurrentAddress = retAdr
	dofile(m_simpleTV.MainScriptDir .. 'user\\video\\video.lua')
-- debug_in_file(retAdr .. '\n')