-- видеоскрипт для поиска видео на сайте https://www.youtube.com (3/2/19)
-- необходимы скрипты: !youtube
-- искать через команду меню "Открыть URL (Ctrl+N)"
-- использовать префикс:
-- "-" для видео
-- "--" плейлистов
-- "---" каналов
-- "-+" прямых трансляций
-- открывает подобные запросы: -Маша и Медведь; --мосфильм; ---jakson vevo; -+ вселенная
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
		if not inAdr then return end
		if not inAdr:match('^%-') then return end
	require 'json'
	if m_simpleTV.Control.CurrentTitle_UTF8 and m_simpleTV.Control.CurrentTitle_UTF8:match('^%-') then m_simpleTV.OSD.ShowMessageT({text = '', showTime = 1000 * 5, id = 'channelName'}) end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = ''
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/71.0.2785.143 Safari/537.36')
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 8000)
	m_simpleTV.Interface.SetBackground({BackColor = 0, BackColorEnd = 255, PictFileName = 'https://www.youtube.com/yts/img/ringo/img/image-hh-404-vflP3hqNT.png', TypeBackColor = 0, UseLogo = 1, Once = 1})
	if not m_simpleTV.User then
		m_simpleTV.User = {}
	end
	if not m_simpleTV.User.Ytube then
		m_simpleTV.User.Ytube = {}
	end
	if not m_simpleTV.User.Ytube.Cookies then
		m_simpleTV.User.Ytube.Cookies = ''
		local error_text, pm = pcall(require, 'pm')
		if package.loaded.pm then
			local ret, login, pass = pm.GetTestPassword('youtube', 'YouTube', true)
			if pass and pass ~= '' then
				pass = pass .. ';'
				m_simpleTV.User.Ytube.Cookies = pass:gsub('PREF=.-;', '')
			end
		end
	end
	if not m_simpleTV.User.Ytube.ApiKey then
		local rc, answer = m_simpleTV.Http.Request(session, {url = 'https://www.youtube.com/s/tv/html5/loader/live.js', headers = 'Cookie: ' .. m_simpleTV.User.Ytube.Cookies})
		local labels = answer:match('labels={\'default\':\'(.-)\'') or ''
		local rc, answer = m_simpleTV.Http.Request(session, {url = 'https://www.youtube.com/s/tv/html5/' .. labels .. '/app-prod.js', headers = 'Cookie: ' .. m_simpleTV.User.Ytube.Cookies})
		local ApiKey = answer:match('%?.%.getApiKey%(%):.-"(.-)"')
		if ApiKey and ApiKey ~= '' then
			m_simpleTV.User.Ytube.ApiKey = ApiKey
			m_simpleTV.User.Ytube.ApiKeyHeader = 'Referer:https://www.youtube.com/tv'
		else
			m_simpleTV.User.Ytube.ApiKey = decode64('QUl6YVN5Q05DZVgwbUpYWHZDSVNuaHBCS3pkc1hKSWVVc19KQmxJ')
			m_simpleTV.User.Ytube.ApiKeyHeader = decode64('UmVmZXJlcjpodHRwczovL25leHRlcnItc2ltcGxldHYucnU=')
		end
	end
	local types, urlyoutube, header
	local eventType = ''
	if inAdr:match('^%-%-%-') then
		types = 'channel'
		header = 'каналы'
		urlyoutube = 'channel/'
	elseif inAdr:match('^%-%-') then
		types = 'playlist'
		header = 'плейлисты'
		urlyoutube = 'playlist?list='
	elseif inAdr:match('^%-%+') then
		eventType = '&eventType=live'
		types = 'video'
		header = 'эфир'
		urlyoutube = 'watch?v='
	else
		types = 'video'
		header = 'видео'
		urlyoutube = 'watch?v='
	end
	inAdr = inAdr:gsub('^[%-%+]+', '')
	inAdr = m_simpleTV.Common.multiByteToUTF8(inAdr)
	local url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=' .. escape(inAdr) .. '&type=' .. types .. '&fields=items/id,items/snippet/title&maxResults=50' .. eventType .. '&key='
	local rc, answer = m_simpleTV.Http.Request(session, {url = url .. m_simpleTV.User.Ytube.ApiKey, headers = m_simpleTV.User.Ytube.ApiKeyHeader})
	m_simpleTV.Http.Close(session)
		if rc ~= 200 then return end
	local tab = json.decode(answer:gsub('(%[%])', '"nil"'):gsub(string.char(239, 187, 191), ''))
		if not tab then return end
	local t, i = {}, 1
		while true do
				if not tab.items[i] then break end
			t[i] = {}
			t[i].Id = i
			t[i].Name = tab.items[i].snippet.title
			t[i].Adress = 'https://www.youtube.com/' .. urlyoutube .. (tab.items[i].id.videoId or tab.items[i].id.playlistId or tab.items[i].id.channelId)
			i = i + 1
		end
		if i == 1 then
			m_simpleTV.OSD.ShowMessageT({text = 'не найдено\n\npoisk_!youtube ошибка[1]', color = ARGB(255, 255, 0, 0), showTime = 1000 * 10, id = 'channelName'})
		 return
		end
	t.ExtButton1 = {ButtonEnable = true, ButtonName = '🞂'}
	t.ExtButton0 = {ButtonEnable = true, ButtonName = '❌'}
	local ret, id = m_simpleTV.OSD.ShowSelect_UTF8(inAdr  .. ' - найдено на YouTube (' .. header .. ')', 0, t, 0, 1+4+8)
		if ret == 2 or not id then return end
	local retAdr = t[id].Adress
	if ret == 3 then
		m_simpleTV.Control.ChangeAdress = 'No'
		m_simpleTV.Control.CurrentAdress = retAdr
		dofile(m_simpleTV.MainScriptDir .. 'user/video/!youtube.lua')
		m_simpleTV.Control.ChangeAdress = 'Yes'
		retAdr = m_simpleTV.Control.CurrentAdress
		m_simpleTV.Control.CurrentAdress = retAdr
	 end
	if ret == 1 then
		m_simpleTV.Control.PlayAddress(t[id].Adress)
	end
-- debug_in_file(retAdr .. '\n')