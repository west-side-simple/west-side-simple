-- видеоскрипт для плейлиста "itv uz" https://itv.uz (29/4/20)
-- открывает подобные ссылки:
-- https://itv.uz/55
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
		if not inAdr then return end
		if not inAdr:match('^https://itv%.uz/%d+') then return end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = 'error'
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.2785.143 Safari/537.36')
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 8000)
	local url = decode64('aHR0cHM6Ly9pdHYudXov')
	local headers = 'X-Requested-With: XMLHttpRequest\nReferer: ' .. url
	local id = inAdr:match('%d+')
	local rc, answer = m_simpleTV.Http.Request(session, {url = url .. decode64('YXBpMi9jaGFubmVscy9zaG93Y2hhbm5lbD9pZD0') .. id, method = 'post', headers = headers})
	m_simpleTV.Http.Close(session)
		if rc ~= 200 then return end
	local retAdr = answer:match('"source_url":"(.-)"')
		if not retAdr then return end
	retAdr = retAdr
			.. '$OPT:NO-STIMESHIFT'
	m_simpleTV.Control.CurrentAdress = retAdr
-- debug_in_file(retAdr .. '\n')