-- видеоскрипт для видеобазы "HDbaza" (2/2/19)
-- открывает подобные ссылки:
-- https://vidozzz.com/iframe?movie_hash=b45a5072586fe870&user_hash=4be9258f86f2ca5d
-- https://myhdplr.com/iframe?mh=9d05d126619e4339&uh=4be9258f86f2ca5d
------------------------------------------------------------------------------------------
local noad = 0 -- пропускать рекламу в начале, сек.
------------------------------------------------------------------------------------------
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
		if not inAdr then return end
		if not inAdr:match('^https?://vidozzz%.com') and not inAdr:match('^$HDbaza') and not inAdr:match('^https?://myhdplr%.com') then return end
	m_simpleTV.OSD.ShowMessageT({text = '', showTime = 1000 * 5, id = 'channelName'})
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = ''
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.81 Safari/537.36')
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 8000)
	if not m_simpleTV.User then
		m_simpleTV.User = {}
	end
	if not m_simpleTV.User.HDbaza then
		m_simpleTV.User.HDbaza = {}
	end
	if not m_simpleTV.User.HDbaza.RES then
		m_simpleTV.User.HDbaza.RES = tonumber(m_simpleTV.Config.GetValue('HDbazaRES') or '10000')
	end
	local title
	if m_simpleTV.User.HDbaza.Tabletitle then
		local index = m_simpleTV.Control.GetMultiAddressIndex()
		if index then
			title = m_simpleTV.User.HDbaza.title .. ' - ' .. m_simpleTV.User.HDbaza.Tabletitle[index+1].Name
		end
	end
	local function unblock(Adr)
		Adr = Adr:gsub('$HDbaza', '')
		local rc, answer = m_simpleTV.Http.Request(session, {url = 'http://noblockme.ru/api/anonymize?url=' .. m_simpleTV.Common.toPersentEncoding(Adr)})
			if rc ~= 200 or (rc == 200 and not answer:match('"status":0')) then return end
		Adr = answer:match('"result":"(.-)"')
			if not Adr then return end
		rc, answer = m_simpleTV.Http.Request(session, {url = Adr, headers = 'Referer:' .. Adr})
			if rc ~= 200 then return end
	 return answer
	end
	local function GetMaxResolutionIndex(t)
		local index
		for u = 1, #t do
				if t[u].res and (m_simpleTV.User.HDbaza.RES) < t[u].res then break end
			index = u
		end
	 return index or 1
	end
	local function GetHDbazaAddress(answer)
		local proto = answer:match('proto: \'(.-)\'')
		local host = answer:match('host: "(.-)"')
		local hls = answer:match('hls_master_file_path: \'(.-)\'')
			if not proto or not host or not hls then return end
		local retAdr = proto .. host .. hls
		local rc, answer = m_simpleTV.Http.Request(session, {url = retAdr, headers = 'Referer:' .. inAdr})
			if rc ~= 200 then return end
		local t, i = {}, 1
		local name, adr
			for w in answer:gmatch('#EXT%-X%-STREAM%-INF:(.-m3u8)') do
				name = w:match('RESOLUTION=(.-),')
				adr = w:match('(http.+)')
					if not name or not adr then break end
				name = name:match('x(%d+)') or '10'
				t[i] = {}
				t[i].Id = i
				t[i].Name = name
				t[i].Adress = adr
				t[i].res = tonumber(name)
				i = i + 1
			end
		table.sort(t, function(a, b) return a.res < b.res end)
		for i = 1, #t do t[i].Id = i end
		m_simpleTV.User.HDbaza.ResolutionTable = t
		local index = GetMaxResolutionIndex(t)
		m_simpleTV.User.HDbaza.Index = index
		retAdr = t[index].Adress
	 return retAdr
	end
	function Quality_HDbaza()
		local t = m_simpleTV.User.HDbaza.ResolutionTable
			if not t then return end
		local index = m_simpleTV.User.HDbaza.Index
		t.ExtButton1 = {ButtonEnable = true, ButtonName = '❌', ButtonScript = 'm_simpleTV.Control.ExecuteAction(37)'}
		if m_simpleTV.User.HDbaza.isVideo == false then
			t.ExtButton0 = {ButtonEnable = true, ButtonName = '💾', ButtonScript = 'SaveHDbazaPlaylist()'}
		end
		if #t > 1 then
			local ret, id = m_simpleTV.OSD.ShowSelect_UTF8('⚙  Качество', index-1, t, 5000, 1+4)
			if ret == 1 then
				m_simpleTV.User.HDbaza.Index = id
				m_simpleTV.User.HDbaza.RES = t[id].res
				m_simpleTV.Control.SetNewAddress(t[id].Adress, m_simpleTV.Control.GetPosition())
				m_simpleTV.Config.SetValue('HDbazaRES', t[id].res)
			end
			if ret == 2 then
				SaveHDbazaPlaylist()
			end
		end
	end
	function SaveHDbazaPlaylist()
		if m_simpleTV.User.HDbaza.Tabletitle then
			m_simpleTV.OSD.ShowMessageT({text = 'Сохранение плейлиста ...', color = ARGB(255, 155, 255, 155), showTime = 1000 * 60, id = 'channelName'})
			local t = m_simpleTV.User.HDbaza.Tabletitle
			local grp = m_simpleTV.User.HDbaza.title
			local adr, name
			local m3ustr = '#EXTM3U $ExtFilter="' .. grp .. '" $BorpasFileFormat="1"\n'
				for i = 1, #t do
					name = t[i].Name
					adr = t[i].Adress:gsub('$HDbaza', '')
					local rc, answer = m_simpleTV.Http.Request(session, {url = adr, headers = 'Referer:' .. adr})
						if rc ~= 200 then
							answer = unblock(inAdr)
								if not answer then
									m_simpleTV.OSD.ShowMessageT({text = 'Невозможно получить плейлист\nHDbaza ошибка[5]-' .. rc, color = ARGB(255, 155, 255, 155), showTime = 1000 * 5, id = 'channelName'})
								 return
								end
						end
					adr = GetHDbazaAddress(answer)
					m3ustr = m3ustr .. '#EXTINF:-1 group-title="' .. grp .. '",' .. name .. '\n' .. adr:gsub('%$OPT:.+', '') .. '\n'
				end
			grp = m_simpleTV.Common.UTF8ToMultiByte(grp)
			grp = string.gsub(grp,'[\\/:%*"<>%|%?]+', ' ')
			local filename = m_simpleTV.Common.GetMainPath(1) .. grp .. '.m3u'
			local fhandle = io.open(filename, 'w+')
			fhandle:write(m3ustr)
			fhandle:close()
			fhandle = io.open(filename)
			if fhandle then
				m_simpleTV.OSD.ShowMessageT({text = '', color = ARGB(0, 0, 0, 0), showTime = 1000, id = 'channelName'})
				m_simpleTV.Interface.MessageBox('Плейлист сохранен в\n' .. m_simpleTV.Common.multiByteToUTF8(filename), 'Плейлист', 0, 0)
			else
				m_simpleTV.OSD.ShowMessageT({text = '', color = ARGB(0, 0, 0, 0), showTime = 1000, id = 'channelName'})
				m_simpleTV.Interface.MessageBox('Невозможно сохранить', 'Плейлист', 0, 0)
			end
			io.close(fhandle)
		end
	end
	local function play(answer)
		local retAdr = GetHDbazaAddress(answer)
		if retAdr then
			if m_simpleTV.Control.CurrentTitle_UTF8 then
				m_simpleTV.Control.CurrentTitle_UTF8 = title
			end
			m_simpleTV.OSD.ShowMessageT({text = title, color = ARGB(255, 155, 155, 255), showTime = 1000 * 5, id = 'channelName'})
			m_simpleTV.Control.CurrentAdress = retAdr .. '$OPT:start-time=' .. noad
-- debug_in_file(retAdr .. '\n')
		else
			m_simpleTV.Control.CurrentAdress = 'http://wonky.lostcut.net/vids/error_getlink.avi'
		end
	 return
	end
	local rc, answer = m_simpleTV.Http.Request(session, {url = inAdr:gsub('$HDbaza', ''), headers = 'Referer:' .. inAdr})
	if rc ~= 200 then
		answer = unblock(inAdr)
			if not answer then
				m_simpleTV.Http.Close(session)
				m_simpleTV.OSD.ShowMessageT({text = 'HDbaza ошибка[1]-' .. rc, color = ARGB(255, 155, 255, 155), showTime = 1000 * 5, id = 'channelName'})
			 return
			end
	end
		if inAdr:match('$HDbaza') then
			play(answer)
		 return
		end
	m_simpleTV.User.HDbaza.isVideo = true
	m_simpleTV.User.HDbaza.Tabletitle = nil
	m_simpleTV.User.HDbaza.title = nil
	title = m_simpleTV.Control.CurrentTitle_UTF8 or 'HDbaza'
	m_simpleTV.User.HDbaza.title = title
	local snd = 0
	local seasNom = 0
	local nameepi = ''
	local transl = answer:match('sounds: %[(.+)%],.-soundsList')
	if transl then
		local t, i = {}, 1
			for Adr, name in transl:gmatch('%[(%d+).-\'(.-)\'%]') do
				t[i] = {}
				t[i].Id = i
				t[i].Name = name
				t[i].Adress = Adr
				i = i + 1
			end
		if i > 2 then
			local _, id = m_simpleTV.OSD.ShowSelect_UTF8('Выберете перевод - ' .. title, 0, t, 5000, 1)
			if not id then id = 1 end
		 	snd = t[id].Adress
		else
			snd = t[1].Adress
		end
	end
	local seasons = answer:match('soundsList: {.-\'' .. snd .. '\': {(.-)}')
	if seasons and not seasons:match('Array') then
		local t, i = {}, 1
			for seas in seasons:gmatch('\'(%d+)\'') do
				t[i] = {}
				t[i].Id = i
				t[i].Name = seas .. ' сезон'
				t[i].Adress = seas
				i = i + 1
			end
		if i > 2 then
			local _, id = m_simpleTV.OSD.ShowSelect_UTF8('Выберете сезон ' .. title, 0, t, 5000, 1)
			if not id then id = 1 end
		 	seasNom = t[id].Adress
			nameepi = t[id].Name
		else
			seasNom = t[1].Adress
		end
		if nameepi ~= '' then nameepi = ' (' .. nameepi .. ')' end
	end
	local episodes = answer:match('soundsList: {.-\'' .. snd .. '\':.-{.-\'' .. seasNom .. '\': %[(.-)%]')
	if episodes then
		local t, i = {}, 1
			for epis in episodes:gmatch('%d+') do
				t[i] = {}
				t[i].Id = i
				t[i].Name = 'серия ' .. epis
				t[i].Adress = '$HDbaza' .. inAdr .. '&snd=' .. snd .. '&s=' .. seasNom .. '&e=' .. epis
				i = i + 1
			end
		m_simpleTV.User.HDbaza.Tabletitle = t
		t.ExtButton1 = {ButtonEnable = true, ButtonName = '❌', ButtonScript = 'm_simpleTV.Control.ExecuteAction(37)'}
		t.ExtButton0 = {ButtonEnable = true, ButtonName = '⚙', ButtonScript = 'Quality_HDbaza()'}
		if i > 2 then
			local _, id = m_simpleTV.OSD.ShowSelect_UTF8(title .. nameepi, 0, t, 5000)
			if not id then id = 1 end
			inAdr = t[id].Adress
			m_simpleTV.User.HDbaza.isVideo = false
		end
		if i == 2 then
			t[1].Name = title
			m_simpleTV.OSD.ShowSelect_UTF8('HDbaza', 0, t, 5000, 32+128)
			inAdr = t[1].Adress
		end
		rc, answer = m_simpleTV.Http.Request(session, {url = inAdr:gsub('$HDbaza', ''), headers = 'Referer:' .. inAdr})
		if rc ~= 200 then
			answer = unblock(inAdr)
				if not answer then
					m_simpleTV.Http.Close(session)
					m_simpleTV.OSD.ShowMessageT({text = 'HDbaza ошибка[4]-' .. rc, color = ARGB(255, 155, 255, 155), showTime = 1000 * 5, id = 'channelName'})
				 return
				end
		end
		if nameepi ~= '' then
			title = title .. nameepi
			m_simpleTV.User.HDbaza.title = title
		end
		if i > 2 then
			title = title .. ' - ' .. m_simpleTV.User.HDbaza.Tabletitle[1].Name
		end
	end
	play(answer)