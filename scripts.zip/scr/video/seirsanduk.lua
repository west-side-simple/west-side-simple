-- видеоскрипт для плейлиста "seirsanduk" https://seirsanduk.us (31/3/20)
-- необходим скрапер TVS: seirsanduk
-- открывает подобные ссылки:
-- seirsanduk=//www.seirsanduk.us/hd-balkanika-hd-online
-- ## прокси ##
local prx = ''
-- '' - нет
-- 'http://proxy-nossl.antizapret.prostovpn.org:29976' - например
-- ##
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
		if not m_simpleTV.Control.CurrentAdress:match('^seirsanduk') then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
	inAdr = inAdr:gsub('^seirsanduk=', 'https:')
	if m_simpleTV.Control.MainMode == 0 then
		m_simpleTV.Interface.SetBackground({BackColor = 0, TypeBackColor = 0, PictFileName = '', UseLogo = 0, Once = 1})
	end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = 'error'
	local userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36'
	local session = m_simpleTV.Http.New(userAgent, prx, false)
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 12000)
	local rc, answer = m_simpleTV.Http.Request(session, {url = inAdr})
	m_simpleTV.Http.Close(session)
		if rc ~= 200 then return end
	local retAdr = answer:match('http[^\'"<>]+%.m3u8[^<>\'"]*')
		if not retAdr then return end
	retAdr = retAdr
			.. '$OPT:no-gnutls-system-trust'
			.. '$OPT:NO-STIMESHIFT$OPT:http-referrer=' .. inAdr
			.. '$OPT:http-user-agent=' .. userAgent
	m_simpleTV.Control.CurrentAdress = retAdr
-- debug_in_file(retAdr .. '\n')