-- видеоскрипт для сайта http://telego19.net (28/2/19)
-- открывает подобные ссылки:
-- http://telego19.net/dozhd.html
------------------------------------------------------------------------------------------
local prx = '' -- прокси: '' - нет; например 'http://proxy.antizapret.prostovpn.org:3128'
------------------------------------------------------------------------------------------
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
		if not inAdr then return end
		if not inAdr:match('^https?://telego[0-9]*%.') then return end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = 'error'
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.2785.143 Safari/537.36', prx, false)
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 8000)
	local rc, answer = m_simpleTV.Http.Request(session, {url = inAdr})
	m_simpleTV.Http.Close(session)
		if rc ~= 200 then return end
	local url = answer:match('<iframe width.-src="(.-)"')
		if not url then return end
	local ua = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.2785.143 Safari/537.36'
	local sessionNoPrx = m_simpleTV.Http.New(ua)
		if not sessionNoPrx then return end
	rc, answer = m_simpleTV.Http.Request(sessionNoPrx, {url = url, headers = 'Referer: ' .. inAdr})
	m_simpleTV.Http.Close(sessionNoPrx)
		if rc ~= 200 then return end
	local retAdr = answer:match('[^\'\"<>]+%.m3u8[^<>\'\"]*')
		if not retAdr then return end
	retAdr = retAdr:gsub('^//', 'http://') .. '$OPT:http-user-agent=' .. ua .. '$OPT:http-referrer=' .. url
	m_simpleTV.Http.Close(session)
	m_simpleTV.Control.CurrentAdress = retAdr
-- debug_in_file(retAdr .. '\n')