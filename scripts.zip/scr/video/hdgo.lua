-- видеоскрипт для видеобазы "HDgo" (2/4/19)
-- открывает подобные ссылки:
-- http://hdgo.cc/video/serials/XYbsvvtzIJqwdtyQmMc8iBV0eWPkkuJL/4496
------------------------------------------------------------------------------------------
local noad = 0 -- пропускать рекламу в начале, сек.
local nosave = 0 -- качество: 0 - сохранять; 1 - нет
------------------------------------------------------------------------------------------
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
		if not inAdr then return end
		if not inAdr:match('^https?://hdgo%.c.-/video/') and not inAdr:match('%$hdgo') and not inAdr:match('^https?://vio%.to') then return end
		if inAdr:match('%.mp4') then return end
	m_simpleTV.OSD.ShowMessageT({text = '', showTime = 1000 * 5, id = 'channelName'})
	inAdr = inAdr:gsub('%?geoblock=%w+', ''):gsub('[%s]*', ''):gsub('https?://hdgo%..-/', 'http://vio.to/')
	local kp = false
	local uafilm = false
	if inAdr:match('&uafilm') then
		uafilm = true
		inAdr = inAdr:gsub('&uafilm', '')
	end
	if inAdr:match('$kinopoisk') then
		kp = true inAdr = inAdr:gsub('$kinopoisk', '')
	end
	if not inAdr:match('/$') and not inAdr:match('%$hdgo') then
		inAdr = inAdr .. '/'
	end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = ''
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/71.0.2785.143 Safari/537.36')
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 8000)
	if inAdr:match('^%$hdgo') then
		m_simpleTV.Interface.SetBackground({BackColor = 0, BackColorEnd = 255, PictFileName = '', TypeBackColor = 0, UseLogo = 3, Once = 1})
	end
	if not m_simpleTV.User then
		m_simpleTV.User = {}
	end
	if not m_simpleTV.User.hdgo then
		m_simpleTV.User.hdgo = {}
	end
	if not m_simpleTV.User.hdgo.RES and nosave == 1 then
		m_simpleTV.User.hdgo.RES = 10000
	elseif m_simpleTV.User.hdgo.RES and nosave == 1 then
		m_simpleTV.User.hdgo.RES = 10000
	else
		m_simpleTV.User.hdgo.RES = tonumber(m_simpleTV.Config.GetValue('hdgoRES') or '10000')
	end
	local title
	if m_simpleTV.User.hdgo.Tabletitle then
		local index = m_simpleTV.Control.GetMultiAddressIndex()
		if index then
			title = m_simpleTV.User.hdgo.title .. ' - ' .. m_simpleTV.User.hdgo.Tabletitle[index+1].Name
		end
	end
	local function GetMaxResolutionIndex(t)
		local index
		for u = 1, #t do
				if t[u].res and (m_simpleTV.User.hdgo.RES) < t[u].res then break end
			index = u
		end
	 return index or 1
	end
	function HdgoQuality()
		local t = m_simpleTV.User.hdgo.Table
			if not t then return end
		local index = m_simpleTV.User.hdgo.Index
		t.ExtButton1 = {ButtonEnable = true, ButtonName = '❌', ButtonScript = 'm_simpleTV.Control.ExecuteAction(37)'}
		if #t > 1 then
			local ret, id = m_simpleTV.OSD.ShowSelect_UTF8('⚙  Качество', index-1, t, 5000, 1+4)
			if ret == 1 then
				m_simpleTV.User.hdgo.Index = id
				m_simpleTV.Control.SetNewAddress(t[id].Adress, m_simpleTV.Control.GetPosition())
				if nosave == 0 then
					m_simpleTV.Config.SetValue('hdgoRES', t[id].res)
				end
				m_simpleTV.User.hdgo.RES = t[id].res
			end
		end
	end
	local function GethdgoAddress(answer)
		local answer = answer:match('media:(.-)%]') or answer
		answer = answer:gsub('\'//', 'http://')
		if qlty == 0 then qlty = 100 end
		local tt, i = {}, 1
			for url in answer:gmatch('(http.-)\'') do
				tt[i] = {}
				tt[i].Id = i
				local rtd = tonumber(url:match('/(%d)/')) or i
				if rtd == 1 then name = 'низкое'
				elseif rtd == 2 then name = 'среднее'
				elseif rtd == 3 then name = 'высокое'
				elseif rtd == 4 then name = 'максимальное'
				else name = 'неизвестно'
				end
				tt[i].Name = name
				tt[i].Adress = url .. '$OPT:NO-STIMESHIFT$OPT:http-referrer=' .. inAdr
				tt[i].res = rtd
				i = i + 1
			end
			if i == 1 then return end
		table.sort(tt, function(a, b) return a.res < b.res end)
		local u, index = 1, 1
		for i = 1, #tt do tt[i].Id = i end
		m_simpleTV.User.hdgo.Table = tt
		local index = GetMaxResolutionIndex(tt)
		m_simpleTV.User.hdgo.Index = index
		retAdr = tt[index].Adress
	 return retAdr
	end
	local nameepi = ''
	local rc, answer = m_simpleTV.Http.Request(session, {url = inAdr:gsub('%$hdgo', ''), headers = 'Referer: ' .. inAdr})
		if rc ~= 200 then
			m_simpleTV.Http.Close(session)
			m_simpleTV.OSD.ShowMessage_UTF8('hdgo ошибка[1]-' .. rc, 255, 5)
		 return
		end
	if not inAdr:match('%$hdgo') then
		local t, i = {}, 1
		local seas = answer:match('<select name="season"(.-)</select>')
		if seas then
			title = m_simpleTV.Control.CurrentTitle_UTF8 or 'hdgo'
			for number, nameepi in seas:gmatch('<option.-value="(%d+)">(.-)</option>') do
				local namee = nameepi:match('езон%s+(%d+)')
				if namee then nameepi = namee .. ' сезон' end
				t[i] = {}
				t[i].Id = i
				t[i].Name = nameepi
				t[i].Adress = inAdr .. '?season=' .. number
				i = i + 1
			end
			if i > 2 then
				local _, id = m_simpleTV.OSD.ShowSelect_UTF8('Выберите сезон - ' .. title, 0, t, 5000, 1)
				if not id then id = 1 end
				AdrS = t[id].Adress
				nameepi = t[id].Name
			else
				AdrS = t[1].Adress
				local npi = t[1].Name:match('^%d+') or '0'
				if tonumber(npi) > 1 then nameepi = t[1].Name end
			end
			AdrS = AdrS:gsub('^//', 'http://')
			rc, answer = m_simpleTV.Http.Request(session, {url = AdrS, headers = 'Referer: ' .. AdrS})
				if rc ~= 200 then
					m_simpleTV.Http.Close(session)
					m_simpleTV.OSD.ShowMessage_UTF8('hdgo ошибка[4]-' .. rc, 255, 5)
				 return
				end
		end
		local t1, i = {}, 1
		local epi = answer:match('<select name="episode"(.-)</select>')
		if epi then
			m_simpleTV.User.hdgo.Tabletitle = nil
			title = m_simpleTV.Control.CurrentTitle_UTF8 or 'hdgo'
			m_simpleTV.User.hdgo.title = title
			if nameepi ~= '' then nameepi = ' - ' .. nameepi end
			for ww in epi:gmatch('<option(.-)</option>') do
				local number = ww:match('value="(.-)"')
				t1[i] = {}
				t1[i].Id = i
				t1[i].Name = i .. ' серия'
				t1[i].Adress = AdrS .. '&e=' .. number .. '$hdgo'
				i = i + 1
			end
			m_simpleTV.User.hdgo.Tabletitle = t1
			t1.ExtButton1 = {ButtonEnable = true, ButtonName = '❌', ButtonScript = 'm_simpleTV.Control.ExecuteAction(37)'}
			t1.ExtButton0 = {ButtonEnable = true, ButtonName = '⚙', ButtonScript = 'HdgoQuality()'}
			if i == 2 then
				m_simpleTV.OSD.ShowSelect_UTF8(title .. nameepi, 0, t1, 5000, 32)
				inAdr = t1[1].Adress
			end
			if i > 2 then
				local _, id = m_simpleTV.OSD.ShowSelect_UTF8(title .. nameepi, 0, t1, 5000)
				if not id then id = 1 end
				inAdr = t1[id].Adress
			end
			if nameepi ~= '' then
				title = title .. nameepi
				m_simpleTV.User.hdgo.title = title
			end
			title = title .. ' - ' .. m_simpleTV.User.hdgo.Tabletitle[1].Name
			rc, answer = m_simpleTV.Http.Request(session, {url = inAdr, headers = 'Referer: ' .. inAdr})
				if rc ~= 200 then
					m_simpleTV.Http.Close(session)
					m_simpleTV.OSD.ShowMessage_UTF8('hdgo ошибка[6]-' .. rc, 255, 5)
				 return
				end
		else
			title = m_simpleTV.Control.CurrentTitle_UTF8 or 'hdgo'
			local t1 = {}
			t1[1] = {}
			t1[1].Id = 1
			t1[1].Name = title
			t1[1].Adress = inAdr
			if uafilm == false then
				t1.ExtButton0 = {ButtonEnable = true, ButtonName = '⚙', ButtonScript = 'HdgoQuality()'}
				t1.ExtButton1 = {ButtonEnable = true, ButtonName = '❌', ButtonScript = 'm_simpleTV.Control.ExecuteAction(37)'}
				m_simpleTV.OSD.ShowSelect_UTF8('HDgo', 0, t1, 5000, 64+32+128)
			end
		end
	end
	local retAdr = GethdgoAddress(answer)
	m_simpleTV.Http.Close(session)
		if not retAdr then
			m_simpleTV.Control.CurrentAdress = 'http://wonky.lostcut.net/vids/error_getlink.avi'
		 return
		end
	if m_simpleTV.Control.CurrentTitle_UTF8 then
		m_simpleTV.Control.CurrentTitle_UTF8 = title
	end
	m_simpleTV.OSD.ShowMessageT({text = title, color = ARGB(255, 155, 155, 255), showTime = 1000 * 5, id = 'channelName'})
	m_simpleTV.Control.CurrentAdress = retAdr .. '$OPT:start-time=' .. noad
-- debug_in_file(retAdr .. '\n')