--script for wink.ru VOD (25/12/20) - portal version
-- авторы wafee, west_side
--поддерживается выбор качества видео с помощью аддона videotracks
--примеры адресов для запуска
--https://wink.ru/media_items/104967810
--https://wink.ru/media_items/105005099/105004855/105005648
--воспроизведение аудиокниг не поддерживается
------------------------------------------------------------------------------

if m_simpleTV.Control.ChangeAddress ~= 'No' then return end

local inAdr =  m_simpleTV.Control.CurrentAddress
if inAdr==nil then return end
local inAdr_id, inAdr_part = '', 1
if not string.match( inAdr, '^https://wink%.ru/media_items/.+' ) then return end
if inAdr:match('%&id=%d+') then inAdr_id = inAdr:match('%&id=(%d+)') end
if inAdr:match('%&part=%d+') then inAdr_part = inAdr:match('%&part=(%d+)') inAdr_part = tonumber(inAdr_part) end
inAdr = inAdr:gsub('%&id=%d+$', ''):gsub('%&part=%d+$', '')
---------------------------------------------------------------------------
	local masshtab = m_simpleTV.User.paramScriptForSkin_masshtab or 1.5
    if not m_simpleTV.Interface.GetFullScreenMode() then
     masshtab = masshtab*0.66
    end
	local pause = '<a href="simpleTVLua:m_simpleTV.Control.ExecuteAction(54)" style="color:#009B76; font-size: small; text-decoration:none"><img src="simpleTVImage:./luaScr/user/westSide/icons/pause.png" height="' .. 36*masshtab .. '" align="top"></a> '
		if m_simpleTV.Config.GetValue("background_chanel","PortalConf.ini") then
		background_chanel = m_simpleTV.Config.GetValue("background_chanel","PortalConf.ini")
		else 
		m_simpleTV.Config.SetValue("background_chanel","http://stream.pcradio.ru:8000/spirit_radio_pcradio-hi$OPT:http-user-agent=pcradio","PortalConf.ini")
		background_chanel = m_simpleTV.Config.GetValue("background_chanel","PortalConf.ini")
		m_simpleTV.OSD.ShowMessageT({imageParam = 'vSizeFactor="1.0" src="' .. m_simpleTV.Common.GetMainPath(2) .. './luaScr/user/westSide/icons/audio.png"', text = ' фоновый канал: Spirit FM', color = ARGB(255, 63, 63, 255), showTime = 1000 * 10})
		end

		local titul_rezka = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://rezka.ag\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/hdrezka_logo.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_hevc = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://rips.club\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/h265.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_rezka_tor = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://rezka.cc\/\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/menuREZKA.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_lostfilm = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://www.lostfilm.tv/new\/\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/lostfilm.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_yt = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://www.youtube.com\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/menuYT.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_wink = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/menuWINK.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_newstudio = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'http://newstudio.tv/\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/newstudio.png" height="' .. 36*masshtab .. '" align="top"></a>'
	dataEN = os.date ("%a %d %b %Y %H:%M")
	dataRU = dataEN:gsub('Sun', 'Вс'):gsub('Mon', 'Пн'):gsub('Tue', 'Вт'):gsub('Wed', 'Ср'):gsub('Thu', 'Чт'):gsub('Fri', 'Пт'):gsub('Sat', 'Сб')
	dataRU = dataRU:gsub('Jan', 'Янв'):gsub('Feb', 'Фев'):gsub('Mar', 'Мар'):gsub('Apr', 'Апр'):gsub('May', 'Май'):gsub('Jun', 'Июн'):gsub('Jul', 'Июл'):gsub('Aug', 'Авг'):gsub('Sep', 'Сен'):gsub('Oct', 'Окт'):gsub('Nov', 'Ноя'):gsub('Dec', 'Дек')
	if m_simpleTV.Interface.GetLanguage() == 'ru' then data = dataRU else data = dataEN end
	if Weather then
		local pogoda = Weather.api.GetCurTemp()
		if type(pogoda)=="table" then
			pogoda_cur_temp = pogoda.cur_temp
			pogoda_letter = pogoda.letter
			pogoda_cur_icon = pogoda.cur_icon
			if pogoda.cur_icon == '' then pogoda_cur_icon = 'simpleTVImage:./luaScr/user/Weather/iconset/light/na.png' end
			pogoda_str = '<td style="padding: 10px 10px 5px; vertical-align: middle; color: #EBEBEB;"><h3><center><a href = "simpleTVLua:dofile(m_simpleTV.MainScriptDir .. \'user/Weather/switch_weather.lua\')"><img src="' .. pogoda_cur_icon .. '" height="' .. 36*masshtab .. '" align="top"></a>' ..	pogoda_cur_temp .. pogoda_letter .. '</h3></td>'
		else m_simpleTV.OSD.ShowMessage_UTF8("установите дополнение ПОГОДА")
			pogoda_str = ''
		end
	else m_simpleTV.OSD.ShowMessage_UTF8("дополнение ПОГОДА не установлено")
			pogoda_str = ''
	end
	portal_str = '<table style="font-size: 32px;" width="100%"><tr><td style="padding: 10px 10px 5px; vertical-align: middle;" align="center">' .. titul_rezka_tor .. titul_hevc .. titul_lostfilm .. titul_newstudio .. ' <font color=#CD7F32><b>' .. data .. ' </b></font>' .. titul_yt .. titul_rezka .. titul_wink .. '</td>' .. pogoda_str .. '</tr></table><hr>'

	portal1_str = '<table style="font-size: 32px;" width="100%"><tr><td style="padding: 10px 10px 0px; vertical-align: middle;"><center>' .. titul_rezka_tor .. titul_hevc .. titul_lostfilm .. titul_newstudio .. titul_yt .. titul_rezka .. titul_wink .. '</td></tr></table><hr>'

	--пагинация титульных категорий
	wink1_str = '<td style="padding: 10px 10px 0px; vertical-align: middle;"><center><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/Wink.png" height="' .. 30*masshtab .. '"></a></td>'
	wink_str = wink1_str .. '<td style="padding: 10px 10px 0px; vertical-align: middle;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/movies\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_video.png" height="' .. 40*masshtab .. '" align="top"></a><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/series\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_series.png" height="' .. 40*masshtab .. '" align="top"></a><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/kids\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_kids.png" height="' .. 40*masshtab .. '" align="top"></a><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/sport\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_sport.png" height="' .. 40*masshtab .. '" align="top"></a><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/333\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_selected.png" height="' .. 40*masshtab .. '" align="top"></a><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/tv\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_tv.png" height="' .. 40*masshtab .. '" align="top"></a></td>'
---------------------------------------------------------------------------
m_simpleTV.Control.ChangeAddress='Yes'
m_simpleTV.Control.CurrentAddress = 'error'

local userAgent = "Mozilla/5.0 (Windows NT 10.0; rv:85.0) Gecko/20100101 Firefox/85.0"
local session =  m_simpleTV.Http.New(userAgent, nil, false)
if session == nil then return end
------------------------------------------------------------------------------
local function get_qlty_name(id)

  local t={
  {2377438, 'SD'},
  {1000059, 'HD'},
  {48528946, 'FHD'},
  {81180663, 'UHD'},
  }

  for i, v in ipairs(t) do
     if tonumber(id)==v[1] then return v[2] end
  end
    return id
end
------------------------------------------------------------------------------
local function get_data_table(id)

  local url = 'https://fe.svc.iptv.rt.ru/CacheClientJson/json/VideoMovie/list_assets?ID=' .. id .. '&locationId=700001&deviceType=OTTSTB'

  local rc,answer = m_simpleTV.Http.Request(session,{url=url})
  m_simpleTV.Http.Close(session)
  if rc~=200 then return end

  --debug_in_file(answer .. '\n')

  require('json')

  answer = string.gsub(answer, '%[%]', '""')

  local tab = json.decode(answer)
  if tab == nil or not tab.content then
  return nil
  end

  local t={}

  for i=1, #tab.content[1].assets.asset do

--     if tab.content[1].assets.asset[i].type == 'CONTENT' then

        name = get_qlty_name(tab.content[1].assets.asset[i].asset_type)
        adr = tab.content[1].assets.asset[i].ifn
--не уверен
		if adr:match('%.wvm') then
		local adr1,adr2,adr3,adr4 = '','','',''
		adr1,adr2,adr3,adr4 = adr:match('__(.-)_(.-)_(.-)_(.-)_film%.wvm$')
		if adr1 and adr2 and adr1~='' and adr2~='' then
		adr = adr:gsub('__.-$','')
		adr = 'hls/' .. adr .. '__' .. adr1 .. '_' .. adr2 .. '_film/variant.m3u8'
		else
		adr = 'hls/' .. adr:gsub('%.wvm$','/variant.m3u8')
		end
		end
--
		if adr:match('hls/hd_') then name = 'FHD' end
		if adr:match('hls/sd_') then name = 'SD' end
		asset_type = tab.content[1].assets.asset[i].type
		asset_id = tab.content[1].assets.asset[i].id

        t[i]={}
        t[i].Id=i
        t[i].Qlty = name
        t[i].Name = asset_type .. ' - ' .. name
        t[i].Address = 'https://zabava-htvod.cdn.ngenix.net/' .. adr		
		t[i].Asset = asset_id
        --debug_in_file(t[i].Name .. '  ' .. t[i].Address .. '\n')

--     end
 end

 if #t==0 then

  for i=1, #tab.content do

--     if tab.content[i].assets.asset.type == 'CONTENT' then

        name = get_qlty_name(tab.content[i].assets.asset.asset_type)
        adr = tab.content[i].assets.asset.ifn
--не уверен
		if adr:match('%.wvm') then
		local adr1,adr2,adr3,adr4 = '','','',''
		adr1,adr2,adr3,adr4 = adr:match('__(.-)_(.-)_(.-)_(.-)_film%.wvm$')
		if adr1 and adr2 and adr1~='' and adr2~='' then
		adr = adr:gsub('__.-$','')
		adr = 'hls/' .. adr .. '__' .. adr1 .. '_' .. adr2 .. '_film/variant.m3u8'
		else
		adr = 'hls/' .. adr:gsub('%.wvm$','/variant.m3u8')
		end
		end
--
		asset_type = tab.content[i].assets.asset.type
		asset_id = tab.content[i].assets.asset.id

        t[i]={}
        t[i].Id=i
        t[i].Qlty = name
        t[i].Name = asset_type .. ' - ' .. name
        t[i].Address = 'https://zabava-htvod.cdn.ngenix.net/' .. adr
		t[i].Asset = asset_id
        --debug_in_file(t[i].Name .. '  ' .. t[i].Address .. '\n')

--     end
  end

 end

  table.sort(t, function(a, b) return a.Name > b.Name end)
  for i=1, #t do t[i].Id=i end

  return t
end
------------------------------------------------------------------------------

local rc,answer = m_simpleTV.Http.Request(session,{url=inAdr})
if rc~=200 then return end

--debug_in_file(answer .. '\n')

local movie = false
local serial = false

if not string.match( answer, '"season_id"' ) then
  movie = true
 else
  serial = true
end

 local logo='https://wink.ru/assets/fa4f2bd16b18b08e947d77d6b65e397e.svg'
 local poster='https://wink.ru/assets/fa4f2bd16b18b08e947d77d6b65e397e.svg'
 logo = findpattern(answer, 'property="og:image" content="(.-)"',1,29,1)
 poster = findpattern(answer, '"ImageObject","contentUrl":"(.-)"',1,28,1)
 if logo:match('vod%-a') then
 if answer:match('src="https://s26037%.cdn%.ngenix%.net/sdp/nc%-snapshot"') then logo = answer:match('src="(https://s26037%.cdn%.ngenix%.net/sdp/nc%-snapshot.-)"')
 else logo = logo
 end
 end
 if logo == 'https://s26037.cdn.ngenix.net' then
 logo = findpattern(answer, 'muted="" poster="(.-)"',1,17,1) or poster
 end
 local t,t1={},{}
 local name, adr, title

if movie then

 local content_id = inAdr:match('/media_items/(%d+)$')
 if content_id==nil then return end

 title = findpattern(answer, '"Movie","name":"(.-)"',1,16,1)
 if title==nil then title=inAdr end

 t = get_data_table(content_id)
 if t==nil then
 if answer:match('(https%://zabava%-htvod%.cdn%.ngenix%.net/hls/.-/variant%.m3u8)') then
 local i = 1
 for w in answer:gmatch('https%://zabava%-htvod%.cdn%.ngenix%.net/hls/.-/variant%.m3u8') do
 t1[i] = {}
 if w:match('hls/hd_') then name = 'FHD' elseif w:match('hls/sd_') then name = 'SD' end
 t1[i].Id=i
 t1[i].Qlty = name
 t1[i].Address = w:match('(https%://zabava%-htvod%.cdn%.ngenix%.net/hls/.-/variant%.m3u8)')
 if t1[i].Address:match('_trailer/') then asset_type = 'PREVIEW' else asset_type = 'CONTENT' end
 t1[i].Asset = tostring(i)
 t1[i].Name = asset_type .. ' - ' .. name
 i=i+1
 end
 end
   table.sort(t1, function(a, b) return a.Qlty > b.Qlty end)
   for i=1, #t1 do t1[i].Id=i end
 end
end

if serial then
local episode_id
if inAdr:match('/media_items/%d+/%d+/%d+$') then
 episode_id = inAdr:match('/media_items/%d+/%d+/(%d+)$')
else
 episode_id = findpattern(answer, '"episode_id":(%d+)%}',1,13,1)
end
 if episode_id==nil then return end

 title = findpattern(answer, '"episode","(.-)"',1,11,1) or findpattern(answer, '"TVSeries","name":"(.-)"',1,19,1)
 if title==nil then title=inAdr end

 t = get_data_table(episode_id)
 if t==nil then
 if answer:match('(https%://zabava%-htvod%.cdn%.ngenix%.net/hls/.-/variant%.m3u8)') then
 local i1 = 1
 for w in answer:gmatch('https%://zabava%-htvod%.cdn%.ngenix%.net/hls/.-/variant%.m3u8') do
 t1[i1] = {}
 if w:match('hls/hd_') then name = 'FHD' elseif w:match('hls/sd_') then name = 'SD' end
 t1[i1].Id=i1
 t1[i1].Qlty = name
 t1[i1].Address = w:match('(https%://zabava%-htvod%.cdn%.ngenix%.net/hls/.-/variant%.m3u8)')
 if t1[i1].Address:match('_trailer/') then asset_type = 'PREVIEW' else asset_type = 'CONTENT' end
 t1[i1].Asset = tostring(i1)
 t1[i1].Name = asset_type .. ' - ' .. name
 i1=i1+1
 end
 end
   table.sort(t1, function(a, b) return a.Qlty < b.Qlty end)
   for i=1, #t1 do t1[i].Id=i end
 end
end

if t and t1 then
if #t==0 and #t1==0 then
 local mess = m_simpleTV.Common.multiByteToUTF8('Wink: Ошибка. Адрес не найден',1251)
 m_simpleTV.OSD.ShowMessageT({text=mess,color=ARGB(255,255,0,0),showTime=1000*3,id="channelName"})
 return
end
end



if m_simpleTV.Control.MainMode == 0 then
if logo:match('poster') then
	m_simpleTV.Interface.SetBackground({BackColor = 0, PictFileName = logo, TypeBackColor = 0, UseLogo = 3, Once = 1})
else
	m_simpleTV.Interface.SetBackground({BackColor = 0, PictFileName = logo, TypeBackColor = 0, UseLogo = 4, Once = 1})
end
	m_simpleTV.Control.ChangeChannelLogo(logo, m_simpleTV.Control.ChannelID, 'CHANGE_IF_NOT_EQUAL')
end

--local header = m_simpleTV.Common.multiByteToUTF8('Выберите качество видео',1251)

--local ret, ret1
local id, id1, select_str, playAdr = 1, 1, '', ''
if t then
if #t>=1 then
for id = 1,#t do
if t[id].Name:match('PREVIEW') then
  if inAdr_id == t[id].Asset or inAdr_id == '' and t[id].Name:match('FHD')
    then
      select_str = select_str .. ' 🔸 <font color=#FFB841>' .. t[id].Name .. '</font>'
    else
      select_str = select_str .. ' 🔹 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&id=' .. t[id].Asset .. '\')" style="color: #BBBBEE; text-decoration: none;">' .. t[id].Name .. '</a>'
  end
  if inAdr_id ~= '' then
  if inAdr_id == t[id].Asset then playAdr = t[id].Address end
  else
  if t[id].Name:match('PREVIEW') and t[id].Name:match('FHD') then
  playAdr = t[id].Address
  elseif t[id].Name:match('PREVIEW') and t[id].Name:match('SD') then
  playAdr = t[id].Address
  end
  end
end
end
--  ret, id = m_simpleTV.OSD.ShowSelect_UTF8('Выберите качество видео',0,t,10000,1+4+8)
--  if id==nil then id=1 playAdr = background_chanel end
end

m_simpleTV.Control.CurrentAddress = playAdr .. '$OPT:http-user-agent=' .. userAgent

elseif t1 then
if #t1>=1 then
for id1 = 1,#t1 do
if t1[id1].Name:match('PREVIEW') then
  if inAdr_id == id1 or inAdr_id == '' and id1 == 1
    then
      select_str = select_str .. ' 🔸 <font color=#FFB841>' .. t1[id1].Name .. '</font>'
    else
      select_str = select_str .. ' 🔹 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&id=' .. id1 .. '\')" style="color: #BBBBEE; text-decoration: none;">' .. t1[id1].Name .. '</a>'
  end
  if inAdr_id ~= '' then
  if inAdr_id == t1[id1].Asset then playAdr = t1[id1].Address end
  else playAdr = t1[1].Address
  end
  id1=id1+1
end
end
--  ret, id = m_simpleTV.OSD.ShowSelect_UTF8('Выберите качество видео',0,t,10000,1+4+8)
--  if id1==nil or id1==1 then playAdr = background_chanel end
end
end
if playAdr ~= '' then
m_simpleTV.Control.CurrentAddress = playAdr .. '$OPT:http-user-agent=' .. userAgent
else playAdr = background_chanel m_simpleTV.Control.CurrentAddress = playAdr end
--end

if m_simpleTV.Control.CurrentTitle_UTF8~=nil then
	if playAdr == background_chanel then
		m_simpleTV.Control.CurrentTitle_UTF8 = title .. ' - контент пока не доступен'
		select_str = '<h4><i><font color=#FFB841>Контент пока не доступен</font></i></h4>'
	elseif
	playAdr:match('_trailer/') then
		m_simpleTV.Control.CurrentTitle_UTF8 = title .. ' - промо' else
		m_simpleTV.Control.CurrentTitle_UTF8 = title
	end
end
----------------------------------------------------------multiaddress
desc1 = answer:match('<p class="root_r1ru04lg.-">(.-)</p>')
year = desc1:match('%d+')
name_eng = answer:match('<h4 class="root_r1ru04lg.-">(.-)</h4>')
if name_eng then name_eng = name_eng:gsub('Жанры','')
poisk_kinopoisk = ' <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'title=' .. m_simpleTV.Common.toPercentEncoding(title:gsub(' %(.-$',''):gsub(' HD','')) .. '&year=' .. year .. '\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/menuKP.png" height="' .. 36*masshtab .. '"></a>'
else poisk_kinopoisk = ''
 end
str_poisk = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'#' .. title:gsub(' %(.-$', '') .. '\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/Preview.png" height="' .. 36*masshtab .. '"></a> <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'-' .. title .. '\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/menuYT.png" height="' .. 36*masshtab .. '"></a>' .. poisk_kinopoisk
genres = answer:match('data%-test="media%-item%-genres"(.-)</div></div></div></div></div>') or ''
local i_g, genres_str = 1, ''
for w1 in genres:gmatch('<a href=".-".-><.->.-</span></a>') do
genres_adr, genres_name = w1:match('<a href="(.-)".-><.->(.-)</span></a>')
genres_adr = 'https://wink.ru' .. genres_adr
if genres_name and genres_adr then
genres_str = genres_str .. ' 🔸 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. genres_adr .. '\')" style="color: #EEEEBB; text-decoration: none;">' .. genres_name .. '</a>'
end
i_g = i_g+1
end
persons = answer:match('data%-test="media%-item%-persons"(.-)</div></div></div></div></div></div>') or ''
local i_p, persons_str = 1, ''
for w2 in persons:gmatch('<a href=".-".-><.-><.-></div><h4.->.-</h4><.->.-</span></a>') do
persons_adr, persons_name = w2:match('<a href="(.-)".-><.-><.-></div><h4.->(.-)</h4><.->.-</span></a>')
persons_adr = 'https://wink.ru/search?query=' .. persons_name
if persons_name and persons_adr then
persons_str = persons_str .. ' 🔹 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/search?query=' .. m_simpleTV.Common.toPercentEncoding(persons_name) .. '&tab=1\')" style="color: #BBBBEE; text-decoration: none;">' .. persons_name .. '</a>'
end
i_p = i_p+1
end
desc2 = genres_str
country = answer:match('<span class="root_r1ru04lg value_vzun33j.-">(.-)</span>') or ''
country = country:gsub('SD%, SD', ''):gsub('HD%, HD', ''):gsub('HD%, SD', ''):gsub('SD%, HD', ''):gsub('SD', ''):gsub('HD', '')
--country flags
							local function get_country_flags(country_ID)
					        country_flag = '<img src="simpleTVImage:./luaScr/user/westSide/country/' .. country_ID .. '.png" height="' .. masshtab*36 .. '" align="top">'
					        return country_flag:gsub('"', "'")
							end
							local tmp_country_ID = ''
							country_ID = ''
							if country and country:match('СССР') then tmp_country_ID = 'ussr' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Аргентина') then tmp_country_ID = 'ar' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Австрия') then tmp_country_ID = 'at' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Австралия') then tmp_country_ID = 'au' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Бельгия') then tmp_country_ID = 'be' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Бразилия') then tmp_country_ID = 'br' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Канада') then tmp_country_ID = 'ca' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Швейцария') then tmp_country_ID = 'ch' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Китай') then tmp_country_ID = 'cn' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Гонконг') then tmp_country_ID = 'hk' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Германия') then tmp_country_ID = 'de' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Дания') then tmp_country_ID = 'dk' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Испания') then tmp_country_ID = 'es' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Финляндия') then tmp_country_ID = 'fi' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Франция') then tmp_country_ID = 'fr' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Великобритания') then tmp_country_ID = 'gb' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Греция') then tmp_country_ID = 'gr' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Ирландия') then tmp_country_ID = 'ie' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Израиль') then tmp_country_ID = 'il' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Индия') then tmp_country_ID = 'in' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Исландия') then tmp_country_ID = 'is' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Италия') then tmp_country_ID = 'it' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Япония') then tmp_country_ID = 'jp' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Южная Корея') or country and country:match('Корея Южная') then tmp_country_ID = 'kr' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Мексика') then tmp_country_ID = 'mx' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Нидерланды') then tmp_country_ID = 'nl' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Норвегия') then tmp_country_ID = 'no' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Польша') then tmp_country_ID = 'pl' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Венгрия') then tmp_country_ID = 'hu' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Новая Зеландия') then tmp_country_ID = 'nz' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Португалия') then tmp_country_ID = 'pt' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Румыния') then tmp_country_ID = 'ro' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('ЮАР') then tmp_country_ID = 'rs' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Россия') then tmp_country_ID = 'ru' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Швеция') then tmp_country_ID = 'se' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Турция') then tmp_country_ID = 'tr' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('Украина') then tmp_country_ID = 'ua' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
							if country and country:match('США') then tmp_country_ID = 'us' country_ID = get_country_flags(tmp_country_ID) .. country_ID end
--rating
rating = answer:match('data%-test="media%-item%-rating"(.-</span></div>)</div>') or ''
local i_r, rating_str = 1, ''
for w3 in rating:gmatch('<div class="rating.-</span></div>') do
rating_val, rating_name = w3:match('value.-">(.-)</span>.-label.-">(.-)</span></div>')

if rating_val and rating_name then
rating_str = rating_str .. '<h5><img src="simpleTVImage:./luaScr/user/westSide/icons/rating_' .. rating_name .. '.png" height="' .. masshtab*20 .. '" align="top"> <img src="simpleTVImage:./luaScr/user/westSide/stars/' .. rating_val .. '.png" height="' .. masshtab*20 .. '" align="top"> <font color=#FFB841>' .. rating_val .. '</font></h5>'
end
i_r = i_r+1
end

-----info
desc = findpattern(answer, ',"description":"(.-)"',1,16,1)

local pars, j, desc_plus = {}, 1, ''
					for media in answer:gmatch('<a data%-type="media_item"(.-)</a>') do
					pars[j] = {}
					pars[j].adr = media:match('href="(.-)"')
					pars[j].adr = 'https://wink.ru' .. pars[j].adr
					pars[j].rating = media:match('<div class="ratings_r1x6jaa5">(.-)</div>')
					pars[j].rating = tonumber(pars[j].rating)
					if not pars[j].rating or pars[j].rating == '' then pars[j].rating = 0 end
					pars[j].name1 = media:match('<h4 class="root_r1ru04lg.-">(.-)</h4>')
					pars[j].poster = answer:match('"' .. pars[j].name1:gsub('%.', '%%.'):gsub('%-', '%%-'):gsub('%+', '%%+'):gsub('%:', '%%:'):gsub('%(', '%%('):gsub('%)', '%%)'):gsub('%?', '%%?'):gsub('%!', '%%!'):gsub('&amp;', '%%&'):gsub('&#x27;', '%\'') .. '".-"(/sdp/.-.jpg)"') or 'https://wink.ru/assets/fa4f2bd16b18b08e947d77d6b65e397e.svg'
					if pars[j].poster ~= 'https://wink.ru/assets/fa4f2bd16b18b08e947d77d6b65e397e.svg' then pars[j].poster = 'https://s26037.cdn.ngenix.net/' .. pars[j].poster end
					desc_plus = desc_plus .. '<table style="float: left;font-size: 22px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="20"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="460" width="1"></td><td width="260" align="center"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. pars[j].adr .. '\')"><img src="' .. pars[j].poster .. '" height="375" width="260"></a></td></tr><tr><td style="padding-top: 10px;" width="260" align="center">' .. west_side_substr(pars[j].name1) .. '</td></tr></table>'
					j = j + 1
					end
					if desc_plus ~= '' then
					desc_plus = '</body><body><table style="font-size: 36px;" width="100%"><tr><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><center><font color=#4169E1>' .. 'Похожий контент' .. '</td></tr></table>' .. desc_plus
                    end
-----------------------------сезоны
local pars_ses, jses, ses_name, desc_ses = {}, 1, '', ''

					local serial_id = inAdr:match('media_items/(%d+)')
					if serial_id==nil then return else
					for media_ses in answer:gmatch('<label for=.-</label>') do
					if not media_ses:match('Трейлер') then
					pars_ses[jses] = {}
					pars_ses[jses].adr_ses, pars_ses[jses].name_ses = media_ses:match('<label for="(%d+)".-<span class="root_r1ru04lg title_.-">(.-)</span></label>')
					pars_ses[jses].adr_ses = 'https://wink.ru/media_items/' .. serial_id .. '/' .. pars_ses[jses].adr_ses
					if inAdr:match(pars_ses[jses].adr_ses)
						then
							desc_ses = desc_ses .. ' 🔶 <font color=#FFB841>' .. pars_ses[jses].name_ses .. '</font>'
							ses_name = pars_ses[jses].name_ses
						else
							desc_ses = desc_ses .. ' 🔷 <a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. pars_ses[jses].adr_ses .. '\')" style="color: #BBBBEE; text-decoration: none;">' .. pars_ses[jses].name_ses .. '</a>'
					end
					end
					jses = jses + 1
					end
					if desc_ses ~= '' and not inAdr:match('media_items/%d+/(%d+)$') then ses_name = pars_ses[1].name_ses end
					end

-----------------------------серии
local pars_serial, js, part_str, desc_serial = {}, 1, '', ''
					for media_serial in answer:gmatch('<a data%-test="episode%-card"(.-)</a>') do
					pars_serial[js] = {}
					pars_serial[js].adr_episode = media_serial:match('href="(.-)"')
					pars_serial[js].adr_episode = 'https://wink.ru' .. pars_serial[js].adr_episode
					pars_serial[js].name_episode = media_serial:match('<span class="root_r1ru04lg name.-">(.-)</span>')
					pars_serial[js].time_episode = media_serial:match('<span class="root_r1ru04lg duration.-">(.-)</span>') or ''
					pars_serial[js].poster_episode = media_serial:match('src="(.-)"') or ''
					pars_serial[js].poster_episode = pars_serial[js].poster_episode:gsub('176x108', '352x216')
					pars_serial[js].status_episode = media_serial:match('<span class="root_r1ru04lg status.-">(.-)</span>') or ''
					--части сезона
					pars_serial[js].jp = math.floor((js-1)/16) + 1 --часть сезона
					pars_serial[js].jsp = js - (pars_serial[js].jp-1)*16 --эпизод в части сезона
					--
					if pars_serial[js].jp == inAdr_part then
					if pars_serial[js].jsp == 1 then
					part_str = part_str .. '<font color=#BBBBEE> • </font><font color=#FFB841>' .. pars_serial[js].jp .. '</font>'
					end
					if pars_serial[js].status_episode and pars_serial[js].status_episode == 'Скоро' then
					desc_serial = desc_serial .. '<table style="float: left;font-size: 22px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="3"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="200" width="1"></td><td width="354"><img src="' .. pars_serial[js].poster_episode .. '" height="200" width="354"></td></tr><tr><td  width="354" align="center">' .. pars_serial[js].name_episode .. ' <font color=#CD7F32> - ' .. pars_serial[js].time_episode .. ' ' .. pars_serial[js].status_episode .. '</font></td><td rowspan="2" width="3"></td></tr></table>'
					elseif pars_serial[js].adr_episode == inAdr then
					desc_serial = desc_serial .. '<table style="float: left;font-size: 22px;color: #7FFFD4; text-decoration: none; background-color: #0E294B;" border="0"><tr><td rowspan="2" width="3"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="200" width="1"></td><td width="354"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. pars_serial[js].adr_episode .. '\')"><img src="' .. pars_serial[js].poster_episode .. '" height="200" width="354"></a></td></tr><tr><td  width="354" align="center"><b>' .. pars_serial[js].name_episode .. ' <font color=#CD7F32> - ' .. pars_serial[js].time_episode .. ' ' .. pars_serial[js].status_episode .. '</font></b></td><td rowspan="2" width="3"></td></tr></table>'
					else
					desc_serial = desc_serial .. '<table style="float: left;font-size: 22px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="3"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="200" width="1"></td><td width="354"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. pars_serial[js].adr_episode .. '\')"><img src="' .. pars_serial[js].poster_episode .. '" height="200" width="354"></a></td></tr><tr><td  width="354" align="center">' .. pars_serial[js].name_episode .. ' <font color=#CD7F32> - ' .. pars_serial[js].time_episode .. ' ' .. pars_serial[js].status_episode .. '</font></td><td rowspan="2" width="3"></td></tr></table>'
					end
					else
					if pars_serial[js].jsp == 1 then
					part_str = part_str .. '<font color=#BBBBEE> • </font><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr .. '&part=' ..pars_serial[js].jp .. '\')" style="color: #BBBBEE; text-decoration: none;">' .. pars_serial[js].jp .. '</a>'
					end
					end
					js = js + 1
					end
					if math.floor(#pars_serial/16)+1 > 1
						then part_str = '<font color=#BBBBEE>Части сезона</font>' .. part_str
						else part_str = ''
					end
					if desc_serial ~= '' then
						desc_serial = '<table style="font-size: 36px;" width="100%"><tr><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><center><font color=#4169E1>' .. title:gsub('%. Серия.-$', ''):gsub('%. Серии.-$', ''):gsub('%. Сезон.-$', '') .. ' - ' .. ses_name .. '. Серии' .. '</td></tr></table>' .. desc_serial
                    end

		local tm = {}
		tm[1] = {}
		tm[1].Id = 1
		tm[1].Name = title
		tm[1].InfoPanelTitle = desc1
		tm[1].InfoPanelName = title
		tm[1].InfoPanelShowTime = 5000
		tm[1].InfoPanelLogo = logo
		tm[1].InfoPanelDesc = '<html><body bgcolor="#434750"><table style="font-size: 32px;" width="100%"><tr>' .. wink_str .. '</tr></table><hr><table width="100%"><tr><td style="padding: 0px 10px 5px;"><img src="' .. poster .. '" width="' .. masshtab*270 .. '"></td><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><h5>' .. select_str .. '</h5><h5>' .. desc_ses .. '</h5><h5>' .. part_str .. '</h5><h3>' .. pause .. '<font color=#00FA9A>' .. title .. '</font></h3><h3>' .. str_poisk .. '</h3><h5><font color=#BBBBBB>' .. name_eng .. '</font></h5><h5>' .. country_ID .. ' ' .. country .. '</h5><h5>' .. desc2 .. '</h5>' .. rating_str .. '</td></tr></table><table width="100%"><tr><td style="padding: 0px 5px 5px;"><h5>' .. persons_str .. '</h5><h5>' .. desc .. '</h5></td></tr></table><hr></body><body>' .. desc_serial .. desc_plus .. '</body></html>'
		tm[1].InfoPanelDesc = tm[1].InfoPanelDesc:gsub('"', '\"')
		tm[1].InfoPanelTitle = tm[1].InfoPanelTitle:gsub('"', '%%22')

--wafee
 local t = {}
 t.message = tm[1].InfoPanelDesc
 t.richTextMode = true
 t.header = tm[1].InfoPanelTitle
 t.showTime = 10000
 t.once = true
 t.textAlignment = 1
 t.windowAlignment = 2
 t.windowMaxSizeH = 1
 t.windowMaxSizeV = 1

 if m_simpleTV.User.westSide.PortalTable==nil then
   m_simpleTV.User.westSide.PortalTable=t
 end

 if select_str:match('Контент пока не доступен') then
   show_portal_window()
 end

 show_portal_window() -- hotkey 'I'
-------------------------------------------------