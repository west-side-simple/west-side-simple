--script for wink.ru (25/12/20) - portal version
--авторы west_side, wafee
--примеры адресов для запуска
--https://wink.ru/media_items?category_id=17&vod_genres=49253936
--https://wink.ru/search?query=%D0%A2%D0%BE%D0%BC%20%D0%9A%D1%80%D1%83%D0%B7
--https://wink.ru/collections/118?category_id=17
--https://wink.ru/movies
------------------------------------------------------------------------------
--предложения по улучшению юзабилити плагина http://iptv.gen12.net/bugtracker/view.php?id=1733
------------------------------------------------------------------------------
if m_simpleTV.Control.ChangeAddress_UTF8 ~= 'No' then return end

local inAdr =  m_simpleTV.Control.CurrentAddress_UTF8
if inAdr==nil then return end

if not string.match( inAdr, '^https://wink%.ru/media_items?.+' )
and not string.match( inAdr, '^https://wink%.ru/search?.+' )
and not string.match( inAdr, '^https://wink%.ru/collections/.+' )
and not string.match( inAdr, '^https://wink%.ru/movies$' )
and not string.match( inAdr, '^https://wink%.ru/series$' )
and not string.match( inAdr, '^https://wink%.ru/kids$' )
and not string.match( inAdr, '^https://wink%.ru/sport$' )
and not string.match( inAdr, '^https://wink%.ru/333$' )
and not string.match( inAdr, '^\'' )
and inAdr ~= 'https://wink.ru/'
then return end
if string.match( inAdr, '^\'' ) then inAdr = 'https://wink.ru/search?query=' .. m_simpleTV.Common.toPercentEncoding(inAdr:match('^\'(.-)$')) .. '&tab=1' m_simpleTV.Control.PlayAddressT({address = inAdr}) end
--wafee------------
--показывать предупреждение "погода не установлена" один раз в сессии симпла

if m_simpleTV.User.westSide.ShowWeatherMess == nil then
  m_simpleTV.User.westSide.ShowWeatherMess = true
end
--в 91 строке продолжение

--зачем при запуске винк портала отрабатывается lostfilm_portal.lua ?

--ноль громкости, при запуске портала, для тех кому не нравится слушать радио
--можно реализовать через опцию в меню
--пример 1 - on, 0 - off
local mute=0
local extOpt=''
if mute==1 then
 m_simpleTV.User.westSide.Volume = m_simpleTV.Control.GetVolume() or 0.3
--при запуске видео в getaddress установить громоксть из m_simpleTV.User.westSide.Volume
--SetVolume(number vol,boolean ShowSlider(opt def=true))
--или как retAdr .. '$OPT:volume=' .. m_simpleTV.User.westSide.Volume
 extOpt = '$OPT:volume=0'
end

--можно через SetMute(number mode) , правда иконка появляется на экране и при скролле mute сбрасывается

--wafee------------

---------------------------------------------------------------------------
local masshtab = m_simpleTV.User.paramScriptForSkin_masshtab or 1.5
    if not m_simpleTV.Interface.GetFullScreenMode() then
     masshtab = masshtab*0.66
    end

		if m_simpleTV.Config.GetValue("background_chanel","PortalConf.ini") then
		background_chanel = m_simpleTV.Config.GetValue("background_chanel","PortalConf.ini")
		else
		m_simpleTV.Config.SetValue("background_chanel","http://stream.pcradio.ru:8000/spirit_radio_pcradio-hi$OPT:http-user-agent=pcradio","PortalConf.ini")
		background_chanel = m_simpleTV.Config.GetValue("background_chanel","PortalConf.ini")
		m_simpleTV.OSD.ShowMessageT({imageParam = 'vSizeFactor="1.0" src="' .. m_simpleTV.Common.GetMainPath(2) .. './luaScr/user/westSide/icons/audio.png"', text = ' фоновый канал: Spirit FM', color = ARGB(255, 63, 63, 255), showTime = 1000 * 10})
		end

		local titul_rezka = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://rezka.ag\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/hdrezka_logo.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_hevc = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://rips.club\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/h265.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_rezka_tor = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://rezka.cc\/\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/menuREZKA.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_lostfilm = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://www.lostfilm.tv/new\/\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/lostfilm.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_yt = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://www.youtube.com\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/menuYT.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_wink = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/menuWINK.png" height="' .. 36*masshtab .. '" align="top"></a>'
		local titul_newstudio = '<a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'http://newstudio.tv/\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/newstudio.png" height="' .. 36*masshtab .. '" align="top"></a>'
	dataEN = os.date ("%a %d %b %Y %H:%M")
	dataRU = dataEN:gsub('Sun', 'Вс'):gsub('Mon', 'Пн'):gsub('Tue', 'Вт'):gsub('Wed', 'Ср'):gsub('Thu', 'Чт'):gsub('Fri', 'Пт'):gsub('Sat', 'Сб')
	dataRU = dataRU:gsub('Jan', 'Янв'):gsub('Feb', 'Фев'):gsub('Mar', 'Мар'):gsub('Apr', 'Апр'):gsub('May', 'Май'):gsub('Jun', 'Июн'):gsub('Jul', 'Июл'):gsub('Aug', 'Авг'):gsub('Sep', 'Сен'):gsub('Oct', 'Окт'):gsub('Nov', 'Ноя'):gsub('Dec', 'Дек')
	if m_simpleTV.Interface.GetLanguage() == 'ru' then data = dataRU else data = dataEn end
	if Weather then
		local pogoda = Weather.api.GetCurTemp()
		if type(pogoda)=="table" then
			pogoda_cur_temp = pogoda.cur_temp
			pogoda_letter = pogoda.letter
			pogoda_cur_icon = pogoda.cur_icon
			if pogoda.cur_icon == '' then pogoda_cur_icon = 'simpleTVImage:./luaScr/user/Weather/iconset/light/na.png' end
			pogoda_str = '<td style="padding: 10px 10px 5px; vertical-align: middle; color: #EBEBEB;"><h3><center><a href = "simpleTVLua:dofile(m_simpleTV.MainScriptDir .. \'user/Weather/switch_weather.lua\')"><img src="' .. pogoda_cur_icon .. '" height="' .. 36*masshtab .. '" align="top"></a>' ..	pogoda_cur_temp .. pogoda_letter .. '</h3></td>'
		else m_simpleTV.OSD.ShowMessage_UTF8("установите дополнение ПОГОДА")
			pogoda_str = ''
		end
	else

--wafee-------------
          if m_simpleTV.User.westSide.ShowWeatherMess then
            m_simpleTV.OSD.ShowMessage_UTF8("дополнение ПОГОДА не установлено")
            m_simpleTV.User.westSide.ShowWeatherMess = false
          end
--wafee-----------
			pogoda_str = ''
	end
	portal_str = '<table style="font-size: 32px;" width="100%"><tr><td style="padding: 10px 10px 0px; vertical-align: middle;" align="center">' ..	titul_rezka_tor .. titul_hevc .. titul_lostfilm .. titul_newstudio .. ' <font color=#CD7F32><b>' .. data .. ' </b></font>' .. titul_yt .. titul_rezka .. titul_wink ..
	'</td>' .. pogoda_str .. '</tr></table><table width="100%" border="0"><tr><td style="padding: 0 0 0 10px;"><hr></td></tr></table>'

	portal1_str = '<table style="font-size: 32px;" width="100%"><tr><td style="padding: 10px 10px 0px; vertical-align: middle;"><center>' .. titul_rezka_tor .. titul_hevc .. titul_lostfilm .. titul_newstudio .. titul_yt .. titul_rezka .. titul_wink .. '</td></tr></table><table width="100%" border="0"><tr><td style="padding: 0 0 0 10px;"><hr></td></tr></table>'
--пагинация титульных категорий
	wink_str = '<table style="font-size: 32px;" width="100%"><tr><td style="padding: 10px 10px 0px; vertical-align: middle;"><center><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/movies\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_video.png" height="' .. 60*masshtab ..
	'" align="top"></a><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/series\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_series.png" height="' .. 60*masshtab ..
	'" align="top"></a><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/kids\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_kids.png" height="' .. 60*masshtab ..
	'" align="top"></a><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/sport\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_sport.png" height="' .. 60*masshtab ..
	'" align="top"></a><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/333\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_selected.png" height="' .. 60*masshtab ..
	'" align="top"></a><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/tv?theme=1000\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_tv.png" height="' .. 60*masshtab ..
	'" align="top"></a></td></tr></table>'
---------------------------------------------------------------------------
m_simpleTV.Control.ChangeAddress_UTF8='Yes'
m_simpleTV.Control.CurrentAddress_UTF8 = 'error'
if inAdr:match('https://wink%.ru/search?') then
inAdr = 'https://wink.ru/search?' .. m_simpleTV.Common.fromPercentEncoding(inAdr:gsub('https://wink%.ru/search%?', ''))
end

--debug_in_file(inAdr .. '\n')

local userAgent = "okhttp/3.14.4"
local session =  m_simpleTV.Http.New(userAgent, nil, false)
if session == nil then return end

local rc,answer = m_simpleTV.Http.Request(session,{url=inAdr})
if rc~=200 then return end

--пагинация категорий поиска
	local wink_str1, cat_name = '', ''
	if inAdr:match('/search%?') then
	for cat in answer:gmatch('<label for="tab_.-</label>') do
	n_cat = cat:match('<label for="tab_(%d+)"')
	if cat:match('Фильмы') then
	if inAdr:match('&tab=' .. n_cat)
	then
	wink_str1 = wink_str1 .. '<td style="padding: 10px 10px 0px; vertical-align: middle;"><center><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr:gsub('%&tab=.-$', '') .. '&tab=' .. n_cat .. '\')" style="text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_video.png" height="' .. 60*masshtab .. '" align="top"><h5><center><font color=#ED4830>Фильмы</font></h5></a></td>'
	cat_name = 'Фильмы'
	else
	wink_str1 = wink_str1 .. '<td style="padding: 10px 10px 0px; vertical-align: middle;"><center><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr:gsub('%&tab=.-$', '') .. '&tab=' .. n_cat .. '\')" style="text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_video.png" height="' .. 60*masshtab .. '" align="top"><h5><center><font color=#BBBBBB>Фильмы</font></h5></a></td>'
	end
	elseif cat:match('Сериалы') then
	if inAdr:match('&tab=' .. n_cat)
	then
	wink_str1 = wink_str1 .. '<td style="padding: 10px 10px 0px; vertical-align: middle;"><center><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr:gsub('%&tab=.-$', '') .. '&tab=' .. n_cat .. '\')" style="text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_series.png" height="' .. 60*masshtab .. '" align="top"><h5><center><font color=#ED4830>Сериалы</font></h5></a></td>'
	cat_name = 'Сериалы'
	else
	wink_str1 = wink_str1 .. '<td style="padding: 10px 10px 0px; vertical-align: middle;"><center><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr:gsub('%&tab=.-$', '') .. '&tab=' .. n_cat .. '\')" style="text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_video.png" height="' .. 60*masshtab .. '" align="top"><h5><center><font color=#BBBBBB>Сериалы</font></h5></a></td>'
	end
	elseif cat:match('ТВ%-каналы') then
	if inAdr:match('&tab=' .. n_cat) or inAdr:match('&tab=6')
	then
	wink_str1 = wink_str1 .. '<td style="padding: 10px 10px 0px; vertical-align: middle;"><center><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr:gsub('%&tab=.-$', '') .. '&tab=' .. n_cat .. '\')" style="text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_tv.png" height="' .. 60*masshtab .. '" align="top"><h5><center><font color=#ED4830>ТВ-каналы</font></h5></a></td>'
	cat_name = 'ТВ-каналы'
	else
	wink_str1 = wink_str1 .. '<td style="padding: 10px 10px 0px; vertical-align: middle;"><center><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr:gsub('%&tab=.-$', '') .. '&tab=' .. n_cat .. '\')" style="text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_tv.png" height="' .. 60*masshtab .. '" align="top"><h5><center><font color=#BBBBBB>ТВ-каналы</font></h5></a></td>'
	end
	elseif cat:match('Детям') then
	if inAdr:match('&tab=' .. n_cat)
	then
	wink_str1 = wink_str1 .. '<td style="padding: 10px 10px 0px; vertical-align: middle;"><center><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr:gsub('%&tab=.-$', '') .. '&tab=' .. n_cat .. '\')" style="text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_kids.png" height="' .. 60*masshtab .. '" align="top"><h5><center><font color=#ED4830>Детям</font></h5></a></td>'
	cat_name = 'Детям'
	else
	wink_str1 = wink_str1 .. '<td style="padding: 10px 10px 0px; vertical-align: middle;"><center><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. inAdr:gsub('%&tab=.-$', '') .. '&tab=' .. n_cat .. '\')" style="text-decoration: none;"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_kids.png" height="' .. 60*masshtab .. '" align="top"><h5><center><font color=#BBBBBB>Детям</font></h5></a></td>'
	end
	wink_str1 = '<table width="100%"><tr>' .. wink_str1 .. '</tr></table><hr>'
	end
	end
	end
local logo = './luaScr/user/westSide/icons/Search_Wink.jpg'
if not inAdr:match('%?query=') and not inAdr:match('movies') and not inAdr:match('series') and not inAdr:match('kids') and not inAdr:match('sport') then
logo = answer:match('"(/sdp/nc%-snapshot.-%.jpg)"') or answer:match('"(/sdp/nc%-poster.-%.jpg)"')
logo = 'https://s26037.cdn.ngenix.net' .. logo
end
title = answer:match('<title data%-rh=.->(.-)<')
title = title:gsub(' смотреть онлайн в хорошем качестве 1080p.-$', ''):gsub(' смотреть онлайн на Wink в хорошем качестве 1080p.-$', ''):gsub(' в хорошем качестве онлайн 1080p.-$', ''):gsub('Wink %– ТВ%-каналы, фильмы и сериалы смотреть в хорошем качестве.-$', 'Wink')
title_zapros = answer:match('"%?query=(.-)"')
if title_zapros then
title_zapros = title_zapros:gsub('&tab=%d+', '')
title_zapros = m_simpleTV.Common.fromPercentEncoding(title_zapros)
title = title:gsub('ТВ%-каналы%, фильмы и сериалы', '') .. cat_name .. ' | ' .. title_zapros
end
local pars, j, kj, desc = {}, 1, 1, ''
					if inAdr == 'https://wink.ru/' then
					local rc,answer_search = m_simpleTV.Http.Request(session,{url='https://wink.ru/search'})
					if rc~=200 then return end
					for media in answer_search:gmatch('<a data%-type="media_item"(.-)</a>') do
					pars[j] = {}
					pars[j].adr = media:match('href="(.-)"')
					pars[j].adr = 'https://wink.ru' .. pars[j].adr
					pars[j].name1 = media:match('<h4 class="root_r1ru04lg.-">(.-)</h4>')
					pars[j].poster = answer_search:match(',"' .. pars[j].name1:gsub('%.', '%%.'):gsub('%-', '%%-'):gsub('%+', '%%+'):gsub('%:', '%%:'):gsub('%(', '%%('):gsub('%)', '%%)'):gsub('%?', '%%?'):gsub('%!', '%%!'):gsub('&amp;', '%%&'):gsub('&#x27;', '%\'') .. '.-"(/sdp/.-.jpg)"') or 'https://wink.ru/assets/fa4f2bd16b18b08e947d77d6b65e397e.svg'
					if pars[j].poster ~= 'https://wink.ru/assets/fa4f2bd16b18b08e947d77d6b65e397e.svg' then pars[j].poster = 'https://s26037.cdn.ngenix.net/' .. pars[j].poster end

--wafee-----------
--					desc = desc .. '<table style="float: left;font-size: 22px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="20"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="460" width="1"></td><td width="260" align="center"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. pars[j].adr .. '\')"><img src="' .. pars[j].poster .. '" height="375" width="260"></a></td></tr><tr><td style="padding-top: 10px;" width="260" align="center">' .. west_side_substr(pars[j].name1) .. '</td></tr></table>'

--for 6?
					desc = desc .. '<table style="float: left;font-size: 22px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="3"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="436" width="1"></td><td width="230" align="center"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. pars[j].adr .. '\')"><img src="' .. pars[j].poster .. '" height="332" width="230"></a></td></tr><tr><td style="padding-top: 10px;" width="230" align="center">' .. west_side_substr(pars[j].name1) .. '</td></tr></table>'

--wafee-----------

					j = j + 1
					end
					else
					for media in answer:gmatch('<a data%-type="media_item"(.-)</a>') do
					pars[j] = {}
					pars[j].adr = media:match('href="(.-)"')
					pars[j].adr = 'https://wink.ru' .. pars[j].adr
					pars[j].name1 = media:match('<h4 class="root_r1ru04lg.-">(.-)</h4>')
					pars[j].poster = answer:match(',"' .. pars[j].name1:gsub('%.', '%%.'):gsub('%-', '%%-'):gsub('%+', '%%+'):gsub('%:', '%%:'):gsub('%(', '%%('):gsub('%)', '%%)'):gsub('%?', '%%?'):gsub('%!', '%%!'):gsub('&amp;', '%%&'):gsub('&#x27;', '%\'') .. '.-"(/sdp/.-%.jpg)"') or 'https://wink.ru/assets/fa4f2bd16b18b08e947d77d6b65e397e.svg'
					if pars[j].poster ~= 'https://wink.ru/assets/fa4f2bd16b18b08e947d77d6b65e397e.svg' then pars[j].poster = 'https://s26037.cdn.ngenix.net/' .. pars[j].poster end
					desc = desc .. '<table style="float: left;font-size: 22px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="20"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="480" width="1"></td><td width="260" align="center"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. pars[j].adr .. '\')"><img src="' .. pars[j].poster .. '" height="375" width="260"></a></td></tr><tr><td  style="padding-top: 10px;" width="260" align="center">' .. west_side_substr(pars[j].name1) .. '</td></tr></table>'
					j = j + 1
					end
					end

local parstv, jtv, desctv = {}, 1, ''

					for mediatv in answer:gmatch('<a (href="/tv.-)</a>') do
					parstv[jtv] = {}
					parstv[jtv].adr = mediatv:match('href="(.-)"')
					parstv[jtv].adr = 'https://wink.ru' .. parstv[jtv].adr
					parstv[jtv].name1 = mediatv:match('<img alt="(.-)"')
					parstv[jtv].poster = mediatv:match('src="(.-)"')
					parstv[jtv].logo = mediatv:match('src=".-".-src="(.-)"')
					if parstv[jtv].adr then
					parstv[jtv].start = parstv[jtv].adr:match('start_time=(%d+)')
					end
					if parstv[jtv].adr
					and parstv[jtv].name1
					and parstv[jtv].poster
					and parstv[jtv].logo
					and parstv[jtv].start
					and tonumber(parstv[jtv].start) < os.time()
					and tonumber(parstv[jtv].start) > os.time() - 3*60*60*24
					and not parstv[jtv].adr:match('/tv/580')
					then
					desctv = desctv .. '<table style="float: left;font-size: 24px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="3"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="300" width="1"></td><td width="354" colspan="2"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. parstv[jtv].adr .. '\')"><img src="' .. parstv[jtv].poster:gsub('176x132', '352x264') .. '" height="200" width="354"></a></td></tr><tr><td style="padding: 0px 0px 0px; vertical-align: middle;" width="170" height="100"><img src="' .. parstv[jtv].logo .. '" height="90" width="160" align="left"></td><td style="padding: 0px 0px 0px; vertical-align: middle;" width="184" height="100">' .. west_side_substr20(parstv[jtv].name1) .. '</td></tr></table>'
					jtv = jtv + 1
					end
					end


					local pars1, j1, kj1, desc1 = {}, 1, 1, ''
					answer1 = answer:match('"media_item",.-$')
					desc1_name = 'Новинки'
					if answer1 and not inAdr:match('333') then
					for media1 in answer1:gmatch('"/images/.-%.jpg".-%{".-":%d+') do
					pars1[j1] = {}
					pars1[j1].poster = media1:match('"(/images/.-%.jpg)",')
					pars1[j1].poster = 'https://s26037.cdn.ngenix.net' .. pars1[j1].poster
					pars1[j1].adr = media1:match('"id":(%d+)')
					if not media1:match('"channel"') and not media1:match('"name"') and pars1[j1].adr then
					pars1[j1].name1, pars1[j1].name2 = answer:match('data%-type="banner" href="/media_items/' .. pars1[j1].adr .. '.-<h2 class="root_r1ru04lg.-">(.-)</h2>(.-)</a>')
					if pars1[j1].name2 and pars1[j1].name2:match('<p class="root_r1ru04lg.-">.-</p>')
						then pars1[j1].name2 = pars1[j1].name2:match('<p class="root_r1ru04lg.-">(.-)</p>')
						else pars1[j1].name2 = ''
					end
					if not pars1[j1].name1 then pars1[j1].name1 = '' end
					if not pars1[j1].name2 then pars1[j1].name2 = '' end
					pars1[j1].adr = 'https://wink.ru/media_items/' .. pars1[j1].adr
					else pars1[j1].name1, pars1[j1].name2 = '', ''
					end
					if pars1[j1].name1 ~= '' then

--wafee-----------

--					desc1 = desc1 .. '<table style="float: left;font-size: 24px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="20"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="360" width="1"></td><td width="690"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. pars1[j1].adr .. '\')"><img src="' .. pars1[j1].poster .. '" height="220" width="690"></a></td></tr><tr><td style="padding-top: 10px;" width="690" align="center"><font color=#00FA9A><b>' .. pars1[j1].name1 .. '</b></font><br><font color=#BBBBBB><i>' .. pars1[j1].name2 .. '</i></font></td></tr></table>'

-- all width banner
					desc1 = desc1 .. '<table width="100%"><tr><td style="padding-top: 10px;"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. pars1[j1].adr .. '\')"><center><img src="' .. pars1[j1].poster .. '" width="' .. 940*masshtab .. '"></a><center><h3><font color=#00FA9A><b>' .. pars1[j1].name1 .. '</font></h3><center><h4><font color=#BBBBBB><i>' .. pars1[j1].name2 .. '</i></font></h4></td></tr></table><hr>'

--wafee-----------

					end
					j1 = j1 + 1
					end
					end

					local pars2, j2, kj2, desc2 = {}, 1, 1, ''
					answer2 = answer:match('">Подборки</h3>.-$')

					if answer2 and inAdr:match('movies') then

						local path1 = './luaScr/user/TVSources/m3u/out_Wink Media.m3u'
						local file1 = io.open('./luaScr/user/TVSources/m3u/out_Wink Media.m3u', 'r')
						if not file1 then
						m_simpleTV.OSD.ShowMessage_UTF8('Необходимо добавить файл ' .. path1) return end
						local answer_pls1 = file1:read('*a')
						file1:close()
						local i, my_pls1 = 1, {}
						local t_pls1, i_pls1, k_pls1 = {}, 1, 1
						for tab_pls1 in answer_pls1:gmatch('tvg%-logo=".-".-https://wink%.ru/collections/%d+%?category_id=17') do
							t_pls1[i_pls1] = {}
							t_pls1[i_pls1].logo_pls1, t_pls1[i_pls1].name_pls1, t_pls1[i_pls1].adr_pls1 = tab_pls1:match('tvg%-logo="(.-)".-,(.-)https://wink%.ru/collections/(%d+)%?category_id=17')
							if tonumber(t_pls1[i_pls1].adr_pls1) == 21
							or tonumber(t_pls1[i_pls1].adr_pls1) == 23
							or tonumber(t_pls1[i_pls1].adr_pls1) == 24
							or tonumber(t_pls1[i_pls1].adr_pls1) == 81
							or tonumber(t_pls1[i_pls1].adr_pls1) == 83
							or tonumber(t_pls1[i_pls1].adr_pls1) == 512
--							or tonumber(t_pls1[i_pls1].adr_pls1) == 580
--							or tonumber(t_pls1[i_pls1].adr_pls1) == 583
							or tonumber(t_pls1[i_pls1].adr_pls1) == 685
--							or tonumber(t_pls1[i_pls1].adr_pls1) == 934
							or tonumber(t_pls1[i_pls1].adr_pls1) == 603
							or tonumber(t_pls1[i_pls1].adr_pls1) == 13
--							or tonumber(t_pls1[i_pls1].adr_pls1) == 14
--							or tonumber(t_pls1[i_pls1].adr_pls1) == 18
							or tonumber(t_pls1[i_pls1].adr_pls1) == 1082
--							or tonumber(t_pls1[i_pls1].adr_pls1) == 627
--							or tonumber(t_pls1[i_pls1].adr_pls1) == 684
--							or tonumber(t_pls1[i_pls1].adr_pls1) == 477
							or tonumber(t_pls1[i_pls1].adr_pls1) == 502
--							or tonumber(t_pls1[i_pls1].adr_pls1) == 322
							or tonumber(t_pls1[i_pls1].adr_pls1) == 362
							then
							t_pls1[i_pls1].adr_pls1 = 'https://wink.ru/collections/' .. t_pls1[i_pls1].adr_pls1 .. '?category_id=17'
							desc2 = desc2 .. '<table style="float: left;font-size: 32px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="20"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="400" width="1"></td><td width="454"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. t_pls1[i_pls1].adr_pls1 .. '\')"><img src="' .. t_pls1[i_pls1].logo_pls1 .. '" height="285" width="454"></a></td></tr><tr><td style="padding-top: 10px;" width="454" align="center">' .. t_pls1[i_pls1].name_pls1 .. '</td></tr></table>'
							end
							i_pls1 = i_pls1 + 1
						end

					elseif inAdr:match('series') then
						local path1 = './luaScr/user/TVSources/m3u/out_Wink Media.m3u'
						local file1 = io.open('./luaScr/user/TVSources/m3u/out_Wink Media.m3u', 'r')
						if not file1 then
						m_simpleTV.OSD.ShowMessage_UTF8('Необходимо добавить файл ' .. path1) return end
						local answer_pls1 = file1:read('*a')
						file1:close()
						local i, my_pls1 = 1, {}
						local t_pls1, i_pls1, k_pls1 = {}, 1, 1
						for tab_pls1 in answer_pls1:gmatch('tvg%-logo=".-".-https://wink%.ru/collections/%d+%?category_id=17') do
							t_pls1[i_pls1] = {}
							t_pls1[i_pls1].logo_pls1, t_pls1[i_pls1].name_pls1, t_pls1[i_pls1].adr_pls1 = tab_pls1:match('tvg%-logo="(.-)".-,(.-)https://wink%.ru/collections/(%d+)%?category_id=17')
							if tonumber(t_pls1[i_pls1].adr_pls1) == 26
							or tonumber(t_pls1[i_pls1].adr_pls1) == 25
							or tonumber(t_pls1[i_pls1].adr_pls1) == 384
							or tonumber(t_pls1[i_pls1].adr_pls1) == 361
							or tonumber(t_pls1[i_pls1].adr_pls1) == 357
							or tonumber(t_pls1[i_pls1].adr_pls1) == 522
							or tonumber(t_pls1[i_pls1].adr_pls1) == 358
							or tonumber(t_pls1[i_pls1].adr_pls1) == 501
							or tonumber(t_pls1[i_pls1].adr_pls1) == 200
							or tonumber(t_pls1[i_pls1].adr_pls1) == 931
							or tonumber(t_pls1[i_pls1].adr_pls1) == 30
							or tonumber(t_pls1[i_pls1].adr_pls1) == 105
							then
							t_pls1[i_pls1].adr_pls1 = 'https://wink.ru/collections/' .. t_pls1[i_pls1].adr_pls1 .. '?category_id=17'
							desc2 = desc2 .. '<table style="float: left;font-size: 32px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="3"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="400" width="1"></td><td width="480"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. t_pls1[i_pls1].adr_pls1 .. '\')"><img src="' .. t_pls1[i_pls1].logo_pls1 .. '" width="480"></a></td></tr><tr><td  width="480" align="center">' .. west_side_substr(t_pls1[i_pls1].name_pls1) .. '</td></tr></table>'
							end
							i_pls1 = i_pls1 + 1
						end
					elseif not answer2 and inAdr:match('kids') then
						local path1 = './luaScr/user/TVSources/m3u/out_Wink Media.m3u'
						local file1 = io.open('./luaScr/user/TVSources/m3u/out_Wink Media.m3u', 'r')
						if not file1 then
						m_simpleTV.OSD.ShowMessage_UTF8('Необходимо добавить файл ' .. path1) return end
						local answer_pls1 = file1:read('*a')
						file1:close()
						local i, my_pls1 = 1, {}
						local t_pls1, i_pls1, k_pls1 = {}, 1, 1
						for tab_pls1 in answer_pls1:gmatch('tvg%-logo=".-".-https://wink%.ru/collections/%d+%?category_id=17') do
							t_pls1[i_pls1] = {}
							t_pls1[i_pls1].logo_pls1, t_pls1[i_pls1].name_pls1, t_pls1[i_pls1].adr_pls1 = tab_pls1:match('tvg%-logo="(.-)".-,(.-)https://wink%.ru/collections/(%d+)%?category_id=17')
							if tonumber(t_pls1[i_pls1].adr_pls1) == 18
							or tonumber(t_pls1[i_pls1].adr_pls1) == 17
							or tonumber(t_pls1[i_pls1].adr_pls1) == 744
							or tonumber(t_pls1[i_pls1].adr_pls1) == 705
							or tonumber(t_pls1[i_pls1].adr_pls1) == 516
							or tonumber(t_pls1[i_pls1].adr_pls1) == 437
							or tonumber(t_pls1[i_pls1].adr_pls1) == 217
							or tonumber(t_pls1[i_pls1].adr_pls1) == 879
							or tonumber(t_pls1[i_pls1].adr_pls1) == 765
							or tonumber(t_pls1[i_pls1].adr_pls1) == 507
							or tonumber(t_pls1[i_pls1].adr_pls1) == 29
							or tonumber(t_pls1[i_pls1].adr_pls1) == 267
							or tonumber(t_pls1[i_pls1].adr_pls1) == 100
							or tonumber(t_pls1[i_pls1].adr_pls1) == 212
							or tonumber(t_pls1[i_pls1].adr_pls1) == 506
							then
							t_pls1[i_pls1].adr_pls1 = 'https://wink.ru/collections/' .. t_pls1[i_pls1].adr_pls1 .. '?category_id=17'
							desc2 = desc2 .. '<table style="float: left;font-size: 32px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="3"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="400" width="1"></td><td width="480"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. t_pls1[i_pls1].adr_pls1 .. '\')"><img src="' .. t_pls1[i_pls1].logo_pls1 .. '" width="480"></a></td></tr><tr><td  width="480" align="center">' .. west_side_substr(t_pls1[i_pls1].name_pls1) .. '</td></tr></table>'
							end
							i_pls1 = i_pls1 + 1
						end
						local path2 = './luaScr/user/TVSources/m3u/out_Wink TV.m3u'
						local file2 = io.open('./luaScr/user/TVSources/m3u/out_Wink TV.m3u', 'r')
						if not file2 then
						m_simpleTV.OSD.ShowMessage_UTF8('Необходимо добавить файл ' .. path2) return end
						local answer_pls2 = file2:read('*a')
						file2:close()
						local t_pls2, i_pls2, k_pls2, desc3 = {}, 1, 1, ''
						for tab_pls2 in answer_pls2:gmatch('group%-title=".-".-tvg%-logo=".-".-https://wink%.ru/tv/%d+') do
						t_pls2[i_pls2] = {}
						t_pls2[i_pls2].name_grp2, t_pls2[i_pls2].logo_pls2, t_pls2[i_pls2].adr_pls2 = tab_pls2:match('group%-title="(.-)".-tvg%-logo="(.-)".-(https://wink%.ru/tv/%d+)')
						if t_pls2[i_pls2].name_grp2:match('Детские') then
						desc3 = desc3 .. '<table style="float: left;font-size: 32px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td width="240"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. t_pls2[i_pls2].adr_pls2 .. '\')"><img src="' .. t_pls2[i_pls2].logo_pls2 .. '" height="135" width="240"></a></td></tr></table>'
						i_pls2 = i_pls2 + 1
						end
						end
						desc1 = desc1 ..
						'<table style="font-size: 40px;" width="100%"><tr><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><center><font color=#4169E1>' .. 'Детские ТВ каналы' ..
						'</td></tr></table>' .. desc3
					elseif not answer2 and inAdr:match('333') then
					title = title .. ' for FRIENDS'
						local path1 = './luaScr/user/TVSources/m3u/out_Wink Media.m3u'
						local file1 = io.open('./luaScr/user/TVSources/m3u/out_Wink Media.m3u', 'r')
						if not file1 then
						m_simpleTV.OSD.ShowMessage_UTF8('Необходимо добавить файл ' .. path1) return end
						local answer_pls1 = file1:read('*a')
						file1:close()
						local i, my_pls1 = 1, {}
						local t_pls1, i_pls1, k_pls1 = {}, 1, 1
						for tab_pls1 in answer_pls1:gmatch('tvg%-logo=".-".-https://wink%.ru/collections/%d+%?category_id=17') do
							t_pls1[i_pls1] = {}
							t_pls1[i_pls1].logo_pls1, t_pls1[i_pls1].name_pls1, t_pls1[i_pls1].adr_pls1 = tab_pls1:match('tvg%-logo="(.-)".-,(.-)https://wink%.ru/collections/(%d+)%?category_id=17')
							if tonumber(t_pls1[i_pls1].adr_pls1) == 21
							or tonumber(t_pls1[i_pls1].adr_pls1) == 23
							or tonumber(t_pls1[i_pls1].adr_pls1) == 24
							or tonumber(t_pls1[i_pls1].adr_pls1) == 81
							or tonumber(t_pls1[i_pls1].adr_pls1) == 83
							or tonumber(t_pls1[i_pls1].adr_pls1) == 512
							or tonumber(t_pls1[i_pls1].adr_pls1) == 580
							or tonumber(t_pls1[i_pls1].adr_pls1) == 583
							or tonumber(t_pls1[i_pls1].adr_pls1) == 685
							or tonumber(t_pls1[i_pls1].adr_pls1) == 934
							or tonumber(t_pls1[i_pls1].adr_pls1) == 603
							or tonumber(t_pls1[i_pls1].adr_pls1) == 13
							or tonumber(t_pls1[i_pls1].adr_pls1) == 14
							or tonumber(t_pls1[i_pls1].adr_pls1) == 18
							or tonumber(t_pls1[i_pls1].adr_pls1) == 1082
							or tonumber(t_pls1[i_pls1].adr_pls1) == 627
							or tonumber(t_pls1[i_pls1].adr_pls1) == 684
							or tonumber(t_pls1[i_pls1].adr_pls1) == 477
							or tonumber(t_pls1[i_pls1].adr_pls1) == 502
							or tonumber(t_pls1[i_pls1].adr_pls1) == 322
							or tonumber(t_pls1[i_pls1].adr_pls1) == 362
							then
							t_pls1[i_pls1].adr_pls1 = 'https://wink.ru/collections/' .. t_pls1[i_pls1].adr_pls1 .. '?category_id=17'
							desc2 = desc2 .. '<table style="float: left;font-size: 32px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="20"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="400" width="1"></td><td width="454"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. t_pls1[i_pls1].adr_pls1 .. '\')"><img src="' .. t_pls1[i_pls1].logo_pls1 .. '" height="285" width="454"></a></td></tr><tr><td style="padding-top: 10px;" width="454" align="center">' .. t_pls1[i_pls1].name_pls1 .. '</td></tr></table>'
							end
							i_pls1 = i_pls1 + 1
						end
						local path2 = './luaScr/user/TVSources/m3u/out_Wink TV.m3u'
						local file2 = io.open('./luaScr/user/TVSources/m3u/out_Wink TV.m3u', 'r')
						if not file2 then
						m_simpleTV.OSD.ShowMessage_UTF8('Необходимо добавить файл ' .. path2) return end
						local answer_pls2 = file2:read('*a')
						file2:close()
						local t_pls2, i_pls2, k_pls2, desc3 = {}, 1, 1, ''
						for tab_pls2 in answer_pls2:gmatch('group%-title=".-".-tvg%-logo=".-".-https://wink%.ru/tv/%d+') do
						t_pls2[i_pls2] = {}
						t_pls2[i_pls2].logo_pls2, t_pls2[i_pls2].adr_pls2 = tab_pls2:match('tvg%-logo="(.-)".-https://wink%.ru/tv/(%d+)')
						if tonumber(t_pls2[i_pls2].adr_pls2) == 247
						or tonumber(t_pls2[i_pls2].adr_pls2) == 257
						or tonumber(t_pls2[i_pls2].adr_pls2) == 259
						or tonumber(t_pls2[i_pls2].adr_pls2) == 265
						or tonumber(t_pls2[i_pls2].adr_pls2) == 292
						or tonumber(t_pls2[i_pls2].adr_pls2) == 296
						or tonumber(t_pls2[i_pls2].adr_pls2) == 825
						or tonumber(t_pls2[i_pls2].adr_pls2) == 826
						or tonumber(t_pls2[i_pls2].adr_pls2) == 827
						or tonumber(t_pls2[i_pls2].adr_pls2) == 828
						or tonumber(t_pls2[i_pls2].adr_pls2) == 829
						or tonumber(t_pls2[i_pls2].adr_pls2) == 830
						or tonumber(t_pls2[i_pls2].adr_pls2) == 831
						or tonumber(t_pls2[i_pls2].adr_pls2) == 444
						or tonumber(t_pls2[i_pls2].adr_pls2) == 486
						or tonumber(t_pls2[i_pls2].adr_pls2) == 766
						or tonumber(t_pls2[i_pls2].adr_pls2) == 498
						or tonumber(t_pls2[i_pls2].adr_pls2) == 504
						or tonumber(t_pls2[i_pls2].adr_pls2) == 505
						or tonumber(t_pls2[i_pls2].adr_pls2) == 506
						or tonumber(t_pls2[i_pls2].adr_pls2) == 515
						or tonumber(t_pls2[i_pls2].adr_pls2) == 520
						or tonumber(t_pls2[i_pls2].adr_pls2) == 521
						or tonumber(t_pls2[i_pls2].adr_pls2) == 522
						or tonumber(t_pls2[i_pls2].adr_pls2) == 523
						or tonumber(t_pls2[i_pls2].adr_pls2) == 539
						or tonumber(t_pls2[i_pls2].adr_pls2) == 540
						or tonumber(t_pls2[i_pls2].adr_pls2) == 541
						or tonumber(t_pls2[i_pls2].adr_pls2) == 542
						or tonumber(t_pls2[i_pls2].adr_pls2) == 441
						or tonumber(t_pls2[i_pls2].adr_pls2) == 822
						or tonumber(t_pls2[i_pls2].adr_pls2) == 823
						or tonumber(t_pls2[i_pls2].adr_pls2) == 547
						or tonumber(t_pls2[i_pls2].adr_pls2) == 548
						or tonumber(t_pls2[i_pls2].adr_pls2) == 319
						or tonumber(t_pls2[i_pls2].adr_pls2) == 344
						then
						t_pls2[i_pls2].adr_pls2 = 'https://wink.ru/tv/' .. t_pls2[i_pls2].adr_pls2
						desc3 = desc3 .. '<table style="float: left;font-size: 32px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td width="240"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. t_pls2[i_pls2].adr_pls2 .. '\')"><img src="' .. t_pls2[i_pls2].logo_pls2 .. '" height="135" width="240"></a></td></tr></table>'
						i_pls2 = i_pls2 + 1
						end
						end
						desc2 = desc2 ..
						'<table style="font-size: 40px;" width="100%"><tr><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><center><font color=#4169E1>' .. 'Избранные ТВ каналы' ..
						'</td></tr></table>' .. desc3
					elseif not answer2 and inAdr:match('sport') then
					title = title .. ' SPORT'
						desc1_name = 'Спортивные каналы'
						local path1 = './luaScr/user/TVSources/m3u/out_Wink Media.m3u'
						local file1 = io.open('./luaScr/user/TVSources/m3u/out_Wink Media.m3u', 'r')
						if not file1 then
						m_simpleTV.OSD.ShowMessage_UTF8('Необходимо добавить файл ' .. path1) return end
						local answer_pls1 = file1:read('*a')
						file1:close()
						local i, my_pls1 = 1, {}
						local t_pls1, i_pls1, k_pls1 = {}, 1, 1
						for tab_pls1 in answer_pls1:gmatch('tvg%-logo=".-".-https://wink%.ru/collections/%d+%?category_id=17') do
							t_pls1[i_pls1] = {}
							t_pls1[i_pls1].logo_pls1, t_pls1[i_pls1].name_pls1, t_pls1[i_pls1].adr_pls1 = tab_pls1:match('tvg%-logo="(.-)".-,(.-)https://wink%.ru/collections/(%d+)%?category_id=17')
							if tonumber(t_pls1[i_pls1].adr_pls1) == 141
							or tonumber(t_pls1[i_pls1].adr_pls1) == 641
							or tonumber(t_pls1[i_pls1].adr_pls1) == 426
							or tonumber(t_pls1[i_pls1].adr_pls1) == 547
							or tonumber(t_pls1[i_pls1].adr_pls1) == 543
							or tonumber(t_pls1[i_pls1].adr_pls1) == 570
							or tonumber(t_pls1[i_pls1].adr_pls1) == 1041
							or tonumber(t_pls1[i_pls1].adr_pls1) == 1042
							or tonumber(t_pls1[i_pls1].adr_pls1) == 1044
							then
							t_pls1[i_pls1].adr_pls1 = 'https://wink.ru/collections/' .. t_pls1[i_pls1].adr_pls1 .. '?category_id=17'
							desc2 = desc2 .. '<table style="float: left;font-size: 32px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="3"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="400" width="1"></td><td width="480"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. t_pls1[i_pls1].adr_pls1 .. '\')"><img src="' .. t_pls1[i_pls1].logo_pls1 .. '" width="480"></a></td></tr><tr><td  width="480" align="center">' .. t_pls1[i_pls1].name_pls1 .. '</td></tr></table>'
							end
							i_pls1 = i_pls1 + 1
						end
						local path2 = './luaScr/user/TVSources/m3u/out_Wink TV.m3u'
						local file2 = io.open('./luaScr/user/TVSources/m3u/out_Wink TV.m3u', 'r')
						if not file2 then
						m_simpleTV.OSD.ShowMessage_UTF8('Необходимо добавить файл ' .. path2) return end
						local answer_pls2 = file2:read('*a')
						file2:close()
						local t_pls2, i_pls2, k_pls2, desc3 = {}, 1, 1, ''
						for tab_pls2 in answer_pls2:gmatch('group%-title=".-".-tvg%-logo=".-".-https://wink%.ru/tv/%d+') do
						t_pls2[i_pls2] = {}
						t_pls2[i_pls2].name_grp2, t_pls2[i_pls2].logo_pls2, t_pls2[i_pls2].adr_pls2 = tab_pls2:match('group%-title="(.-)".-tvg%-logo="(.-)".-(https://wink%.ru/tv/%d+)')
						if t_pls2[i_pls2].name_grp2:match('Спортивные') then
						desc3 = desc3 .. '<table style="float: left;font-size: 32px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td width="240"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. t_pls2[i_pls2].adr_pls2 .. '\')"><img src="' .. t_pls2[i_pls2].logo_pls2 .. '" height="135" width="240"></a></td></tr></table>'
						i_pls2 = i_pls2 + 1
						end
						end
						desc1 = desc3
						end

					if inAdr:match('series') or inAdr:match('movies') or inAdr:match('kids') or inAdr:match('sport') then
					desc = '<html><body bgcolor="#434750">' .. portal_str .. wink_str .. '<table style="font-size: 40px;" width="100%"><tr><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><center><font color=#6495ED>' .. title .. '</td></tr></table><table style="font-size: 40px;" width="100%"><tr><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><center><font color=#4169E1>' .. desc1_name ..	'</td></tr></table><table width="100%" border="0"><tr><td style="padding: 0 0 0 10px;"><hr></td></tr></table>' .. desc1 .. '<table style="font-size: 40px;" width="100%" border="0"><tr><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><p><center><font color=#4169E1>' .. 'Подборки' ..	'</td></tr></table>' .. desc2
					elseif inAdr:match('333') then
					desc = '<html><body bgcolor="#434750">' .. portal_str .. wink_str .. '<table style="font-size: 40px;" width="100%"><tr><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><center><font color=#6495ED>' .. title .. '</td></tr></table><table style="font-size: 40px;" width="100%" border="0"><tr><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><p><center><font color=#4169E1>' .. 'Подборки' .. '</td></tr></table><hr>' .. desc2
					elseif inAdr == 'https://wink.ru/' then
					desc = '<html><body bgcolor="#434750">' .. portal_str .. wink_str .. '<table style="font-size: 40px;" width="100%"><tr><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><center><font color=#6495ED>' .. title .. '</td></tr></table><table style="font-size: 40px;" width="100%"><tr><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><center><font color=#4169E1>' .. desc1_name .. '</td></tr></table><table style="float: left;" width="100%" border="0"><tr><td style="padding: 0 0 0 10px;"><hr></td></tr></table>' .. desc1 .. '<table style="font-size: 40px;" width="100%" border="0"><tr><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><center><font color=#4169E1>' .. 'Лидеры просмотра' .. '<hr></td></tr></table>' .. desc
					else
					if desctv ~= '' then
					desc = '<html><body bgcolor="#434750">' .. portal_str .. wink_str1 .. '</body><body><table style="font-size: 40px;" width="100%"><tr><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><center><font color=#6495ED>' .. title:gsub('ТВ%-каналы, фильмы и сериалы', '') .. '</td></tr></table><table style="float: left;" width="100%" border="0"><tr><td style="padding: 0 0 0 10px;"><hr></td></tr></table>' .. desctv
					else
					desc = '<html><body bgcolor="#434750">' .. portal_str .. wink_str1 .. '</body><body><table style="font-size: 40px;" width="100%"><tr><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><center><font color=#6495ED>' .. title .. '</td></tr></table>' .. desc
					end
					end
--debug_in_file(answer .. '\n')

--wafee------------
--внесу предложение добавить пагинацию на каталог или жанровые страницы и для всех страниц нижнее меню,
--например можно указать адреса на другие разделы, источники портала и т.п Если вы планируете,
--кроме новинок и лидеров просмотра, выводить на главную страницу дополнительные категории,
--то отпадет необходимость снизу подыматься к верхнему меню, что повысит юзабилити

--строка жанровой пагинации
local pagin_genres_name = ''
local pagin_genres={
{"Комедии","https://wink.ru/media_items?category_id=17&vod_genres=49253936","https://s26037.cdn.ngenix.net/imo/transform/profile=smallbanner176x176/images/bu7mq1toldapbksmmf1g.png"},
{"Приключения","https://wink.ru/media_items?category_id=17&vod_genres=49542085","https://s26037.cdn.ngenix.net/imo/transform/profile=smallbanner176x176/images/bu7mqadoldapbksmmf20.png"},
{"Драмы","https://wink.ru/media_items?category_id=17&vod_genres=49542078","https://s26037.cdn.ngenix.net/imo/transform/profile=smallbanner176x176/images/bu7mqidoldapbksmmf2g.png"},
{"Боевики","https://wink.ru/media_items?category_id=17&vod_genres=49542077","https://s26037.cdn.ngenix.net/imo/transform/profile=smallbanner176x176/images/bu7mqqdoldapbksmmf30.png"},
{"Триллеры","https://wink.ru/media_items?category_id=17&vod_genres=49542086","https://s26037.cdn.ngenix.net/imo/transform/profile=smallbanner176x176/images/bu7mr35oldapbksmmf3g.png"},
{"Семейные","https://wink.ru/media_items?category_id=17&vod_genres=50953974","https://s26037.cdn.ngenix.net/imo/transform/profile=smallbanner176x176/images/bu7mrb5oldapbksmmf40.png"},
{"Фэнтези","https://wink.ru/media_items?category_id=17&vod_genres=49542080","https://s26037.cdn.ngenix.net/imo/transform/profile=smallbanner176x176/images/bu7mriloldapbksmmf4g.png"},
{"Фантастика","https://wink.ru/media_items?category_id=17&vod_genres=49542076","https://s26037.cdn.ngenix.net/imo/transform/profile=smallbanner176x176/images/bu7mrrtoldapbksmmf50.png"},
{"Криминал","https://wink.ru/media_items?category_id=17&vod_genres=50953973","https://s26037.cdn.ngenix.net/imo/transform/profile=smallbanner176x176/images/bu7ms3loldapbksmmf5g.png"},
{"Ужасы","https://wink.ru/media_items?category_id=17&vod_genres=49542057","https://s26037.cdn.ngenix.net/imo/transform/profile=smallbanner176x176/images/bu7msbdoldapbksmmf60.png"},
{"Эротические","https://wink.ru/media_items?category_id=17&vod_genres=52184003","https://s26037.cdn.ngenix.net/imo/transform/profile=smallbanner176x176/images/bu7msjtoldapbksmmf6g.png"},
}

  local t_genres, pagin_genres_item = {}, ''
  for ig=1,#pagin_genres do
    t_genres[ig] = {}
    t_genres[ig].Name = pagin_genres[ig][1]
    t_genres[ig].Address = pagin_genres[ig][2]
	t_genres[ig].Logo = pagin_genres[ig][3]
	if inAdr == t_genres[ig].Address then
	pagin_genres_item = pagin_genres_item .. '<table style="float: left;font-size: 22px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="3"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="150" width="1"></td><td width="150" align="center"><img src="' .. t_genres[ig].Logo .. '" height="150" width="150"></td></tr></table>'
	pagin_genres_name = t_genres[ig].Name
	else
	pagin_genres_item = pagin_genres_item .. '<table style="float: left;font-size: 22px;color: #7FFFD4; text-decoration: none;" border="0"><tr><td rowspan="2" width="3"><img src="simpleTVImage:./luaScr/user/westSide/icons/pixel.png" height="150" width="1"></td><td width="120" align="center"><a href="simpleTVLua:m_simpleTV.Control.PlayAddress(\'' .. t_genres[ig].Address .. '\')"><img src="' .. t_genres[ig].Logo .. '" height="120" width="120"></a></td></tr></table>'
	end
  end

local pagin_genres_name = '</td></tr></table><table style="font-size: 24px;" width="100%" border="0"><tr><td style="padding: 0px 5px 5px; vertical-align: middle;"><center><font color=#4169E1>' .. 'Жанр: '.. pagin_genres_name .. '</font></td></tr></table>'
local footer_menu_genres = pagin_genres_name ..
'<table style="float: left;" width="100%" border="0"><tr><td style="padding: 0px 0 0 10px;"><hr></td></tr></table>' .. pagin_genres_item
--
local pagin = '<table style="float: left;" width="100%" border="0"><tr><td style="padding-top: 25px; font-size: 24px; text-align: center;"><font color=#4169E1>Медиапортал</font></td></tr></table>'

local footer_menu = pagin .. '<table style="float: left;" width="100%" border="0"><tr><td style="padding: 0px 0 0 10px;"><hr></td></tr></table>' .. '<table style="float: left; font-size: 22px;" width="100%" border="0">' ..
'<tr><td style="padding: 0px 5px 5px 20px; color: #EBEBEB; vertical-align: middle;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/tv?theme=1000\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_tv.png" height="54" align="top"></a> Wink TV</td><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/movies\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_video.png" height="54" align="top"></a> Фильмы</td><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;">' .. titul_hevc .. ' RipsClub</td></tr>' ..
'<tr><td style="padding: 0px 5px 5px 20px; color: #EBEBEB; vertical-align: middle;">' .. titul_rezka .. ' HDRezka</td><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/series\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_series.png" height="54" align="top"></a> Сериалы</td><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;">' .. titul_newstudio .. ' NewStudio</td></tr>' ..
'<tr><td style="padding: 0px 5px 5px 20px; color: #EBEBEB; vertical-align: middle;">' .. titul_lostfilm .. ' LostFilm</td><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;"><a href = "simpleTVLua:m_simpleTV.Control.PlayAddress(\'https://wink.ru/kids\')"><img src="simpleTVImage:./luaScr/user/westSide/icons/wink_kids.png" height="54" align="top"></a> Мульты</td><td style="padding: 0px 5px 5px; color: #EBEBEB; vertical-align: middle;">' .. titul_yt .. ' Youtube</td></tr></table>' ..
'<table style="float: left;" width="100%" border="0"><tr><td style="padding: 0px 5px 5px;"></td></tr></table>'

desc = desc .. footer_menu_genres .. footer_menu .. '</body></html>'

--debug_in_file(desc .. '\n')
--wafee------------

local poster = logo or './luaScr/user/westSide/icons/Channels.jpg'

if m_simpleTV.Control.CurrentTitle_UTF8~=nil then
   m_simpleTV.Control.CurrentTitle_UTF8 = title
end

if m_simpleTV.Control.MainMode == 0 then
	m_simpleTV.Interface.SetBackground({BackColor = 0, PictFileName = logo, TypeBackColor = 0, UseLogo = 4, Once = 1})
	m_simpleTV.Control.ChangeChannelLogo(poster, m_simpleTV.Control.ChannelID, 'CHANGE_IF_NOT_EQUAL')
end
local retAdr = background_chanel
m_simpleTV.Control.CurrentAddress_UTF8 = retAdr .. extOpt

----------------------------------------------------------multiaddress

		local tm = {}
		tm[1] = {}
		tm[1].Id = 1
		tm[1].Name = title
		tm[1].Address = background_chanel
		tm[1].InfoPanelTitle = title
		tm[1].InfoPanelName = title
		tm[1].InfoPanelShowTime = 60000
		tm[1].InfoPanelLogo = poster
		tm[1].InfoPanelDesc = desc
		tm[1].InfoPanelDesc = tm[1].InfoPanelDesc:gsub('"', '\"')
		tm[1].InfoPanelTitle = tm[1].InfoPanelTitle:gsub('"', '%%22')

--wafee
 local t = {}
 t.message = tm[1].InfoPanelDesc
 t.richTextMode = true
 t.header = tm[1].InfoPanelTitle
 t.showTime = 1000*60
 t.once = true
 --t.textAlignment = 1
 t.windowAlignment = 2
 t.windowMaxSizeH = 1
 t.windowMaxSizeV = 1

 if m_simpleTV.User.westSide.PortalTable==nil then
   m_simpleTV.User.westSide.PortalTable=t --кешируем данные в юзер таблицу
 end

 show_portal_window() -- hotkey 'I'

-------------------------------------------------