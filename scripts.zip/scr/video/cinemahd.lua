-- видеоскрипт для сайта https://cinema-hd.club (20/10/18)
-- необходимы скрипты: moonwalk, youtube
-- открывает подобные ссылки:
-- https://cinema-hd.club/films/komedii/mamma_mia_2/1-1-0-25189
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
		if not inAdr then return end
		if not inAdr:match('https?://cinema%-hd%.') then return end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = ''
	local session = m_simpleTV.Http.New('Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.2785.143 Safari/537.36')
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 8000)
	local rc, answer = m_simpleTV.Http.Request(session, {url = inAdr})
	m_simpleTV.Http.Close(session)
		if rc ~= 200 then return end
	local retAdr = answer:match('<iframe src="(.-)"') or answer:match('<iframe width.- src="(.-)"')
		if not retAdr then return end
	local title = answer:match('<title>(.-)</title>') or 'cinema-hd'
	title = title:gsub('%s+%d+%s+сезон', ''):gsub('%(.+', '')
	m_simpleTV.Control.CurrentTitle_UTF8 = title
	retAdr = retAdr:gsub('^//', 'http://'):gsub('/iframe.+', '/iframe')
	m_simpleTV.Control.ChangeAdress = 'No'
	m_simpleTV.Control.CurrentAdress = retAdr
	dofile(m_simpleTV.MainScriptDir .. 'user\\video\\video.lua')
-- debug_in_file(retAdr .. '\n')