-- видеоскрипт для плейлиста "paromtv" http://www.parom.tv (7/2/20)
-- открывает подобные ссылки:
-- http://www.parom.tv/133
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
		if not m_simpleTV.Control.CurrentAdress:match('^http://www%.parom%.tv/%d') then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
	if m_simpleTV.Control.MainMode == 0 then
		m_simpleTV.Interface.SetBackground({BackColor = 0, TypeBackColor = 0, PictFileName = '', UseLogo = 0, Once = 1})
	end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = 'error'
	local session = m_simpleTV.Http.New('Dalvik/2.1.0 (Linux; U; Android 6.0.1;)')
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 8000)
	local rc, answer = m_simpleTV.Http.Request(session, {url = decode64('aHR0cDovL3d3dy5wYXJvbS50di9ydS9wbGF5ZXJkYXRhLmpzb24='), headers = 'Referer: http://www.parom.tv/'})
	m_simpleTV.Http.Close(session)
		if rc ~= 200 then return end
	local chId = inAdr:match('%d+')
	answer = answer:gsub('(%[%])', '"nil"')
	require 'json'
	local tab = json.decode(answer)
		if not tab or not tab.channels then return end
	local i = 1
	local retAdr
		while true do
				if not tab.channels[i] then break end
			local id = tab.channels[i].id
				if id and tonumber(id) == tonumber(chId) then
					retAdr = tab.channels[i].hls_uri
				 break
				end
			i = i + 1
		end
		if not retAdr then return end
	retAdr = retAdr .. '$OPT:http-referrer=http://www.parom.tv/$OPT:http-user-agent=Dalvik/2.1.0 (Linux; U; Android 6.0.1;)'
	m_simpleTV.Control.CurrentAdress = retAdr
-- debug_in_file(retAdr .. '\n')