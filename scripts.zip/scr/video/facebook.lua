-- видеоскрипт для сайта https://www.facebook.com (10/8/18)
-- открывает подобные ссылки:
-- https://www.facebook.com/cnninternational/videos/vb.18793419640/10155641785904641
		if m_simpleTV.Control.ChangeAdress ~= 'No' then return end
	local inAdr = m_simpleTV.Control.CurrentAdress
		if not inAdr then return end
		if not inAdr:match('https?://www.facebook%.com/.-/videos/') then return end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = ''
	local session = m_simpleTV.Http.New('Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1')
		if not session then return end
	m_simpleTV.Http.SetTimeout(session, 8000)
	local rc, answer = m_simpleTV.Http.Request(session, {url = inAdr})
	m_simpleTV.Http.Close(session)
		if rc ~= 200 then
			m_simpleTV.OSD.ShowMessage_UTF8('facebook ошибка[1]-' .. rc, 255, 5)
		 return
		end
	answer = answer:gsub('&quot;', '"'):gsub('&amp;', '&')
	local retAdr = answer:match('"type":"video","src":"(.-)"')
		if not retAdr then
			m_simpleTV.OSD.ShowMessage_UTF8('facebook ошибка[2]', 255, 5)
		 return
		end
	retAdr = retAdr:gsub('\\/', '/')
	m_simpleTV.Control.CurrentTitle_UTF8 = 'facebook'
	m_simpleTV.Control.CurrentAdress = retAdr
-- debug_in_file(retAdr .. '\n')