local t={}
  t.utf8 = true
  t.name = '-'
  t.lua_as_scr = true
  t.luastring = 'm_simpleTV.Control.Restart(-2.0,true)'  --position reset, multiaddress reset
  t.action = 'KEYRESTART'
  m_simpleTV.Interface.AddExtMenuT(t)

