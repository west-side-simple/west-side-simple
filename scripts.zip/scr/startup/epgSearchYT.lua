-- поиск на https://www.youtube.com из телепрограмы (14/6/20)
-- необходим видоскрипт: youtube
	function findEPGInYT(epgId)
			if not epgId then return end
		local t = m_simpleTV.Database.GetTable('SELECT * FROM ChProg WHERE (ChProg.Id=' .. epgId .. ');')
			if not t
				or not t[1]
				or not t[1].Title
			then
			 return
			end
		m_simpleTV.Control.ExecuteAction(38, 0) -- SHOW_OSD_EPG
		m_simpleTV.Control.ExecuteAction(6, 0)
		-- local param = {text='epgID:' .. epgId .. '\n' .. 'Title:' .. t[1].Title,id='testEpgMenu'}
		-- m_simpleTV.OSD.ShowMessageT(param)
		local function clean_title(s)
			s = s:gsub('%(.-%)', ' ')
			s = s:gsub('%[.-%]', ' ')
			s = s:gsub('Х/ф', '')
			s = s:gsub('х/ф', '')
			s = s:gsub('Т/с', '')
			s = s:gsub('т/с', '')
			s = s:gsub('%d+%-.-$', ' ')
			s = s:gsub('Сезон.-$', '')
			s = s:gsub('сезон.-$', '')
			s = s:gsub('Серия.-$', '')
			s = s:gsub('серия.-$', '')
			s = s:gsub('%d+ с%-н.-$', '')
			s = s:gsub('%d+ с[%.]*$', '')
			s = s:gsub('%p', ' ')
			s = s:gsub('«', '')
			s = s:gsub('»', '')
			s = s:gsub('^%s*(.-)%s*$', '%1')
		 return s
		end
		local w = clean_title(t[1].Title)
		w = '-' .. w
		m_simpleTV.Control.PlayAddressT({address = w})
	end
	local t = {}
	t.utf8 = true
	t.name = 'YouTube поиск'
	t.lua_as_scr = true
	t.luastring = 'local action,param,extParam = ...;findEPGInYT(extParam)'
	t.location = 2 -- LOCATION_EPG_MENU
	t.image = m_simpleTV.Common.GetMainPath(0) .. 'Icons/menuYT.png'
	m_simpleTV.Interface.AddExtMenuT(t)