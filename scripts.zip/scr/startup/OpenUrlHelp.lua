-- OpenUrlHelp (18/08/21)
-- Copyright © 2017-2020 Nexterr | https://github.com/Nexterr/simpleTV
-- westSide+
	local youtube = true
	local kinopoisk = true
	local acestream = true
	local tmdb = true
	local rezka = true
	local exfs = true
	local filmix = true
	local kinopub = true
	local function yt(chk)
		if not chk then return '' end
		local video, playlist, channel, live
		if m_simpleTV.Interface.GetLanguage() == 'ru' then
			video = 'Название видео'
			playlist = 'Название плейлиста'
			channel = 'Название канала'
			live = 'Название прямой трансляции'
		else
			video = 'video'
			playlist = 'playlist'
			channel = 'channel'
			live = 'live'
		end
	 return '<p><strong>YouTube</strong></p><table border="1"><tr><td>&nbsp;<strong>- ' .. video .. '</strong>&nbsp;</td><td>&nbsp;<strong>-- ' .. playlist .. '</strong>&nbsp;</td></tr><tr><td>&nbsp;<strong>--- ' .. channel .. '</strong>&nbsp;</td><td>&nbsp;<strong>-+ ' .. live .. '</strong>&nbsp;</td></tr></table>'
	end
		local function ex_fs(chk)
			if not chk then return '' end
		local title, name
		if m_simpleTV.Interface.GetLanguage() == 'ru' then
			title = 'EX-FS'
			name = 'search'
		else
			title = 'EX-FS'
			name = 'search'
		end
	 return '<p><strong>' .. title .. '</strong></p><table border="1"><tr><td>&nbsp;<strong>! ' .. name .. '</strong>&nbsp;</td><td>&nbsp;<strong>! ID сайта Кинопоиск</strong>&nbsp;</td></tr></table>'
	end
	local function fx(chk)
			if not chk then return '' end
		local title, name
		if m_simpleTV.Interface.GetLanguage() == 'ru' then
			title = 'Filmix'
			name = 'search'
		else
			title = 'Filmix'
			name = 'search'
		end
	 return '<p><strong>' .. title .. '</strong></p><table border="1"><tr><td>&nbsp;<strong>? ' .. name .. '</strong>&nbsp;</td></tr></table>'
	end
	local function kp(chk)
			if not chk then return '' end
		local title, name
		if m_simpleTV.Interface.GetLanguage() == 'ru' then
			title = 'КиноПоиск'
			name = 'Название фильма'
		else
			title = 'KinoPoisk'
			name = 'name'
		end
	 return '<p><strong>' .. title .. '</strong></p><table border="1"><tr><td>&nbsp;<strong>* ' .. name .. '</strong>&nbsp;</td><td>&nbsp;<strong>** ID сайта Кинопоиск</strong>&nbsp;</td></tr></table>'
	end
	local function as(chk)
			if not chk then return '' end
		local name
		if m_simpleTV.Interface.GetLanguage() == 'ru' then
			name = 'Название канала'
		else
			name = 'name'
		end
	 return '<p><strong>AceStream TTV</strong></p><table border="1"><tr><td>&nbsp;<strong>+ ' .. name ..'</strong>&nbsp;</td></tr></table>'
	end
	local function tm(chk)
			if not chk then return '' end
		local title, name
		if m_simpleTV.Interface.GetLanguage() == 'ru' then
			title = 'TMDb'
			name = 'Название или теги фильма, сериала, коллекции, персоны'
		else
			title = 'TMDb'
			name = 'Title of the film, series, collection, person'
		end
	 return '<p><strong>' .. title .. '</strong></p><table border="1"><tr><td>&nbsp;<strong>= ' .. name ..'</strong>&nbsp;</td></tr></table>'
	end
	local function rz(chk)
			if not chk then return '' end
		local title, name
		if m_simpleTV.Interface.GetLanguage() == 'ru' then
			title = 'Rezka'
			name = 'Название или теги фильма, сериала, мультфильма, аниме'
		else
			title = 'Rezka'
			name = 'Title of the film, series'
		end
	 return '<p><strong>' .. title .. '</strong></p><table border="1"><tr><td>&nbsp;<strong># ' .. name ..'</strong>&nbsp;</td></tr></table>'
	end
	local function strHtml(html)
		local search
		if m_simpleTV.Interface.GetLanguage() == 'ru' then
			search = 'поиск'
		else
			search = 'search'
		end
	 return '<html><body><h3>🔎 Команды поиска </h3><p></p>' .. html .. '</body></html>'


	end
	local function kpb(chk)
			if not chk then return '' end
		local title, name, name1
		if m_simpleTV.Interface.GetLanguage() == 'ru' then
			title = 'Кинопаб'
			name = 'Тег поиска'
			name1 = ' Стартовая страница'
		else
			title = 'KinoPub'
			name = 'tag search'
			name1 = ' start page'
		end
	 return '<p><strong>' .. title .. '</strong></p><table border="1"><tr><td>&nbsp;<strong>, ' .. name .. '</strong>&nbsp;</td><td>&nbsp;<strong>, ' .. name1 .. '</strong>&nbsp;</td></tr></table>'
	end
	local str = tm(tmdb) .. rz(rezka) .. kp(kinopoisk) .. ex_fs(exfs) .. fx(filmix) .. yt(youtube) .. as(acestream) .. kpb(kinopub)
		if str == '' then return end
	str = strHtml(str)
	m_simpleTV.PlayList.SetOpenUrlHelp(str)