--hookLocalFiles (02/12/2020)

if m_simpleTV.User==nil then m_simpleTV.User={} end
if m_simpleTV.User.hookLocalFiles==nil then m_simpleTV.User.hookLocalFiles={} end

function hookLocalFilesOsdEvent()
 if not m_simpleTV.User.hookLocalFiles.isActive or m_simpleTV.User.hookLocalFiles.isActive==nil then 
    return
 end
 local t = m_simpleTV.Control.GetCurrentChannelInfo()
 if t~=nil and t.Address~=nil then
	m_simpleTV.Control.CurrentAdress_UTF8 = t.Address
	m_simpleTV.Control.Reason = 'Playing'
	
	if m_simpleTV.User.hookLocalFiles~=nil and m_simpleTV.User.hookLocalFiles.Background~=nil then
		m_simpleTV.User.hookLocalFiles.Background = nil
	end
	dofile (m_simpleTV.MainScriptDir .. "user/hookLocalFiles/events.lua")
 end	
end

AddFileToExecute('getaddress',m_simpleTV.MainScriptDir .. "user/hookLocalFiles/getaddress.lua")
AddFileToExecute('events',m_simpleTV.MainScriptDir .. "user/hookLocalFiles/events.lua")
AddFileToExecute('onconfig',m_simpleTV.MainScriptDir .. "user/hookLocalFiles/initconfig.lua")
m_simpleTV.OSD.AddEventListener({type=1,callback="hookLocalFilesOsdEvent"})

local function getConfigVal(key)
 return m_simpleTV.Config.GetValue(key,"hookLocalFilesConf.ini")
end


  local value=getConfigVal('hookLocalFilesEnabledChk') or 0
  m_simpleTV.User.hookLocalFiles.isHook=0	
  if tonumber(value)==1 then
     m_simpleTV.User.hookLocalFiles.isHook=1
  end

  value=getConfigVal('hookLocalFilesVideoChk') or 1
  m_simpleTV.User.hookLocalFiles.isVideo=0     
  if tonumber(value)==1 then
     m_simpleTV.User.hookLocalFiles.isVideo=1
  end

  value = getConfigVal('hookLocalFilesVideo') 
  if value~=nil then 		
	m_simpleTV.User.hookLocalFiles.Video=value
  end		

  value=getConfigVal('hookLocalFilesAudioChk') or 1
  m_simpleTV.User.hookLocalFiles.isAudio=0  
  if tonumber(value)==1 then
     m_simpleTV.User.hookLocalFiles.isAudio=1
  end
  
  value = getConfigVal('hookLocalFilesAudio') 
  if value~=nil then 		
	m_simpleTV.User.hookLocalFiles.Audio=value
  end	

  value=getConfigVal('hookLocalFilesImageChk') or 1
  m_simpleTV.User.hookLocalFiles.isImage=0
  if tonumber(value)==1 then
     m_simpleTV.User.hookLocalFiles.isImage=1
  end

  value = getConfigVal('hookLocalFilesImage') 
  if value~=nil then 		
	m_simpleTV.User.hookLocalFiles.Image=value
  end	

  value = getConfigVal('hookLocalFilesImageDur') or 5
  if value~=nil then 
	m_simpleTV.User.hookLocalFiles.ImageDuration=value
  end

  value=getConfigVal('hookLocalFilesOSDTitleChk') or 0
  m_simpleTV.User.hookLocalFiles.isOSDTitle=0     
  if tonumber(value)==1 then
     m_simpleTV.User.hookLocalFiles.isOSDTitle=1
  end
